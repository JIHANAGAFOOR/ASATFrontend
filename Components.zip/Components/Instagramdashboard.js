import React, { Component } from "react";

import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";
import Typography from "@material-ui/core/Typography";
import Toolbar from "@material-ui/core/Toolbar";
import i18next from "i18next";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import {
  fetchinstagramsentimental,
  fetchinstagramPostCount,
  fetchgetword,
} from "../Reducers/actions";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4plugins_wordCloud from "@amcharts/amcharts4/plugins/wordCloud";
import Paper from "@material-ui/core/Paper";
import PrintIcon from "@material-ui/icons/Print";
import IconButton from "@material-ui/core/IconButton";
import Grid from "@material-ui/core/Grid";
import InstagramIcon from "@material-ui/icons/Instagram";
import { DropdownButton, Dropdown } from "react-bootstrap";
import { MenuItem, FormControl, Select } from "@material-ui/core";
import CircularProgress from "@material-ui/core/CircularProgress";
import CommentsModal from "./CommentsModal";
import MetricWidget from "./MetricWidget";
import PostCountBarChart from "./PostCountBarChart";
import PostCountBarChartModal from "./PostCountBarChartModal";
import SentimentalPieChart from "./SentimentalPieChart";
import * as URLS from "../Reducers/Constants";
import axios from "axios";
import SearchAnalysis1 from './SearchAnalysis1'
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${payload[0].name} : # ${payload[0].value} `}</p>
      </div>
    );
  }

  return null;
};

class Instagramdashboard extends Component {
  constructor() {
    super();
    this.state = {
      // twitterpos: false,
      // twitternegative: false,
      // twitterneutral: false,
      // facebookpos: false,
      // facebookneg: false,
      // facebookneu: false,
      // facebooksearch: "",
      instagrampos: false,
      instagramneg: false,
      instagramneu: false,
      instagramsenti: false,
      posts: false,
	     searchValue: '',
      // ch: null,
      // twitterch: null,
    };
  }

  componentDidMount() {
    let { dispatch } = this.props;
    dispatch(fetchinstagramsentimental());
    dispatch(fetchinstagramPostCount());
    dispatch(fetchgetword());
  }

  handleOpeninstagrampositive = (e) => {
    e.preventDefault();

    this.setState({ instagrampos: true });
  };

  handleCloseinstagrampositive = (e) => {
    e.preventDefault();

    this.setState({ instagrampos: false });
  };

  handleOpeninstagramnegative = (e) => {
    e.preventDefault();

    this.setState({ instagramneg: true });
  };

  handleCloseinstagramnegative = (e) => {
    e.preventDefault();

    this.setState({ instagramneg: false });
  };

  handleOpeninstagramneutral = (e) => {
    e.preventDefault();

    this.setState({ instagramneu: true });
  };

  handleCloseinstagramneutral = (e) => {
    e.preventDefault();
    this.setState({ instagramneu: false });
  };

  handleOpeninstagramposts = (e) => {
    e.preventDefault();
    this.setState({ posts: true });
  };

  handleCloseinstagramposts = (e) => {
    e.preventDefault();
    this.setState({ posts: false });
  };

  handleOpeninstagramsenti = (e) => {
    e.preventDefault();
    this.setState({ instagramsenti: true });
  };

  handleCloseinstagramsenti = (e) => {
    e.preventDefault();
    this.setState({ instagramsenti: false });
  };
handleInputChange = (e) => {
         console.log("nn ",e.target.value)
    this.setState({ searchValue: e.target.value });

  };

  instaChangeWord = async (e) => {
	    e.preventDefault();
console.log("SERACH "+this.state.searchValue)
    let url = URLS.INSTAGRAM_SEARCH + `?search=${this.state.searchValue}`;
    if (this.state.searchValue === "default") {
      url = URLS.INSTAGRAM;
    }
	  console.log("URL "+url)
    const headers = {
      "Content-Type": "application/json",
    };
    await axios.get(url, { headers }).then((res) => {
      let obj2 = res.data;
	    console.log(obj2)
      this.setState({ instagramAnalysis: res.data });
    });
  };

  render() {
    if (this.props.instagramone) {
      let word = this.props.instagramone.report.hash_tags;
      var x = word;
    }

    let chart = am4core.create("chartdiv", am4plugins_wordCloud.WordCloud);
    chart.logo.disabled = true;
    let series = chart.series.push(new am4plugins_wordCloud.WordCloudSeries());
    series.colors = new am4core.ColorSet();
    series.colors.passOptions = {};
    series.accuracy = 4;
    series.randomness = 0;
    series.heatRules.push({
      target: series.labels.template,
      property: "fill",
      min: am4core.color("#ff9800"),
      max: am4core.color("#00bcd4"),
      dataField: "value",
    });
    // series.step = 15;
    // series.rotationThreshold = 0.7;
    // series.maxCount = 200;
    // series.minWordLength = 2;
    series.labels.template.tooltipText = "{word}: {value}";
    // series.fontFamily = "Courier New";
    series.maxFontSize = am4core.percent(30);
    series.dataFields.word = "tag";
    series.dataFields.value = "value";
    series.data = x;

    const lang = localStorage.getItem("search") || "default";

    let totalInstaPosts = "--";
    let totalInstaFollowers = "--";
    let totalInstaFollowing = "--";
    let instaarr = [];
    let instapostvalue = [];
    let instanegative = [];
    let instaneutral = [];
	  let searchArray={}
	  let commentsArray={}
    let words = this.props.getwords || [];
 var instagramData=this.props.instagramsent
    if (this.props.instagramsent) {
	     //commentsArray=this.props.facebooksent.comments;
	    console.log("DATAZZ  "+JSON.stringify(this.props.facebooksent))
	   //let dataSearch=this.props.facebooksent.data || {}

	    //searchArray=dataSearch
      let objs = this.props.instagramsent.report || {};
      instaarr = Object.keys(objs).map((key) => ({
        name: i18next.t(key),
        value: Number(objs[key]),
      }));
//console.log("INSTA ",JSON.stringify(instagramData))
      let instacomments = this.props.instagramsent.comments;
      if (instacomments) {
        instapostvalue = instacomments["positive_description"];
        instanegative = instacomments["negative_description"];
        instaneutral = instacomments["neutral_description"];
      }
    }
	
    if (this.props.instagramProfile) {
      let profileData = this.props.instagramProfile.report;
      if(profileData){
        totalInstaPosts = profileData.post_count.media_count;
        totalInstaFollowers = profileData.followers_count.followers_count;
        totalInstaFollowing = profileData.follows_count.follows_count;
      }
    }

    if (this.props.instagramPostCount) {
      let posts = this.props.instagramPostCount["no of posts"];
      var dayInstaPosts = Object.keys(posts || {}).map((key) => ({
        name: key.slice(0, 10),
        Postscount: posts[key],
      }));
     // console.log("instagram posts", dayInstaPosts.slice(0,90))
    }

    const instagramFileName = "Instagram_Comments";

    return (
      <div
        style={{
          paddingTop: "100px",
          paddingLeft: "30px",
          paddingRight: "30px",
        }}
      >
        <Toolbar variant="dense" style={{ padding: "0.5px" }}>
          <Typography
            variant="h5"
            style={{ flexGrow: "1", marginBottom: "5px" }}
          >
            {i18next.t("Instagram Analysis")}
          </Typography>
          <Breadcrumbs aria-label="breadcrumb" textalign="right">
            <Link color="inherit">{i18next.t("Dashboard")}</Link>

            <Typography color="textPrimary">
              {i18next.t("Instagram Analysis")}
            </Typography>
          </Breadcrumbs>
        </Toolbar>

        <CommentsModal
          title="Positive Comments"
          open={this.state.instagrampos}
          handleCloseModal={this.handleCloseinstagrampositive}
          comments={instapostvalue}
          fileName={instagramFileName}
        />

        <CommentsModal
          title="Negative Comments"
          open={this.state.instagramneg}
          handleCloseModal={this.handleCloseinstagramnegative}
          comments={instanegative}
          fileName={instagramFileName}
        />

        <CommentsModal
          title="Neutral Comments"
          open={this.state.instagramneu}
          handleCloseModal={this.handleCloseinstagramneutral}
          comments={instaneutral}
          fileName={instagramFileName}
        />

        <PostCountBarChartModal
          dataArray={dayInstaPosts}
          open={this.state.posts}
          title="Instagram Posts (90 Days)"
          datekey="name"
          countkey="Postscount"
	    labellingModal="Posts Count"
          handleClose={this.handleCloseinstagramposts}
        />

        {/* Three widgets start */}
        <Grid
          container
          spacing={3}
          // container
          // direction="row"
          justify="space-between"
          // textAlignVertical="center"
        >
          <MetricWidget
            iconType="instagram"
            // backgroundColor="#3b5998"
            backgroundColor="radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%)"
            parentUrl="/parent/fbdb"
            name="Posts"
            count={totalInstaPosts}
          />

          <MetricWidget
            iconType="instagram"
            // backgroundColor="#00aced"
            backgroundColor="radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%)"

            parentUrl="/parent/dashboard"
            name="Followers"
            count={totalInstaFollowers}
          />

          <MetricWidget
            iconType="instagram"
            // backgroundColor="#517fa4"
            backgroundColor="radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%)"

            parentUrl="/parent/indb"
            name="Following"
            count={totalInstaFollowing}
          />
        </Grid>
        {/* Three widgets end */}

        <div class="row mt-4 mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-6">
	    {/*<SentimentalPieChart
              dataArray={instaarr}
              title="Instagram Sentimental Analysis"
              handleOpenPositive={this.handleOpeninstagrampositive}
              handleOpenNegative={this.handleOpeninstagramnegative}
              handleOpenNeutral={this.handleOpeninstagramneutral}
              handleChangeWord={this.instaChangeWord}
              language={lang}
              words={words}
              handleZoomout={this.handleOpeninstagramsenti}
            />*/}
	    <SearchAnalysis1
	    //searchArray={searchArray}
              dataArray={instaarr}

              title="Search Analysis"
              handleOpenPositive={this.handleOpenfacebookpositive}
              handleOpenNegative={this.handleOpenfacebooknegative}
              handleOpenNeutral={this.handleOpenfacebookneutral}
	      handleSubmit={this.instaChangeWord}
	      searchValue={this.state.searchValue}
          setSearchValue={this.handleInputChange}
              handleZoomout={this.handleOpenfbsenti}
	     //commentsArray={commentsArray}
            />
          </div>

          {/* instagram postcount graph start */}
          <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-6">
            <PostCountBarChart
              dataArray={dayInstaPosts}
              title="Instagram Posts (90 Days)"
              datekey="name"
              countkey="Postscount"
              totalPosts="----"
              handleZoomout={this.handleOpeninstagramposts}
              labelling="Post Count"
            />
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  if (state.instagramAnalysis && state.getword) {
    return {
      instagramsent: state.instagramAnalysis.find(
        (obj) => obj.name.toLowerCase() === "sentimental analysis"
      ),
      instagramProfile: state.instagramAnalysis.find(
        (obj) => obj.name === "Profile_data"
      ),
      instagramPostCount: state.instagramPostCount?.data,
      getwords: state.getword,
    };
  } else {
    console.log("No data found");
	 
  }
}

export default withRouter(connect(mapStateToProps)(Instagramdashboard));
