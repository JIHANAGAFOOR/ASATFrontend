import React, { useState } from "react";
import {
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import FacebookCommentsModal from "./FacebookCommentsModal";
const FacebookReport = ({data}) => {
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [comment, setComment] = useState("Nodata");
  function handleBarClick(data) {
    // Extract necessary information from the clicked bar data
    const { message, created_time, positive, negative, neutral, comments } =
      data;
    setModalMessage(message);
    setShowModal(true);
    setComment(comments);
  }

  const newObj = [];

   data.posts_with_comment_analysis.forEach((obj1) => {
  //  console.log(obj1['comments'].positive_description.length);
      let post = {
        created_time: new Date(obj1.post["created_time"]).toLocaleString(),
        // ...obj1.reports,
        Positive_Comment:obj1['comments'].positive_description.length,
        Negative_Comment:obj1['comments'].negative_description.length,
        Neutral_Comment:obj1['comments'].neutral_description.length,
        message: obj1.post["message"],
        comments: obj1["comments"],
      };

      newObj.push(post);
    });

  // console.log(""+JSON.stringify(newObj));
  return (
    <div>
	   <Paper elevation={3}>
	    <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight">
              <div class="mr-auto p-2 bd-highlight">Facebook Sentimental Analysis</div>
              <div class="bd-highlight"> 
              </div>
            </div>
          </Typography>
      <ResponsiveContainer height={400} width="100%" >
        <BarChart
          data={newObj} >
          <XAxis dataKey="created_time" />
          <YAxis />
          <Tooltip />
          <Legend
	  formatter={(value, entry, index) => (
            <span style={{ color: entry.color }}>
              {value.replace(/_/g, ' ')}
            </span>
          )}
	  />
          <Bar
            dataKey="Positive_Comment"
            stackId="a"
            fill="#8884d8"
            onClick={(data) => handleBarClick(data)}
          />
          <Bar
            dataKey="Negative_Comment"
            stackId="a"
            fill="#82ca9d"
            onClick={(data) => handleBarClick(data)}
          />
          <Bar
            dataKey="Neutral_Comment"
            stackId="a"
            fill="#efca9d"
            onClick={(data) => handleBarClick(data)}
          />
        </BarChart>
      </ResponsiveContainer>

       
      {showModal && (
        <FacebookCommentsModal
          title={modalMessage}
          open={showModal}
          handleCloseModal={() => setShowModal(false)}
          comments={comment}
          fileName={"senti"}
        />
      )}
	  </Paper>
    </div>
	 
  );
};

export default FacebookReport;

