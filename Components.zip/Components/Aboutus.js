import React, { Component } from "react";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";

class Aboutus extends Component {
  render() {
    return (
      <div>
        <br />
        <br />
        <br />
        <br />

        <Typography variant="h5" component="h2" gutterBottom>
          {i18next.t('About SAT')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('SAT is a great social analytics tool that helps you identify your best content and see what users need. It helps you execute virtually all your social media tasks in one place. SAT works on a service-oriented architecture model that enables the easy deployment and seamless maintenance and support. SAT has the capability to collect, monitor, analyze, summarize, and visualize social media data to facilitate,conversations and interactions to extract useful patterns and intelligence.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('The Social Media Analytics Process')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('Social media analytics involves a three-stage process')}:
          {i18next.t('capture, understand, and present. The capture stage involves obtaining relevant social media data by monitoring or listening to various social media sources, archiving relevant data, and extracting pertinent information. Not all data that are captured will be useful. The understand stage selects relevant data for modeling, removes noisy, low-quality data, and employs various advanced data analytic methods to analyze the data retained and gain insights from it.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Key Social Media Analytic Techniques')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('Social media analytics is a growing area that encompasses a variety of modeling and analytical techniques from different fields. We highlight below those that are most instrumental in understanding, analyzing, and presenting large amounts of social media data. These techniques can support various stages of social media analytics. Sentimentanalysis and trend analysis primarily support the understand stage. Topic modeling and social network analysis have primarily applications in the understand stage but can support the capture and present stages as well. Visual analytics spans the understand and the present stages.')}

        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Opinion mining (or sentiment analysis)')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('is the core technique behind many social media monitoring systems and trend analysis applications. It leverage computational linguistics, natural language processing and other methods of text analytics to automatically extract user sentiments or opinions from text sources at any level of granularity (words or phrases up to entire documents). Such subjective information extracted about people, products, services, or other entities support various tasks including predicting stock market movements, determining market trends, analyzing product defects, and managing crises.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Social network analysis')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('is used to analyze a social network graph to understand its underlying structure, connections, and theoretical properties as well as to identify the relative importance of different nodes within the network. A social network graph consists of nodes (users) and associated relationships (depicted by edges). The relationships are typically detected from user actions directly connecting two people (such as accepting another user as a friend), though they may be inferred from indirect behaviors creating relationships, such as voting, tagging, or commenting.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Trend analysis')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('is used for identifying and predicting future outcomes and behaviors based on historical data collected over time. Applications of trend analysis include forecasting the growth of customers or sales, predicting the effectiveness of ad campaigns, staying ahead of shifts in consumers’ sentiments, forecasting movements in the stock market, etc.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Profile analysis')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('is the multivariate equivalent of repeated measures or mixed ANOVA.In profile analysis, the data are usually plotted with time points, observations, tests, etc. on the x-axis, with the response, score, etc. on the y-axis. These plots are then made into profiles lines representing the score across time points or tests for each group.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Hash tag analysis')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('is one of the most important concepts in the modern world. Hashtags that spread quickly and get used by a lot of different users begin to trend.That means that the keyword term is popular and becoming widely used online. That doesn’t mean that every hashtag you set out to use should trend. It all depends on why you’re using your hashtag. SAT framework will get the hashtags from the popular social media websites like Facebook,Twitter etc.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Contextual analysis')}:
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('is the best way to determine in which term the business operates which mainly focuses on the macro environment of a business. An SAT will perform this analysis by text (in whatever medium, including multimedia) that helps us to assess that text within the context of its historical and cultural setting, but also in terms of its textuality – or the qualities that characterize the text as a text.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t("'Api/Third party integration for Analysis of emails and help desks calls etc'")} :
          {i18next.t('SAT will allow you to communicate and analyse the emails and other third parties applications. SAT will receive the data from different sources like help desk calls emails and other third party APIs and will be able to analyze the data.')}
        </Typography>
        <Typography variant="h6" component="h2" gutterBottom>
          {i18next.t('Use Cases for Social Media Analytics')}::
        </Typography>
        <Typography variant="subtitle1" component="h2" gutterBottom>
          {i18next.t('Innovation')} :
          ➢ {i18next.t('SAT can be leveraged to collaborate with customers and drive future products and services. Think of it like a digital crowdsourcing method— gather information about what customers want and how you can serve them better.')}
          <br />
          {i18next.t('Brand Health')} :
          ➢{i18next.t('Brand health measures people’s attitudes, conversations, and behavior towards your products and services. Measuring brand health through social media can give real-time insights about people’s perception of your brand, as well as add a new layer to metric like NPS. To measure brand health, look at')} : ● {i18next.t('Conversation and sentiment drivers')}  ● {i18next.t('Location, time, and impact of conversations')} ● {i18next.t('Competitive implications')} ● {i18next.t('Issues identification')} ● {i18next.t('Influence')}

          <br />
          {i18next.t('Customer Experience')} :
          ➢{i18next.t('Improving your relationship with customers and their experience with your brand is absolutely essential and leads to numerous other benefits like better brand health and increased revenue. Ways to improve customer experiences through social media include keeping them informed, engaging with them, and offering exclusive promotions to followers. To measure customer experience, look at ● Customer attitudes (common keywords and topics) ● Context ● Volume of service issues addressed through social.')}
          <br />
          {i18next.t('Marketing Optimization')} :
          ➢{i18next.t('Use social data to improve the effectiveness of marketing programs. Social media performance can demonstrate how similar marketing content and campaigns will perform on other platforms, driving them in a more successful direction. Additionally, social media can help marketers understand target groups of people—how they speak, what they like, what they respond to— so they can tailor other types of marketing to them better')}
          <br />
          ➢ {i18next.t('Operational Efficiency Social tends to require initial investment and some ongoing resources, but it can deliver both hard and soft operational benefits long-term. An example is word-of-mouth advertising, or customers using social to extend brand influence across their own networks. Another is addressing issues via social—like responding to customers’ tweets— instead of relying on more costly forms of customer service like call centers. To measure operational efficiency, consider  ● Percentage of resolved inquiries by channel ● Most active brand advocates by channel (by likes, shares, retweets, etc.) ● Popular questions asked on social versus through other mediums.')}
        </Typography>
      </div>
    );
  }
}

export default Aboutus;
