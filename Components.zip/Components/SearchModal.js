import React from "react";
import Modal from "@material-ui/core/Modal";
import PrintIcon from "@material-ui/icons/Print";
import CloseIcon from "@material-ui/icons/Close";
import { Table } from "react-bootstrap";
// import { ExportCSV } from "./ExportCSV";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";

const formatDateTime = (dateTime) => {
  let formattedDateTime = new Date(dateTime).toLocaleString();
  return formattedDateTime;
};

// CommentsModal component
const SearchModal = ({
 title, 
  open,
  handleCloseModal,
  comments,
  fileName,
}) => {
  console.log("comments",  comments,
  )
  return (
    <Modal
      open={open}
      onClose={handleCloseModal}
      style={{ overflow: "scroll" }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Paper
          elevation={3}
          style={{
            textAlign: "left",
            padding: "10px",
            overflow: "scroll",
            width: "900px",
            maxHeight: "900px",
            marginTop: "40px",
          }}
        >
          <div align="right">
            {/* <ExportCSV csvData={comments} fileName={fileName} /> */}
            <IconButton onClick={() => window.print()}>
              <PrintIcon />
            </IconButton>
            <IconButton onClick={handleCloseModal}>
              <CloseIcon />
            </IconButton>
          </div>

          <Table striped bordered hover >
            <thead>
              <tr>
                <th>Search Word : {title}</th>
              </tr>
            </thead>
            <div >
            <tbody >
	  {comments.positive_description.length > 0&&<span style={{color:"green",fontWeight:500,}}>Positive Comments </span>}
            <div style={{border:'1px solid black',borderRadius:'10px',padding:'10px',marginBottom:'16px'}}>
              {comments.positive_description.length > 0 ? 
               
                comments.positive_description.map((comment, index) => (
                  <div >
                   
                    <tr key={index}>
                    <span>{index+1}.</span> <td style={{ fontSize: "15px",color:"geen" }}>
                        <span>{comment.message || comment.message}</span>{"   "}
			{/* <span className="secname">
                          {formatDateTime(comment.time || comment.date_time)}
                        </span>*/}
                      </td>
                    </tr>
                  </div>
                ))
              : (
                <tr>
                  <td
                    colSpan="1"
                    style={{ fontSize: "15px", textAlign: "",color:"green" }}
                  >
                    No Positive Comment found!!!
                  </td>
                </tr>
              )}
              </div>
            </tbody>
	  
            <tbody style={{backgroundColor:"",}}>
                {comments.negative_description.length > 0&&<span style={{color:"red",fontWeight:500}}>Negative Comments </span>}
                <div style={{border:'1px solid black',borderRadius:'10px',padding:'10px',marginBottom:'16px'}}>
              { comments.negative_description.length > 0 ? (
                comments.negative_description.map((comment, index) => (
                  <tr key={index} style={{color:"red"}}>
			<span>{index+1}. </span> <td style={{ fontSize: "15px" }}>
                      <span>{comment.message || comment.message}</span>{"    "}
			{/*<span className="secname">{formatDateTime(comment.time || comment.date_time)}</span>*/}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="1" style={{ fontSize: "15px", color:"red",fontWeight:"500" }}>
                  No Negative Comments found!!!
                  </td>
                </tr>
              )}
              </div>
            </tbody>
            <tbody style={{backgroundColor:"",}}>
                {comments.neutral_description.length > 0&&<span style={{fontWeight:500}}>Neutral Comments </span>}
                <div style={{border:'1px solid black',borderRadius:'10px',padding:'10px',marginBottom:'16px'}}>
              { comments.neutral_description.length > 0 ? (
                comments.neutral_description.map((comment, index) => (
                  <tr key={index} >
                     <span>{index+1}. </span>
                   <td style={{ fontSize: "15px" }}>
                     
                      <span>{comment.message}</span>{"   "}
			{/*<span className="secname">{formatDateTime(comment.time || comment.date_time)}</span>*/}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="1" style={{ fontSize: "15px",fontWeight:"500" }}>
                  No Neutral Comments found!!!
                  </td>
                </tr>
              )}
              </div>
            </tbody>
            </div>
          </Table>
        </Paper>
      </div>
    </Modal>
  );
};

export default SearchModal;

