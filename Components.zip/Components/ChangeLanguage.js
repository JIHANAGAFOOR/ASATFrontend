import React, { Component } from "react";
import i18next from "i18next";

export class ChangeLanguage extends Component {
  change(option) {
    option.preventDefault();
    localStorage.setItem("lang", option.target.value);
    window.location.reload();
  }

  render() {
    const lang = localStorage.getItem("lang") || "en";
    return (
      <>
        <select
          className="custom-select pull-right mr-2"
          onChange={this.change}
          value={lang}
          style={{ color: "#111112", width:200}}
        
        >
          <option value="en">English</option>
          <option value="hi">Hindi</option>
          <option value="mr">Marathi</option>
        </select>
      </>
    );
  }
}

export default ChangeLanguage;
