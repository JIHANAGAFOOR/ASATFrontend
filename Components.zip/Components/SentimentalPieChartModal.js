import React from "react";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";
import CircularProgress from "@material-ui/core/CircularProgress";
import Modal from "@material-ui/core/Modal";
import CloseIcon from "@material-ui/icons/Close";
import PrintIcon from "@material-ui/icons/Print";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,Label,
  ResponsiveContainer,
} from "recharts";

const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${payload[0].name} : ${payload[0].value} % `}</p>
      </div>
    );
  }
  return null;
};

export default function PostCountBarChartModal({dataArray, open, title, handleClose}) {  
  return <Modal open={open} onClose={handleClose}>
    <div
      style={{
        // width:1800,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Paper
        elevation={3}
        style={{
          textAlign: "center",
          textAlignVertical: "center",
          padding: "10px",
        }}
      >
        <Typography>{i18next.t(title)}</Typography>

        <div align="right">
          <IconButton onClick={() => window.print()}>
            <PrintIcon />
          </IconButton>
          <IconButton onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </div>
        <ResponsiveContainer height={800} width={1800}>
          <PieChart
            width={100}
            height={100}
            // onMouseEnter={this.onPieEnter}
          >
            <Legend layout="vertical" verticalAlign="top" align="right" />
            <Tooltip content={<CustomTooltip />} />
            <Pie
              data={
                dataArray.length > 0 ? (
                  dataArray
                ) : (
                  <p>
                    <CircularProgress />
                  </p>
                )
              }
              cx={900}
              cy={350}
              innerRadius={135}
              outerRadius={275}
              fill="#8884d8"
              paddingAngle={5}
              dataKey="value"
          
              labelLine={true}
               label={({ name, percent }) => `${name} ${(percent * 100).toFixed(2)}%`}

                    
            >
              {dataArray.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={COLORS[index % COLORS.length]}
                />
              ))}
              <Label
    valueKey="value"
    position="inside"
    fill="#ffffff"
    fontSize={14}
  />

            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </Paper>
    </div>
  </Modal>
;

};
