import React, { useState,useMemo} from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { GrevienceData } from './GravienceData';

const GravienceStage = () => {
  const [data, setData] = useState(GrevienceData);
  const [selectedStage, setSelectedStage] = useState("CLOSED");
  const handleStageChange = (e) => {
    setSelectedStage(e.target.value);
  };

  const calculateChartData = useMemo(() => {
    const stageData = {};

    // Calculate mean completion time for the selected stage
    data.forEach(item => {
        if (item.Stage === selectedStage) {
            if (!stageData[item.Subject]) {
                stageData[item.Subject] = { total: 0, count: 0 };
            }
            stageData[item.Subject].total += parseInt(item.CompletionTime); // Parse CompletionTime as an integer
            stageData[item.Subject].count++;
        }
    });

    // Format data for the selected stage
    const formattedData = Object.keys(stageData).map(subject => {
        const { total, count } = stageData[subject];
        const meanCompletionTime = count !== 0 ? Math.round(total / count) : 0; // Handle division by zero
        return {
            Subject: subject,
            MeanCompletionTime: meanCompletionTime
        };
    });

    return formattedData;
}, [data, selectedStage]);
console.log("calculateChartData",calculateChartData)
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF1919'];

  return (
    <div>
      <div style={{ float: 'right',margin:8 }}>
        <p>Select Stage:</p>
        <select value={selectedStage} onChange={handleStageChange}>
          <option value="">Select Stage</option>
          {data && [...new Set(data.map(item => item.Stage))].map((stage, index) => (
            <option key={index} value={stage}>{stage}</option>
          ))}
        </select>
      </div>
      <div>
        {/* <h3>Mean Completion Time for Selected Stage: {selectedStage}</h3> */}
        {calculateChartData.length > 0 && (
          <BarChart
            width={400}
            height={430}
            data={calculateChartData}
            barSize={15}
            layout="vertical"
            margin={{ top: 32, right: 0, left: 16, bottom: 5 }}
          >
          
            <XAxis type="number" interval={"preserveStartEnd"} />
            <YAxis
              type="category"
              dataKey="Subject"
              width={100}
            //   angle={-10}
              textAnchor="end"
              label={{
                value: "Subject",
                angle: -90,
                position: "insideLeft",
                textAnchor: "middle",
                offset: -50,
              }}
            />
            <Tooltip />
            <Legend />
            <Bar dataKey="MeanCompletionTime" fill="#8884d8"barSize={10} />
          </BarChart>
        )}
      </div>
    </div>
  );
};

export default GravienceStage ;

