import React, { useState } from "react";
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
} from "recharts";
import "./GrievanceForcast.css"; // Import your CSS file for styling

const data = [
  { name: "Cleaning of Public Toilets", actual: 67, forecast: 72 },
  { name: "Unauthorised Mobile Tower", actual: 78, forecast: 84 },
  { name: "Illegal Hording / Flex", actual: 78, forecast: 84 },
  { name: "Irregular Water Supply", actual: 78, forecast: 84 },
];
const dd = [{ name: "Illegal Hording / Flex", actual: 78, forecast: 84 }];
const GrievanceForcast = () => {
  const [selectedDataKey, setSelectedDataKey] = useState([
    { name: "Cleaning of Public Toilets", actual: 67, forecast: 72 },
  ]);

  const handleButtonClick = (dataKey) => {
    const filter = data.filter((entries) => entries.name === dataKey);
    setSelectedDataKey(filter);
  };
 

  return (
    <div className="line-graph-container">
      <BarChart
       width={300}
       height={300}
        data={selectedDataKey}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="actual" fill="#8884d8" />
        <Bar dataKey="forecast" fill="#82ca9d" />
      </BarChart>
      <div className="button-container" style={{cursor:"pointer"}}>
        <button onClick={() => handleButtonClick("Cleaning of Public Toilets")}>
          Cleaning of Public Toilets
        </button>
        <button onClick={() => handleButtonClick("Unauthorised Mobile Tower")}>
          Unauthorised Mobile Tower
        </button>
	  {/*  <button onClick={() => handleButtonClick("Illegal Hording / Flex")}>
          Illegal Hording / Flex
        </button>
        <button onClick={() => handleButtonClick("Irregular Water Supply")}>
          Irregular Water Supply
        </button>*/}
      </div>
    </div>
  );
};

export default GrievanceForcast;

