import React, { Component } from "react";

class Webcrawling extends Component {
  
  render() {
    

    
    return <div>
      <br/>
      <br/>
      <br/>
      this is crawling
      <br/>
      
      <button onClick="window.open('file:///E:\asat_scrapper\stand_alone\dist\')">
        launch</button>
        <a href="file:///E:\asat_scrapper\stand_alone\dist\_init_.exe">test</a> </div>;
        
  }

  
}

export default Webcrawling;
