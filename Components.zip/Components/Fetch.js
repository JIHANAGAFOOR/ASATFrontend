export const Data=[
  {
      "_id": "65ddbb702b1213c0cd2242c9",
      "account_name": "pcmc",
      "name": "Sentimental Analysis",
      "posts_with_comment_analysis": [
          {
              "post": {
                  "created_time": "2024-02-27T06:14:30+0000",
                  "message": "\u092e\u0939\u093e\u0930\u093e\u0937\u094d\u091f\u094d\u0930 \u0936\u093e\u0938\u0928\u093e\u091a\u094d\u092f\u093e \u0938\u093e\u0902\u0938\u094d\u0915\u0943\u0924\u093f\u0915 \u0915\u093e\u0930\u094d\u092f \u0935\u093f\u092d\u093e\u0917 \u0935 \u091c\u093f\u0932\u094d\u0939\u093e\u0927\u093f\u0915\u093e\u0930\u0940, \u092a\u0941\u0923\u0947 \u092f\u093e\u0902\u091a\u094d\u092f\u093e\u0924\u0930\u094d\u092b\u0947 \u0926\u093f.\u0968\u096e \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0924\u0947 \u0969 \u092e\u093e\u0930\u094d\u091a \u0926\u0930\u092e\u094d\u092f\u093e\u0928 \u092e\u0939\u093e\u0938\u0902\u0938\u094d\u0915\u0943\u0924\u0940 \u092e\u0939\u094b\u0924\u094d\u0938\u0935 \u0968\u0966\u0968\u096a \u0938\u093e\u0939\u093f\u0924\u094d\u092f\u0930\u0924\u094d\u0928 \u092a\u0941\u0923\u0947 \u091c\u093f\u0932\u094d\u0939\u094d\u092f\u093e\u0924\u0940\u0932 \u0935\u093f\u0935\u093f\u0927 \u0920\u093f\u0915\u093e\u0923\u0940 \u0906\u092f\u094b\u091c\u093f\u0924 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u093e \u0906\u0939\u0947.\n\n\u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092c\u0939\u0941\u0938\u0902\u0916\u094d\u092f\u0947\u0928\u0947 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u0939\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940!",
                  "id": "477167415712554_718200447151965"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-27T06:51:50+0000",
                          "message": "\u0938\u093e\u0939\u093f\u0924\u094d\u092f \u0930\u0924\u094d\u0928  \u0939\u0947 \u0920\u093f\u0915\u093e\u0923 \u0928\u0947\u092e\u0915\u0947 \u0915\u0941\u0920\u0947 \u0906\u0939\u0947"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-27T07:50:52+0000",
                          "message": "Pimpri Chinchwad Municipal Corporation \u0909\u0917\u093e\u091a \u092a\u094b\u0938\u094d\u091f \u0915\u0930\u093e\u092f\u091a\u0940 \u092e\u094d\u0939\u0923\u0941\u0928 \u0915\u0930\u0941 \u0928\u0915\u093e. \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u093e \u0924\u0940 \u092a\u094b\u0938\u094d\u091f \u0935\u093e\u091a\u0924\u093e \u092a\u0923 \u0906\u0932\u0940 \u092a\u093e\u0939\u093f\u091c\u0947 \u0939\u0940 \u0915\u093e\u0933\u091c\u0940 \u0918\u094d\u092f\u093e."
                      }
                  ]
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-27T04:23:59+0000",
                  "message": "\u0915\u0927\u0940 \u0938\u0939\u094d\u092f\u093e\u0926\u094d\u0930\u0940\u091a\u094d\u092f\u093e \u0921\u094b\u0902\u0917\u0930\u093e\u0924 \u0924\u0930 \u0915\u0927\u0940 \u0938\u0902\u0924\u093e\u0902\u091a\u094d\u092f\u093e \u0936\u092c\u094d\u0926\u093e\u0924, \n\u0915\u0927\u0940 \u0907\u0924\u093f\u0939\u093e\u0938\u093e\u091a\u094d\u092f\u093e \u092a\u093e\u0928\u093e\u0924 \u0924\u0930 \u0915\u0927\u0940 \u092f\u093e \u092d\u0942\u092e\u0940\u0935\u0930\u0940\u0932 \u092e\u093e\u0923\u0938\u093e\u0902\u091a\u094d\u092f\u093e \u092e\u0928\u093e\u0924!\n\n\u0906\u092e\u094d\u0939\u0940 \u0936\u094b\u0927\u0932\u0902, \u091c\u092a\u0932\u0902, \u0905\u0928\u0941\u092d\u0935\u0932\u0902 \u0906\u0939\u0947 \u092e\u0930\u093e\u0920\u0940\u092a\u0923...\n\n\u092e\u0930\u093e\u0920\u0940 \u092d\u093e\u0937\u093e \u0917\u094c\u0930\u0935 \u0926\u093f\u0928\u093e\u091a\u094d\u092f\u093e \u0939\u093e\u0930\u094d\u0926\u093f\u0915 \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e!\n\n#\u0917\u094c\u0930\u0935_\u092e\u0930\u093e\u0920\u0940\u091a\u093e #\u092e\u0930\u093e\u0920\u0940_\u092d\u093e\u0937\u093e_\u0917\u094c\u0930\u0935_\u0926\u093f\u0928 #PCMC",
                  "id": "477167415712554_718164153822261"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-23T10:46:35+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0938\u0948\u0928\u093f\u0915 \u092d\u0935\u0928, \u0926\u093f\u0918\u0940 \u092f\u0947\u0925\u0947 RRR \u0915\u0947\u0902\u0926\u094d\u0930  \u0909\u092d\u093e\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0947 \u0906\u0923\u093f \u092f\u093e\u092c\u093e\u092c\u0924 \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u091c\u0928\u091c\u093e\u0917\u0943\u0924\u0940 \u0926\u0947\u0916\u0940\u0932 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhSurvekshan2024 \n#SwachhSurvekshan2024Maharashtra \n#MissionLiFE \n#MajhiVasundharaAbhiyan4 \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \n#SwachhBharatGov \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs \nSwachh Bharat Mission - Urban \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_716114644027212"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-23T15:43:43+0000",
                          "message": "Good effort , keep it up \ud83d\udc4fLet me know if as a responsible citizen I can also help the community."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "66.67",
                  "negative": "0.00",
                  "neutral": "33.33"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-23T10:43:46+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0938\u0902\u0924 \u0917\u093e\u0921\u0917\u0947 \u092e\u0939\u093e\u0930\u093e\u091c \u091c\u092f\u0902\u0924\u0940 \u0928\u093f\u092e\u093f\u0924\u094d\u0924 \u0915\u093f\u0935\u0933\u0947 \u0935\u093f\u0915\u093e\u0938 \u0928\u0917\u0930 \u0930\u0939\u093f\u0935\u093e\u0936\u0940 \u0938\u0902\u0918 \u0906\u0923\u093f \u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0928\u092a\u093e \u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0938\u0902\u092f\u0941\u0915\u094d\u0924 \u0935\u093f\u0926\u094d\u092f\u092e\u093e\u0928\u0947 \u090f\u092e \u092c\u0940 \u0915\u0948\u0902\u092a \u0924\u0947 \u092e\u0941\u0915\u093e\u0908 \u091a\u094c\u0915 \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nSwachh Bharat Mission - Urban \nSwachh Maharashtra Mission -Urban \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs",
                  "id": "477167415712554_716113100694033"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-23T10:58:58+0000",
                          "message": "\u0905\u0924\u093f\u0936\u092f \u0938\u0941\u0902\u0926\u0930 \u0915\u093e\u092e \u0935 \u0928\u093f\u092f\u094b\u091c\u0928"
                      },
                      {
                          "date_time": "2024-02-25T03:47:05+0000",
                          "message": "Good effort on cleanliness..Our city PCMC should win 1st Prize this time in All India Ranking.We can beat Mysore and Indore also.Lets all citizen come together and help local government in their efforts.Also all citizens should maintain highest level of cleanliness near their home and offices."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "80.00",
                  "negative": "0.00",
                  "neutral": "20.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T17:03:42+0000",
                  "message": "\u092f\u0936\u0938\u094d\u0935\u0940 \u0915\u093e\u092e\u0917\u093f\u0930\u0940\u092c\u0926\u094d\u0926\u0932 \u0905\u092d\u093f\u0928\u0902\u0926\u0928!\n\n\u0907\u0902\u0921\u0938\u094d\u091f\u094d\u0930\u0940\u0905\u0932 \u0938\u094d\u092a\u094b\u0930\u094d\u091f\u0938 \u0905\u0938\u094b\u0938\u093f\u090f\u0936\u0928\u0924\u0930\u094d\u092b\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u091f\u0940-\u0968\u0966 \u0915\u094d\u0930\u093f\u0915\u0947\u091f \u0938\u094d\u092a\u0930\u094d\u0927\u0947\u091a\u094d\u092f\u093e \u0905\u0902\u0924\u093f\u092e \u0938\u093e\u092e\u0928\u094d\u092f\u093e\u0924 \u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u092a\u093e\u0932\u093f\u0915\u093e \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0915\u094d\u0930\u093f\u0915\u0947\u091f \u0938\u0902\u0918\u093e\u0928\u0947 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u0938\u0902\u0918\u093e\u0935\u0930 \u092e\u093e\u0924 \u0915\u0930\u0924 \u0935\u093f\u091c\u0947\u0924\u0947\u092a\u0926 \u092a\u091f\u0915\u093e\u0935\u0932\u0947. \n\n\u0935\u093f\u091c\u0947\u0924\u094d\u092f\u093e \u0938\u0902\u0918\u093e\u091a\u0947 \u0906\u092f\u0941\u0915\u094d\u0924 \u0924\u0925\u093e \u092a\u094d\u0930\u0936\u093e\u0938\u0915 \u0936\u0947\u0916\u0930 \u0938\u093f\u0902\u0939 \u092f\u093e\u0902\u0928\u0940 \u0915\u094c\u0924\u0941\u0915 \u0915\u0947\u0932\u0947 \u0905\u0938\u0941\u0928 \u092f\u0936\u093e\u092c\u0926\u094d\u0926\u0932 \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e\u0926\u0947\u0916\u0940\u0932 \u0926\u093f\u0932\u094d\u092f\u093e.\n\nThe winning fifer!\n\nThe #PCMC employee cricket team won the title by defeating the Tata Motors team in the final match of the T20 cricket tournament organized by the Industrial Sports Association.\n\n#WellPlayed #PCMCUpdates",
                  "id": "477167415712554_715206974117979"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-21T17:27:02+0000",
                          "message": "Congratulations all Tim"
                      },
                      {
                          "date_time": "2024-02-22T09:49:20+0000",
                          "message": "Wow... Congratulations \ud83d\udc4f \ud83d\udc4f \ud83d\udc4f \ud83c\udf89 \ud83c\udf89 Keep it"
                      }
                  ]
              },
              "reports": {
                  "positive": "57.14",
                  "negative": "0.00",
                  "neutral": "42.86"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T06:26:16+0000",
                  "message": "\u091c\u0936\u0940 \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u0947\u0935\u093f\u0937\u092f\u0940\u091a\u0940 \u0917\u094b\u0921\u0940 \u092e\u0928\u093e\u0924\u0942\u0928 \u0915\u0927\u0940\u0939\u0940 \u0938\u0902\u092a\u0924 \u0928\u093e\u0939\u0940 \u0924\u0938\u0947\u091a \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u0947\u0924\u0942\u0928 \u0936\u093f\u0915\u0932\u0947\u0932\u094d\u092f\u093e \u0917\u094b\u0937\u094d\u091f\u0940 \u0915\u0927\u0940\u0939\u0940 \u0935\u093f\u0938\u094d\u092e\u0930\u0923\u093e\u0924 \u091c\u093e\u0924 \u0928\u093e\u0939\u0940\u0924. \n\n\u091c\u093e\u0917\u0924\u093f\u0915 \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u093e \u0926\u093f\u0928\u093e\u091a\u094d\u092f\u093e \u0938\u0930\u094d\u0935\u093e\u0902\u0928\u093e \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e!\n\n#\u092e\u093e\u0924\u0943\u092d\u093e\u0937\u093e\n#InternationalMotherTongueDay",
                  "id": "477167415712554_714960150809328"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-21T10:43:53+0000",
                          "message": "\u0906\u0924\u093e \u0939\u094d\u092f\u093e \u0936\u0941\u092d\u0926\u093f\u0928\u0940 \u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0916\u093e\u0924\u094d\u092f\u093e\u091a\u0947 \u0928\u093e\u0935 \u092e\u0930\u093e\u0920\u0940\u0924 \u0915\u0930\u0942\u0928 \u091f\u093e\u0915\u093e"
                      },
                      {
                          "date_time": "2024-02-21T09:48:55+0000",
                          "message": "\u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0916\u093e\u0924\u094d\u092f\u093e\u091a\u0947 \u0928\u093e\u0935 \u0906\u092a\u0932\u094d\u092f\u093e \u092e\u093e\u092f\u092e\u0930\u093e\u0920\u0940 \u0915\u0930\u093e\n\n\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u2705\ud83d\ude0d"
                      }
                  ]
              },
              "reports": {
                  "positive": "44.44",
                  "negative": "0.00",
                  "neutral": "55.56"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T06:14:06+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u092e\u0928\u092a\u093e \u0936\u093e\u0933\u093e, \u0928\u0947\u0939\u0930\u0942\u0928\u0917\u0930  \u092f\u0947\u0925\u0947 \u092a\u0925\u0928\u093e\u091f\u094d\u092f\u093e\u091a\u094d\u092f\u093e \u092e\u093e\u0927\u094d\u092f\u092e\u093e\u0924\u0942\u0928 \u0935\u093f\u0926\u094d\u092f\u093e\u0930\u094d\u0925\u094d\u092f\u093e\u0902\u092e\u0927\u094d\u092f\u0947 (\u0913\u0932\u093e, \u0938\u0941\u0915\u093e, \u0938\u0945\u0928\u093f\u091f\u0930\u0940, \u0918\u0930\u0917\u0941\u0924\u0940 \u0918\u093e\u0924\u0915, \u092a\u094d\u0932\u093e\u0938\u094d\u091f\u093f\u0915) \u0905\u0936\u093e \u092a\u093e\u091a \u092a\u094d\u0930\u0915\u093e\u0930\u091a\u094d\u092f\u093e \u0915\u091a\u0930\u093e \u0935\u0930\u094d\u0917\u0940\u0915\u0930\u0923\u093e\u0935\u093f\u0937\u092f\u0940 \u091c\u0928\u091c\u093e\u0917\u0943\u0924\u0940 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940, \u0924\u0938\u0947\u091a \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u0947\u091a\u0940 \u0935 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u0947\u091a\u0940 \u0938\u093e\u092e\u0942\u0939\u093f\u0915 \u0936\u092a\u0925\u0939\u0940 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhSurvekshan2024 \n#SwachhSurvekshan2024Maharashtra \n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \nMajhi Vasundhara \nSwachh Bharat Mission - Urban  \nMinistry of Housing and Urban Affairs \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_714956687476341"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-21T06:31:00+0000",
                          "message": "We should all participate in Cleanliness as a community and make PCMC proud.All citizens should do their bit and should take onus to clean 100 sq foot area around their residence and office.This will infact help make INDIA cleaner."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T12:52:09+0000",
                  "message": "\u0936\u093f\u0915\u094d\u0937\u0923 \u0935\u093f\u0937\u092f\u0915 \u0938\u0941\u0935\u093f\u0927\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u0935\u093f\u0926\u094d\u092f\u093e\u0930\u094d\u0925\u0940-\u0936\u093f\u0915\u094d\u0937\u0915 \u092e\u0942\u0932\u094d\u092f\u093e\u0902\u0915\u0928, \u091c\u0932\u094d\u0932\u094b\u0937 \u0936\u093f\u0915\u094d\u0937\u0923\u093e\u091a\u093e, \u0905\u092d\u094d\u092f\u093e\u0938\u0926\u094c\u0930\u093e, \u0938\u092e\u0941\u092a\u0926\u0947\u0936\u0928 \u0905\u0938\u0947 \u0938\u092e\u093e\u0935\u0947\u0936 \u0906\u0939\u0947.\n\nProvision for Educational facilities include student-teacher assessment, Jallosh Shikshanacha, study tours & counselling, etc.\n\n#PCMCBudget2024_25",
                  "id": "477167415712554_714563887515621"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-21T06:35:47+0000",
                          "message": "Very good initiative"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "54.55",
                  "negative": "0.00",
                  "neutral": "45.45"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T12:23:42+0000",
                  "message": "\u0936\u0939\u0930\u093e\u091a\u094d\u092f\u093e \u0938\u094c\u0902\u0926\u0930\u094d\u092f\u093e\u0924 \u0935\u093e\u0922 \u0915\u0930\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0935 \u092e\u0941\u0932\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u092e\u0948\u0926\u093e\u0928\u0940 \u0916\u0947\u0933\u093e\u0902\u091a\u0940 \u0930\u0942\u091a\u0940 \u0935\u093e\u0922\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u092a\u0941\u0922\u0940\u0932 \u0924\u0930\u0924\u0941\u0926\u0940 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u094d\u092f\u093e \u0906\u0939\u0947\u0924.\n\nSaid provisions have been made to enhance the beauty of #PCMC & create interest in children for outdoor activities.\n\n#PCMCBudget2024_25",
                  "id": "477167415712554_714552077516802"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [
                      {
                          "date_time": "2024-02-20T14:35:24+0000",
                          "message": "Hmm, \u092a\u093f\u0902\u092a\u0933\u0947 \u0938\u094c\u0926\u093e\u0917\u0930 \u0932\u093e \u0917\u0930\u0940\u092c \u0932\u094b\u0915\u0902 \u0930\u093e\u0939\u0924\u093e\u0924, \u0924\u094d\u092f\u093e\u0902\u091a\u094d\u092f\u093e \u092e\u0941\u0932\u093e\u0902\u0938\u093e\u0920\u0940 \u0939\u094d\u092f\u093e\u091a\u093e \u092b\u093e\u092f\u0926\u093e\u091a \u0939\u094b\u0908\u0932"
                      }
                  ],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-20T12:56:02+0000",
                          "message": "\u092e\u094b\u0936\u0940 \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0940\u0932 \u0909\u0926\u094d\u092f\u093e\u0928\u0947 \u0915\u0927\u0940 \u0935\u093f\u0915\u0938\u093f\u0924 \u0939\u094b \u0939\u094b\u0923\u093e\u0930"
                      }
                  ]
              },
              "reports": {
                  "positive": "46.15",
                  "negative": "7.69",
                  "neutral": "46.15"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T05:30:30+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u0947 \u0905\u0902\u0926\u093e\u091c\u092a\u0924\u094d\u0930\u0915\u0968\u0966\u0968\u096a-\u0968\u0966\u0968\u096b \u0926\u093f.-\u0968\u0966 \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0938\u0915\u093e\u0933\u0940 \u0967\u0967\u0935\u093e...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_357852063796195"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-20T06:14:47+0000",
                          "message": "Very good budget...PCMC India"
                      },
                      {
                          "date_time": "2024-02-20T05:50:49+0000",
                          "message": "Good Budget...PCMC"
                      },
                      {
                          "date_time": "2024-02-20T05:53:23+0000",
                          "message": "Pls take care of senior citizens with more walking areas,parks, cycling tracks near Nehru Nagar area."
                      },
                      {
                          "date_time": "2024-02-20T05:55:10+0000",
                          "message": "Focus on more electric buses to reduce rising pollution"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-20T05:55:44+0000",
                          "message": "Last mile connectivity from metro stations required."
                      },
                      {
                          "date_time": "2024-02-20T19:20:21+0000",
                          "message": "\u092a\u093f\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921\u093c \u0906\u092f\u0942\u0915\u094d\u0924 \u0936\u0947\u0916\u0930 \u0938\u093f\u0902\u0939 \u0938\u093e\u0939\u0947\u092c \u0935\u093e\u0932\u094d\u0939\u0947\u0915\u0935\u093e\u0921\u0940 \u0917\u0942\u0930\u0942\u0935\u094d\u0926\u093e\u0930\u093e \u0930\u094b\u0921  \u092e\u092e\u0940\u0932\u0940 \u091a\u094c\u0915  \u0938\u0930\u094d\u0935\u0947 \u0928\u092c\u0930 126. \u092f\u093e \u0920\u093f\u0915\u093e\u0923\u0940 PMRDA \u0905\u0930\u0915\u094d\u0937\u093f\u0924 \u091c\u093e\u0917\u0947 \u092e\u0927\u094d\u092f\u0947 \u0935\u093f\u0930\u0917\u0942\u0933\u093e \u0915\u0947\u0926\u094d\u0930 \u0906\u0930\u0915\u094d\u0937\u093f\u0924 \u0905\u0938\u0924\u093e\u0928\u0940 \u092a\u0923 \u0924\u094d\u092f\u093e \u0920\u093f\u0915\u093e\u0923\u0940 \u0938\u094d\u0925\u093e\u0928\u0940\u0915 \u092c\u093f\u0932\u094d\u0921\u0930 \u0915\u0921\u0942\u0928 \u0915\u093e\u0939\u0940 \u0905\u0927\u093f\u0915\u093e\u0930\u0940 \u092f\u093e\u0928\u093e \u092e\u0945\u0928\u0947\u091c \u0915\u0930\u0942\u0928  \u0938\u0930\u094d\u0935\u0947 \u0928\u0902\u092c\u0930 126 \u092f\u093e \u0915\u092e\u0930\u094d\u0936\u093f\u092f\u0932 \u092c\u093f\u0932\u094d\u0921\u093f\u0902\u0917 \u090a\u092d\u093e \u0930\u093e\u0939\u093f\u0932\u0940 \u0906\u0939\u0947 \u0939\u093f \u091c\u093e\u0917\u093e \u092e\u0939\u093e\u0928\u0917\u0930 \u092a\u093e\u0932\u0940\u0915\u0947\u0928\u0947 \u0924\u093e\u092c\u094d\u092f\u093e \u092e\u0927\u094d\u092f\u0947 \u0918\u0947\u090a\u0928 \u092f\u094b\u0917\u094d\u092f \u0924\u093f \u0915\u093e\u0930\u0935\u093e\u0908 \u091d\u093e\u0932\u0940\u091a \u092a\u093e\u0939\u0940\u091c\u0947 \u0924\u0938\u0947\u091a \u0938\u0930\u094d\u0935\u0947 \u0928\u092c\u0930 133  \u092e\u0927\u0940 \u092a\u0923  \u092f\u093e \u0938\u0930\u094d\u0935\u0947 \u0928\u0902\u092c\u0930 \u092e\u0927\u093f \u092a\u0923 PMRDA \u091c\u093e\u0917\u093e \u0905\u0930\u0915\u094d\u0937\u093f\u0924 \u0906\u0939\u0947 \u0924\u093f\u0925 \u092a\u0923 \u0915\u093e\u0930\u0935\u093e\u0908 \u0935\u094d\u0939\u093e\u092f\u0932\u093e \u0939\u0935\u0940 \u091c\u092f \u092e\u0939\u093e\u0930\u093e\u0937\u094d\u091f\u094d\u0930"
                      }
                  ]
              },
              "reports": {
                  "positive": "52.63",
                  "negative": "5.26",
                  "neutral": "42.11"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-14T14:58:03+0000",
                  "message": "#PCMC \u0924\u0930\u094d\u092b\u0947 \u0926\u093f. \u0967\u096b \u0924\u0947 \u0967\u096f \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0926\u0930\u092e\u094d\u092f\u093e\u0928 \u091b\u0924\u094d\u0930\u092a\u0924\u0940 \u0936\u093f\u0935\u093e\u091c\u0940 \u092e\u0939\u093e\u0930\u093e\u091c \u0935\u093f\u091a\u093e\u0930 \u092a\u094d\u0930\u092c\u094b\u0927\u0928 \u092a\u0930\u094d\u0935 \u0968\u0966\u0968\u096a \u0906\u092f\u094b\u091c\u093f\u0924 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u092f\u0947\u0924 \u0906\u0939\u0947.\n\n\u0939\u093e \u0910\u0924\u093f\u0939\u093e\u0938\u093f\u0915 \u0938\u094b\u0939\u0933\u093e \u0905\u0928\u0941\u092d\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092c\u0939\u0941\u0938\u0902\u0916\u094d\u092f\u0947\u0928\u0947 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u0939\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940!\n\n#\u0936\u093f\u0935\u091c\u092f\u0902\u0924\u0940",
                  "id": "477167415712554_711275481177795"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "52.63",
                  "negative": "5.26",
                  "neutral": "42.11"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-10T15:07:26+0000",
                  "message": "\u0935\u093f\u0915\u0938\u093f\u0924 \u092d\u093e\u0930\u0924 \u0938\u0902\u0915\u0932\u094d\u092a \u092f\u093e\u0924\u094d\u0930\u093e - \u0936\u0939\u0930\u0940 \u092e\u094b\u0939\u0940\u092e \n\n\u0909\u0926\u094d\u092f\u093e \u0926\u093f. \u0967\u0967 \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0930\u094b\u091c\u0940 \u0906\u092f\u0908\u0938\u0940 \u092e\u094b\u092c\u093e\u0908\u0932 \u0925\u093f\u090f\u091f\u0930 \u0935\u094d\u0939\u0945\u0928 \u092a\u094d\u0930\u093e\u0925\u092e\u093f\u0915 \u0936\u093e\u0933\u093e, \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0947 \u0938. \u0967\u0966 \u0935\u093e. \u0935 \u092a\u093e\u0923\u094d\u092f\u093e\u091a\u094d\u092f\u093e \u091f\u093e\u0915\u0940\u091c\u0935\u0933, \u091a\u0915\u094d\u0930\u092a\u093e\u0923\u0940 \u0935\u0938\u093e\u0939\u0924, \u092d\u094b\u0938\u0930\u0940 \u092f\u0947\u0925\u0947 \u0926\u0941. \u0969 \u0935\u093e \u092f\u0947\u0923\u093e\u0930 \u0906\u0939\u0947. \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092f\u093e\u0935\u0947\u0933\u0940 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u093e\u0939\u0942\u0928 \u0935\u093f\u0935\u093f\u0927 \u092f\u094b\u091c\u0928\u093e\u0902\u091a\u093e \u0932\u093e\u092d \u0918\u094d\u092f\u093e\u0935\u093e \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940.\n\n#ViksitBharatSankalpYatra\n#PCMC",
                  "id": "477167415712554_708842108087799"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [
                      {
                          "date_time": "2024-02-10T15:19:19+0000",
                          "message": "\u092e\u094b\u0926\u0940 \u0938\u0930\u0915\u093e\u0930 \u091a\u093e \u092a\u094d\u0930\u091a\u093e\u0930 \u0906\u0924\u093e \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0915\u0930\u0923\u093e\u0930 \u0915\u093e??  \u0915\u093f\u092e\u093e\u0928 \u0928\u093e\u0935 \u0924\u0930\u0940 \u0926\u0947\u0936\u093e\u091a\u0902 \u0935\u093e\u092a\u0930\u093e ,\u092e\u094b\u0926\u0940 \u092e\u094d\u0939\u0923\u091c\u0947 \u0926\u0947\u0936 \u0928\u093e\u0939\u0940 \u091c\u0930\u093e \u092d\u093e\u0928\u093e\u0935\u0930 \u092f\u093e \u092a\u093e\u0932\u093f\u0915\u093e \u092a\u094d\u0930\u0936\u093e\u0938\u0928"
                      }
                  ],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-10T15:21:10+0000",
                          "message": "\u0906\u0924\u093e\u092a\u0930\u094d\u092f\u0902\u0924 \u0926\u093f\u0932\u0947\u0932\u094d\u092f\u093e \u0917\u0945\u0930\u0902\u091f\u094d\u092f\u093e\u091a \u0915\u093e\u092f \u091d\u093e\u0932\u0902 \u0924\u0947 \u092a\u0923 \u0938\u093e\u0902\u0917\u093e\u092f\u0932\u093e \u0935\u093f\u0938\u0930\u0942 \u0928\u0915\u093e \u092e\u094d\u0939\u0923\u091c\u0947 \u091d\u093e\u0932\u0902"
                      }
                  ]
              },
              "reports": {
                  "positive": "47.62",
                  "negative": "9.52",
                  "neutral": "42.86"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-07T07:02:43+0000",
                  "message": "On #WorldCancerDay, Pimpri Chinchwad Municipal corporation's creative anti-tobacco campaign converts red stains into brilliant rangoli, encouraging a tobacco-free lifestyle and cleanliness.\n\nEnergetic rallies advocate for health and environmental beauty, mobilising residents to create a healthier neighbourhood.\n\nAdopting a tobacco-free lifestyle and promoting cleanliness to create a healthier, cleaner community.\n#SwachhBharatGov \n#MissionLiFE \n#MajhiVasundharaAbhiyan4 \n#MaharashtraDGIPR \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \n#SwachhBharatMissionUrban \n#SafaiMitraSuraksha \nMajhi Vasundhara \nSwachh Bharat Mission - Urban \nMinistry of Housing and Urban Affairs \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_706832468288763"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-07T08:00:49+0000",
                          "message": "\u0938\u094d\u0935\u091a\u094d\u091b PCMC \u0938\u0941\u0902\u0926\u0930 PCMC"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "9.09",
                  "neutral": "40.91"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-02T03:13:21+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1149063529410415"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-02T03:43:00+0000",
                          "message": "Extat spot"
                      },
                      {
                          "date_time": "2024-02-02T05:33:13+0000",
                          "message": "Army rowing node Nashik phata in Pune kasarwadi"
                      },
                      {
                          "date_time": "2024-02-02T05:55:19+0000",
                          "message": "Abhi he"
                      },
                      {
                          "date_time": "2024-02-02T03:42:48+0000",
                          "message": "Spardha kuth ahet"
                      },
                      {
                          "date_time": "2024-02-02T05:55:37+0000",
                          "message": "Just start hogi"
                      }
                  ]
              },
              "reports": {
                  "positive": "40.74",
                  "negative": "7.41",
                  "neutral": "51.85"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-01T02:21:24+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_933574645151535"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-01T02:34:15+0000",
                          "message": "Punya madhe training center kuth ahe"
                      },
                      {
                          "date_time": "2024-02-01T05:17:07+0000",
                          "message": "Congratulations\ud83c\udf89"
                      },
                      {
                          "date_time": "2024-02-01T04:55:50+0000",
                          "message": "CME DAPODI"
                      }
                  ]
              },
              "reports": {
                  "positive": "36.67",
                  "negative": "6.67",
                  "neutral": "56.67"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-31T11:05:57+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_906025557567804"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T11:07:33+0000",
                          "message": "Haa soyal"
                      },
                      {
                          "date_time": "2024-01-31T11:08:40+0000",
                          "message": "Kya hua"
                      }
                  ]
              },
              "reports": {
                  "positive": "34.38",
                  "negative": "6.25",
                  "neutral": "59.38"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-31T02:15:56+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_764377222385020"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T05:19:05+0000",
                          "message": "Chal Bhai Tarun \ud83d\udd25"
                      },
                      {
                          "date_time": "2024-01-31T03:49:13+0000",
                          "message": "\ud83d\udc4c\ud83d\udc4c"
                      }
                  ]
              },
              "reports": {
                  "positive": "32.35",
                  "negative": "5.88",
                  "neutral": "61.76"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T12:12:40+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1345383646150642"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T14:39:08+0000",
                          "message": "Available *100% Original Protein and Supplements @ \n *KALYANI NAGAR* \n *Next to Gold Gym,*\n& 3M Car Care.\n9423218811\n www.mynutrify.com\n *Free Home Delivery in all over Pune*\n\n *Some products having Special Offer!* \ud83c\udf89\u2728 Buy any protein or gainer , and receive a complimentary shaker bottle! Limited time deal, grab yours now! \ud83d\udcaa\ud83c\udffc"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "34.29",
                  "negative": "5.71",
                  "neutral": "60.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T06:20:56+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0938\u0902\u092f\u0941\u0915\u094d\u0924 \u0935\u093f\u0926\u094d\u092f\u092e\u093e\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966  \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0926\u093f. \u0968\u096d \u091c\u093e\u0928\u0947\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0930\u094b\u091c\u0940 \u0915\u0947 \u090f\u0938 \u092c\u0940 \u091a\u094c\u0915 \u0924\u0947 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938  \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u092a\u094d\u0932\u0949\u0917\u0947\u0925\u0949\u0928 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940, \u092f\u093e\u092e\u0927\u094d\u092f\u0947 \u092e\u0939\u093e\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u0947 \u0938\u0930\u094d\u0935 \u0905\u0927\u093f\u0915\u093e\u0930\u0940, \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0935 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u092f\u093e\u0902\u091a\u0947 \u0967\u0966\u0966 \u0938\u094d\u0935\u092f\u0902\u0938\u0947\u0935\u0915 \u0938\u0939\u092d\u093e\u0917\u0940 \u091d\u093e\u0932\u0947 \u0939\u094b\u0924\u0947. \n#SwachhBharatGov \n#MissionLiFE \n#MaharashtraDGIPR \n#MajhiVasundharaAbhiyan4 \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs \nSwachh Bharat Mission - Urban \nCMOMaharashtra",
                  "id": "477167415712554_701969138775096"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-31T15:53:35+0000",
                          "message": "Great"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "36.11",
                  "negative": "5.56",
                  "neutral": "58.33"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T06:16:34+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e\u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0968\u096c \u091c\u093e\u0928\u0947\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0930\u094b\u091c\u0940 \u0938\u094d\u0915\u093e\u092f \u0938\u094d\u0915\u093e\u092f\u092a\u0930 \u0938\u094b\u0938\u093e\u092f\u091f\u0940 \u0924\u0925\u093e\u0935\u0921\u0947 \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u092a\u094d\u0932\u0949\u0917\u0947\u0925\u0949\u0928 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940. \nOn behalf of Pimpri Chinchwad Municipal Corporation, a Plogathon was conducted on 26th January 2024 by Sky Skipper Society in Tathavade area under Swachh Survekshan 2024 and Majhi Vasundhara Mission 4.0.\n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#SwachhBharatMissionUrban  \n#SafaimitraSurakshaChallenge  \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nSwachh Bharat Mission - Urban \nMajhi Vasundhara  \nSwachh Maharashtra Mission -Urban  \nMinistry of Housing and Urban Affairs",
                  "id": "477167415712554_701966738775336"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T13:08:36+0000",
                          "message": "Pimpri Chinchwad Municipal Corporation \u0932\u094b\u0915\u0947\u0936\u0928 \u0924\u093e\u0925\u0935\u0921\u0947 \u0928\u0938\u0941\u0928 \u0928\u093f\u0917\u0921\u0940 \u092a\u094d\u0930\u093e\u0927\u093f\u0915\u0930\u0923 \u0906\u0939\u0947."
                      }
                  ]
              },
              "reports": {
                  "positive": "35.14",
                  "negative": "5.41",
                  "neutral": "59.46"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T03:30:33+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_245662221913687"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T03:58:59+0000",
                          "message": "Best of luck all Rower's"
                      },
                      {
                          "date_time": "2024-01-30T07:01:01+0000",
                          "message": "Love \u2764"
                      },
                      {
                          "date_time": "2024-01-30T05:13:14+0000",
                          "message": "Nice"
                      },
                      {
                          "date_time": "2024-01-30T03:57:35+0000",
                          "message": "Nice"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T06:45:39+0000",
                          "message": "Jai mp \ud83d\udd25\ud83d\udd25\ud83d\udd25\ud83d\udd25\ud83d\udd25"
                      },
                      {
                          "date_time": "2024-01-30T05:52:06+0000",
                          "message": "Thanks for live"
                      },
                      {
                          "date_time": "2024-01-30T03:37:24+0000",
                          "message": "Venue?"
                      },
                      {
                          "date_time": "2024-01-30T06:01:25+0000",
                          "message": "Single mai Punjab ka kya hua"
                      },
                      {
                          "date_time": "2024-01-30T05:51:20+0000",
                          "message": "Hlo bro"
                      },
                      {
                          "date_time": "2024-01-30T05:51:55+0000",
                          "message": "Commatery mai team ka confirm kar do"
                      },
                      {
                          "date_time": "2024-01-30T08:17:00+0000",
                          "message": "Hlo"
                      },
                      {
                          "date_time": "2024-01-30T09:02:07+0000",
                          "message": "Last 750 pe"
                      },
                      {
                          "date_time": "2024-01-30T09:01:49+0000",
                          "message": "Baki teams ko bhi dekya karo fir army walo ko kue dekyte ho"
                      }
                  ]
              },
              "reports": {
                  "positive": "34.00",
                  "negative": "4.00",
                  "neutral": "62.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T16:54:36+0000",
                  "message": "Rowers, Are you ready?\n\nGet ready to experience the thrill and adventure!\n\n\u0930\u094b\u0935\u094d\u0939\u0930\u094d\u0938, \u0924\u0941\u092e\u094d\u0939\u0940 \u0924\u092f\u093e\u0930 \u0906\u0939\u093e\u0924 \u0915\u093e?\n\n\u0930\u094b\u092e\u093e\u0902\u091a\u0915 \u0930\u094b\u0908\u0902\u0917 \u0905\u0928\u0941\u092d\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0938\u091c\u094d\u091c \u0935\u094d\u0939\u093e!\n\n#RowingChampionship #PCMC",
                  "id": "477167415712554_701646018807408"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T10:19:39+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "35.29",
                  "negative": "3.92",
                  "neutral": "60.78"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T11:30:27+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_415611457692116"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-29T11:52:56+0000",
                          "message": "Good to see the event"
                      },
                      {
                          "date_time": "2024-01-30T02:26:23+0000",
                          "message": "The Indian Senior Rowing nationals have started, all the very best to all involved as I am still based in O.Z. Coach P."
                      },
                      {
                          "date_time": "2024-01-30T02:17:03+0000",
                          "message": "So very proud of you all:)"
                      },
                      {
                          "date_time": "2024-01-29T11:36:45+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T07:24:01+0000",
                          "message": "W4 heats"
                      }
                  ]
              },
              "reports": {
                  "positive": "39.29",
                  "negative": "3.57",
                  "neutral": "57.14"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T03:21:36+0000",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_720860216470673"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-29T03:40:04+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "40.35",
                  "negative": "3.51",
                  "neutral": "56.14"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-27T04:56:51+0000",
                  "message": "\u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u0915\u0943\u092a\u092f\u093e \u0928\u094b\u0902\u0926 \u0918\u094d\u092f\u093e\u0935\u0940 \u0935 \u0938\u0939\u0915\u093e\u0930\u094d\u092f \u0915\u0930\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940.\n\n#PCMC #WaterSupply",
                  "id": "477167415712554_700114308960579"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-27T05:28:17+0000",
                          "message": "\u0927\u0928\u094d\u092f\u0935\u093e\u0926"
                      }
                  ]
              },
              "reports": {
                  "positive": "39.66",
                  "negative": "3.45",
                  "neutral": "56.90"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-27T04:43:16+0000",
                  "message": "\u091c\u0917\u0926\u094d\u0917\u0941\u0930\u0942 \u0938\u0902\u0924 \u0924\u0941\u0915\u093e\u0930\u093e\u092e \u092e\u0939\u093e\u0930\u093e\u091c \u0938\u0902\u0924\u092a\u0940\u0920 \u092a\u094d\u0930\u0935\u0947\u0936 \u0938\u094b\u0921\u0924 \u092a\u094d\u0930\u0915\u094d\u0930\u093f\u092f\u093e \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1825970254521333"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-27T05:40:57+0000",
                          "message": "Awaj"
                      },
                      {
                          "date_time": "2024-01-27T12:08:53+0000",
                          "message": "\u092c\u0939\u0941\u0924 \u092c\u0922\u093c\u093f\u092f\u093e \u0914\u0930 \u0938\u0924\u094d\u092f\u0964"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-27T06:29:47+0000",
                          "message": "\ud83d\udc4d"
                      },
                      {
                          "date_time": "2024-01-27T10:43:24+0000",
                          "message": "\ud83d\ude4f\ud83d\ude4f\ud83d\ude4f"
                      },
                      {
                          "date_time": "2024-01-27T06:50:26+0000",
                          "message": "\ud83d\udc4d"
                      },
                      {
                          "date_time": "2024-01-27T06:55:43+0000",
                          "message": "\ud83d\udc4d\ud83d\udc46\ud83d\udc4c\ud83d\udc4c"
                      },
                      {
                          "date_time": "2024-01-27T06:54:19+0000",
                          "message": "Thanks \ud83d\ude4f\ud83d\ude4f\ud83d\ude4f"
                      },
                      {
                          "date_time": "2024-01-27T05:56:11+0000",
                          "message": "\ud83d\udc4c\ud83d\udc4c\ud83d\udc4c\ud83d\udc4c"
                      }
                  ]
              },
              "reports": {
                  "positive": "37.88",
                  "negative": "3.03",
                  "neutral": "59.09"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-24T09:40:31+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e \u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0936\u094d\u0930\u0940 \u0938\u0902\u0924 \u0936\u093f\u0930\u094b\u092e\u0923\u0940 \u0938\u093e\u0935\u0924\u093e \u092e\u0939\u093e\u0930\u093e\u091c \u0909\u0926\u094d\u092f\u093e\u0928, \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0947 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u093f\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n\nOn behalf of Pimpri Chinchwad Municipal Corporation, a cleanliness campaign was conducted at Sri Sant Shiromani Savata Maharaj Udyan, Jadhavwadi under Swachh Survekshan 2024 and Majhi Vasundhara Mission 4.0.\n#SwachhBharatGov \n#MissionLiFE \n#MaharashtraDGIPR \n#MajhiVasundharaAbhiyan4 \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \n@majhivasundharaabhiyan_4.0 \n@mohua__india \n@sbmurbangov \n@cmomaharashtra_",
                  "id": "477167415712554_698458935792783"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T09:22:33+0000",
                          "message": "\u091c\u0917\u0924\u093e\u092a \u0928\u0917\u0930 \u0932\u0947\u0928 \u0928 6 \u092e\u0927\u094d\u092f\u0947 \u0915\u093f\u0924\u0940 \u0924\u0915\u094d\u0930\u093e\u0930\u0940 \u0915\u0947\u0932\u094d\u092f\u093e \u0924\u0930\u0940 \u0915\u091a\u0930\u093e \u0909\u091a\u0932\u0924 \u0928\u093e\u0939\u0940\u0924 \u092f\u0947\u0925\u0940\u0932 \u0932\u094b\u0915 \u0925\u0902\u0921\u0940 \u0924\u093e\u092a \u092e\u0941\u0933\u0947 \u0906\u091c\u093e\u0930\u0940 \u092a\u0921\u0932\u0947 \u0906\u0939\u0947\u0924 . \n\u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092b\u0915\u094d\u0924 \u091c\u093e\u0939\u093f\u0930\u093e\u0924\u0940 \u092e\u0927\u094d\u092f\u0947 \u092a\u093e\u0932\u093f\u0915\u093e \u0926\u093e\u0916\u0935\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937\u093e\u0924 \u0915\u093f\u0924\u0940\u0924\u0930\u0940 \u0936\u0939\u0930\u093e\u0924 \u0915\u091a\u0930\u093e \u091c\u093e\u0917\u094b\u091c\u093e\u0917\u0940 \u0906\u0939\u0947"
                      }
                  ]
              },
              "reports": {
                  "positive": "37.31",
                  "negative": "2.99",
                  "neutral": "59.70"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-24T06:11:29+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e \u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0906\u0923\u093f \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0936\u093f\u0935\u0938\u0943\u0937\u094d\u091f\u0940 \u092a\u093e\u0930\u094d\u0915, \u0921\u093e\u0902\u0917\u0947 \u091a\u094c\u0915 \u092f\u0947\u0925\u0940\u0932 \u0909\u0926\u094d\u092f\u093e\u0928 \u0906\u0923\u093f \u0909\u0926\u094d\u092f\u093e\u0928\u093e\u091a\u094d\u092f\u093e \u0906\u0924\u0940\u0932 \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u093f\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\nOn behalf of the Pimpri Chinchwad Municipal Corporation, a cleanliness drive was carried out under Swachh Survekshan 2024 and Majhi Vasundhara Abhiyan 4.0 in Shivshristi Park, Dange Chowk and the park and the inner area of \u200b\u200bthe park.\n#SwachhBharatGov \n#SwachhSurvekshan2024Maharashtra \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhSurvekshan2024 \n#SwachhBharatMissionUrban \nMinistry of Housing and Urban Affairs \nMajhi Vasundhara \nSwachh Bharat Mission - Urban \nHardeep Singh Puri",
                  "id": "477167415712554_698388422466501"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T12:45:40+0000",
                          "message": "\u0938\u094d\u0935\u091a\u094d\u091b\u0924\u0947\u091a\u094d\u092f\u093e \u092e\u0939\u093e\u0928\u0917\u0930 \u092a\u093e\u0932\u093f\u0915\u093e \u092b\u0915\u094d\u0924 \u092c\u093e\u0924\u093e \u092e\u093e\u0930\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937\u093e\u0924 \u0936\u0939\u0930\u093e\u0924 \u0920\u0940\u0915 \u0920\u093f\u0915\u093e\u0923\u0940 \u0905\u0928\u0947\u0915 \u0920\u093f\u0915\u093e\u0923\u0940 \u0915\u091a\u0931\u094d\u092f\u093e\u091a\u0947 \u0922\u0940\u0917 \u0906\u0939\u0947. \u0935\u093e\u0930\u0902\u0935\u093e\u0930 \u0924\u0915\u094d\u0930\u093e\u0930 \u0915\u0930\u0942\u0928 \u0938\u0941\u0926\u094d\u0927\u093e \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0916\u0941\u0930\u094d\u091a\u0940\u0935\u0930 \u092c\u0938\u0942\u0928 \u0930\u093e\u0939\u0924\u093e\u0924\n\u092f\u093e\u091a\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937 \u0909\u0926\u093e\u0939\u0930\u0923 \u0917 \u092a\u094d\u0930\u092d\u093e\u0917 \u091c\u0917\u0924\u093e\u092a \u0928\u0917\u0930 \u0932\u0947\u0928 \u0928 6 \u092a\u093e\u0936\u0940\u0932 \u0928\u093e\u0932\u094d\u092f\u093e\u091a\u0947 \u0938\u093e\u0902\u0921\u092a\u093e\u0923\u0940 \u092e\u0941\u0933\u0947 \u0924\u0947\u0925\u0940\u0932 \u0928\u093e\u0917\u0930\u093f\u0915 \u0924\u093e\u092a \u0925\u0902\u0921\u0940\u0928\u0947 \u0917\u094d\u0930\u0938\u094d\u0924 \u0906\u0939\u0947\u0924 \u092a\u094d\u0930\u0936\u093e\u0938\u0928 \u0935\u093e\u0930\u0902\u0935\u093e\u0930 \u0938\u093e\u0902\u0917\u0942\u0928 \u0915\u091a\u0930\u093e \u0915\u093e\u0922\u0924 \u0928\u093e\u0939\u0940\u0924 \u092e\u0940\u0939\u0940 \u0905\u0928\u0947\u0915 \u0935\u0947\u0933\u093e \u0938\u093e\u0902\u0917\u093f\u0924\u0932\u0947 \u0938\u093e\u0930\u0925\u0940 \u0935\u0930 \u0924\u0915\u094d\u0930\u093e\u0930 \u0939\u0940 \u0915\u0947\u0932\u0940 \u092a\u0923 \u0915\u093e\u0939\u0940\u091a \u0915\u0930\u0924 \u0928\u093e\u0939\u0940 . \n\n\u092e\u0940 \u0924\u0930 \u090f\u0915\u091a \u0938\u0927\u094d\u092f\u093e \u092b\u094b\u091f\u094b \u0936\u0947\u092f\u0930 \u0915\u0930\u0924\u094b \u092c\u093e\u0915\u0940 \u0920\u093f\u0915\u093e\u0923\u0940 \u0915\u093e\u092f \u0905\u0935\u0938\u094d\u0925\u093e \u0905\u0938\u0947\u0932 \u0906\u092a\u0923\u091a \u0935\u093f\u091a\u093e\u0930 \u0915\u0930\u093e\u0935\u093e"
                      }
                  ]
              },
              "reports": {
                  "positive": "36.76",
                  "negative": "2.94",
                  "neutral": "60.29"
              }
          }
      ],
      "analysis_done_at": "02/27/2024, 16:06:34",
      "source": "FACEBOOK"
  },
  {
      "_id": "65ddb8bc2b1213c0cd2242c2",
      "account_name": "pcmc",
      "name": "Sentimental Analysis",
      "posts_with_comment_analysis": [
          {
              "post": {
                  "created_time": "2024-02-27T06:14:30+0000",
                  "message": "\u092e\u0939\u093e\u0930\u093e\u0937\u094d\u091f\u094d\u0930 \u0936\u093e\u0938\u0928\u093e\u091a\u094d\u092f\u093e \u0938\u093e\u0902\u0938\u094d\u0915\u0943\u0924\u093f\u0915 \u0915\u093e\u0930\u094d\u092f \u0935\u093f\u092d\u093e\u0917 \u0935 \u091c\u093f\u0932\u094d\u0939\u093e\u0927\u093f\u0915\u093e\u0930\u0940, \u092a\u0941\u0923\u0947 \u092f\u093e\u0902\u091a\u094d\u092f\u093e\u0924\u0930\u094d\u092b\u0947 \u0926\u093f.\u0968\u096e \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0924\u0947 \u0969 \u092e\u093e\u0930\u094d\u091a \u0926\u0930\u092e\u094d\u092f\u093e\u0928 \u092e\u0939\u093e\u0938\u0902\u0938\u094d\u0915\u0943\u0924\u0940 \u092e\u0939\u094b\u0924\u094d\u0938\u0935 \u0968\u0966\u0968\u096a \u0938\u093e\u0939\u093f\u0924\u094d\u092f\u0930\u0924\u094d\u0928 \u092a\u0941\u0923\u0947 \u091c\u093f\u0932\u094d\u0939\u094d\u092f\u093e\u0924\u0940\u0932 \u0935\u093f\u0935\u093f\u0927 \u0920\u093f\u0915\u093e\u0923\u0940 \u0906\u092f\u094b\u091c\u093f\u0924 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u093e \u0906\u0939\u0947.\n\n\u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092c\u0939\u0941\u0938\u0902\u0916\u094d\u092f\u0947\u0928\u0947 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u0939\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940!",
                  "id": "477167415712554_718200447151965"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-27T06:51:50+0000",
                          "message": "\u0938\u093e\u0939\u093f\u0924\u094d\u092f \u0930\u0924\u094d\u0928  \u0939\u0947 \u0920\u093f\u0915\u093e\u0923 \u0928\u0947\u092e\u0915\u0947 \u0915\u0941\u0920\u0947 \u0906\u0939\u0947"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-27T07:50:52+0000",
                          "message": "Pimpri Chinchwad Municipal Corporation \u0909\u0917\u093e\u091a \u092a\u094b\u0938\u094d\u091f \u0915\u0930\u093e\u092f\u091a\u0940 \u092e\u094d\u0939\u0923\u0941\u0928 \u0915\u0930\u0941 \u0928\u0915\u093e. \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u093e \u0924\u0940 \u092a\u094b\u0938\u094d\u091f \u0935\u093e\u091a\u0924\u093e \u092a\u0923 \u0906\u0932\u0940 \u092a\u093e\u0939\u093f\u091c\u0947 \u0939\u0940 \u0915\u093e\u0933\u091c\u0940 \u0918\u094d\u092f\u093e."
                      }
                  ]
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-27T04:23:59+0000",
                  "message": "\u0915\u0927\u0940 \u0938\u0939\u094d\u092f\u093e\u0926\u094d\u0930\u0940\u091a\u094d\u092f\u093e \u0921\u094b\u0902\u0917\u0930\u093e\u0924 \u0924\u0930 \u0915\u0927\u0940 \u0938\u0902\u0924\u093e\u0902\u091a\u094d\u092f\u093e \u0936\u092c\u094d\u0926\u093e\u0924, \n\u0915\u0927\u0940 \u0907\u0924\u093f\u0939\u093e\u0938\u093e\u091a\u094d\u092f\u093e \u092a\u093e\u0928\u093e\u0924 \u0924\u0930 \u0915\u0927\u0940 \u092f\u093e \u092d\u0942\u092e\u0940\u0935\u0930\u0940\u0932 \u092e\u093e\u0923\u0938\u093e\u0902\u091a\u094d\u092f\u093e \u092e\u0928\u093e\u0924!\n\n\u0906\u092e\u094d\u0939\u0940 \u0936\u094b\u0927\u0932\u0902, \u091c\u092a\u0932\u0902, \u0905\u0928\u0941\u092d\u0935\u0932\u0902 \u0906\u0939\u0947 \u092e\u0930\u093e\u0920\u0940\u092a\u0923...\n\n\u092e\u0930\u093e\u0920\u0940 \u092d\u093e\u0937\u093e \u0917\u094c\u0930\u0935 \u0926\u093f\u0928\u093e\u091a\u094d\u092f\u093e \u0939\u093e\u0930\u094d\u0926\u093f\u0915 \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e!\n\n#\u0917\u094c\u0930\u0935_\u092e\u0930\u093e\u0920\u0940\u091a\u093e #\u092e\u0930\u093e\u0920\u0940_\u092d\u093e\u0937\u093e_\u0917\u094c\u0930\u0935_\u0926\u093f\u0928 #PCMC",
                  "id": "477167415712554_718164153822261"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-23T10:46:35+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0938\u0948\u0928\u093f\u0915 \u092d\u0935\u0928, \u0926\u093f\u0918\u0940 \u092f\u0947\u0925\u0947 RRR \u0915\u0947\u0902\u0926\u094d\u0930  \u0909\u092d\u093e\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0947 \u0906\u0923\u093f \u092f\u093e\u092c\u093e\u092c\u0924 \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u091c\u0928\u091c\u093e\u0917\u0943\u0924\u0940 \u0926\u0947\u0916\u0940\u0932 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhSurvekshan2024 \n#SwachhSurvekshan2024Maharashtra \n#MissionLiFE \n#MajhiVasundharaAbhiyan4 \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \n#SwachhBharatGov \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs \nSwachh Bharat Mission - Urban \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_716114644027212"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-23T15:43:43+0000",
                          "message": "Good effort , keep it up \ud83d\udc4fLet me know if as a responsible citizen I can also help the community."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "66.67",
                  "negative": "0.00",
                  "neutral": "33.33"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-23T10:43:46+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0938\u0902\u0924 \u0917\u093e\u0921\u0917\u0947 \u092e\u0939\u093e\u0930\u093e\u091c \u091c\u092f\u0902\u0924\u0940 \u0928\u093f\u092e\u093f\u0924\u094d\u0924 \u0915\u093f\u0935\u0933\u0947 \u0935\u093f\u0915\u093e\u0938 \u0928\u0917\u0930 \u0930\u0939\u093f\u0935\u093e\u0936\u0940 \u0938\u0902\u0918 \u0906\u0923\u093f \u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0928\u092a\u093e \u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0938\u0902\u092f\u0941\u0915\u094d\u0924 \u0935\u093f\u0926\u094d\u092f\u092e\u093e\u0928\u0947 \u090f\u092e \u092c\u0940 \u0915\u0948\u0902\u092a \u0924\u0947 \u092e\u0941\u0915\u093e\u0908 \u091a\u094c\u0915 \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nSwachh Bharat Mission - Urban \nSwachh Maharashtra Mission -Urban \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs",
                  "id": "477167415712554_716113100694033"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-23T10:58:58+0000",
                          "message": "\u0905\u0924\u093f\u0936\u092f \u0938\u0941\u0902\u0926\u0930 \u0915\u093e\u092e \u0935 \u0928\u093f\u092f\u094b\u091c\u0928"
                      },
                      {
                          "date_time": "2024-02-25T03:47:05+0000",
                          "message": "Good effort on cleanliness..Our city PCMC should win 1st Prize this time in All India Ranking.We can beat Mysore and Indore also.Lets all citizen come together and help local government in their efforts.Also all citizens should maintain highest level of cleanliness near their home and offices."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "80.00",
                  "negative": "0.00",
                  "neutral": "20.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T17:03:42+0000",
                  "message": "\u092f\u0936\u0938\u094d\u0935\u0940 \u0915\u093e\u092e\u0917\u093f\u0930\u0940\u092c\u0926\u094d\u0926\u0932 \u0905\u092d\u093f\u0928\u0902\u0926\u0928!\n\n\u0907\u0902\u0921\u0938\u094d\u091f\u094d\u0930\u0940\u0905\u0932 \u0938\u094d\u092a\u094b\u0930\u094d\u091f\u0938 \u0905\u0938\u094b\u0938\u093f\u090f\u0936\u0928\u0924\u0930\u094d\u092b\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u091f\u0940-\u0968\u0966 \u0915\u094d\u0930\u093f\u0915\u0947\u091f \u0938\u094d\u092a\u0930\u094d\u0927\u0947\u091a\u094d\u092f\u093e \u0905\u0902\u0924\u093f\u092e \u0938\u093e\u092e\u0928\u094d\u092f\u093e\u0924 \u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u092a\u093e\u0932\u093f\u0915\u093e \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0915\u094d\u0930\u093f\u0915\u0947\u091f \u0938\u0902\u0918\u093e\u0928\u0947 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u0938\u0902\u0918\u093e\u0935\u0930 \u092e\u093e\u0924 \u0915\u0930\u0924 \u0935\u093f\u091c\u0947\u0924\u0947\u092a\u0926 \u092a\u091f\u0915\u093e\u0935\u0932\u0947. \n\n\u0935\u093f\u091c\u0947\u0924\u094d\u092f\u093e \u0938\u0902\u0918\u093e\u091a\u0947 \u0906\u092f\u0941\u0915\u094d\u0924 \u0924\u0925\u093e \u092a\u094d\u0930\u0936\u093e\u0938\u0915 \u0936\u0947\u0916\u0930 \u0938\u093f\u0902\u0939 \u092f\u093e\u0902\u0928\u0940 \u0915\u094c\u0924\u0941\u0915 \u0915\u0947\u0932\u0947 \u0905\u0938\u0941\u0928 \u092f\u0936\u093e\u092c\u0926\u094d\u0926\u0932 \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e\u0926\u0947\u0916\u0940\u0932 \u0926\u093f\u0932\u094d\u092f\u093e.\n\nThe winning fifer!\n\nThe #PCMC employee cricket team won the title by defeating the Tata Motors team in the final match of the T20 cricket tournament organized by the Industrial Sports Association.\n\n#WellPlayed #PCMCUpdates",
                  "id": "477167415712554_715206974117979"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-21T17:27:02+0000",
                          "message": "Congratulations all Tim"
                      },
                      {
                          "date_time": "2024-02-22T09:49:20+0000",
                          "message": "Wow... Congratulations \ud83d\udc4f \ud83d\udc4f \ud83d\udc4f \ud83c\udf89 \ud83c\udf89 Keep it"
                      }
                  ]
              },
              "reports": {
                  "positive": "57.14",
                  "negative": "0.00",
                  "neutral": "42.86"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T06:26:16+0000",
                  "message": "\u091c\u0936\u0940 \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u0947\u0935\u093f\u0937\u092f\u0940\u091a\u0940 \u0917\u094b\u0921\u0940 \u092e\u0928\u093e\u0924\u0942\u0928 \u0915\u0927\u0940\u0939\u0940 \u0938\u0902\u092a\u0924 \u0928\u093e\u0939\u0940 \u0924\u0938\u0947\u091a \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u0947\u0924\u0942\u0928 \u0936\u093f\u0915\u0932\u0947\u0932\u094d\u092f\u093e \u0917\u094b\u0937\u094d\u091f\u0940 \u0915\u0927\u0940\u0939\u0940 \u0935\u093f\u0938\u094d\u092e\u0930\u0923\u093e\u0924 \u091c\u093e\u0924 \u0928\u093e\u0939\u0940\u0924. \n\n\u091c\u093e\u0917\u0924\u093f\u0915 \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u093e \u0926\u093f\u0928\u093e\u091a\u094d\u092f\u093e \u0938\u0930\u094d\u0935\u093e\u0902\u0928\u093e \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e!\n\n#\u092e\u093e\u0924\u0943\u092d\u093e\u0937\u093e\n#InternationalMotherTongueDay",
                  "id": "477167415712554_714960150809328"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-21T10:43:53+0000",
                          "message": "\u0906\u0924\u093e \u0939\u094d\u092f\u093e \u0936\u0941\u092d\u0926\u093f\u0928\u0940 \u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0916\u093e\u0924\u094d\u092f\u093e\u091a\u0947 \u0928\u093e\u0935 \u092e\u0930\u093e\u0920\u0940\u0924 \u0915\u0930\u0942\u0928 \u091f\u093e\u0915\u093e"
                      },
                      {
                          "date_time": "2024-02-21T09:48:55+0000",
                          "message": "\u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0916\u093e\u0924\u094d\u092f\u093e\u091a\u0947 \u0928\u093e\u0935 \u0906\u092a\u0932\u094d\u092f\u093e \u092e\u093e\u092f\u092e\u0930\u093e\u0920\u0940 \u0915\u0930\u093e\n\n\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u2705\ud83d\ude0d"
                      }
                  ]
              },
              "reports": {
                  "positive": "44.44",
                  "negative": "0.00",
                  "neutral": "55.56"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T06:14:06+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u092e\u0928\u092a\u093e \u0936\u093e\u0933\u093e, \u0928\u0947\u0939\u0930\u0942\u0928\u0917\u0930  \u092f\u0947\u0925\u0947 \u092a\u0925\u0928\u093e\u091f\u094d\u092f\u093e\u091a\u094d\u092f\u093e \u092e\u093e\u0927\u094d\u092f\u092e\u093e\u0924\u0942\u0928 \u0935\u093f\u0926\u094d\u092f\u093e\u0930\u094d\u0925\u094d\u092f\u093e\u0902\u092e\u0927\u094d\u092f\u0947 (\u0913\u0932\u093e, \u0938\u0941\u0915\u093e, \u0938\u0945\u0928\u093f\u091f\u0930\u0940, \u0918\u0930\u0917\u0941\u0924\u0940 \u0918\u093e\u0924\u0915, \u092a\u094d\u0932\u093e\u0938\u094d\u091f\u093f\u0915) \u0905\u0936\u093e \u092a\u093e\u091a \u092a\u094d\u0930\u0915\u093e\u0930\u091a\u094d\u092f\u093e \u0915\u091a\u0930\u093e \u0935\u0930\u094d\u0917\u0940\u0915\u0930\u0923\u093e\u0935\u093f\u0937\u092f\u0940 \u091c\u0928\u091c\u093e\u0917\u0943\u0924\u0940 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940, \u0924\u0938\u0947\u091a \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u0947\u091a\u0940 \u0935 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u0947\u091a\u0940 \u0938\u093e\u092e\u0942\u0939\u093f\u0915 \u0936\u092a\u0925\u0939\u0940 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhSurvekshan2024 \n#SwachhSurvekshan2024Maharashtra \n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \nMajhi Vasundhara \nSwachh Bharat Mission - Urban  \nMinistry of Housing and Urban Affairs \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_714956687476341"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-21T06:31:00+0000",
                          "message": "We should all participate in Cleanliness as a community and make PCMC proud.All citizens should do their bit and should take onus to clean 100 sq foot area around their residence and office.This will infact help make INDIA cleaner."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T12:52:09+0000",
                  "message": "\u0936\u093f\u0915\u094d\u0937\u0923 \u0935\u093f\u0937\u092f\u0915 \u0938\u0941\u0935\u093f\u0927\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u0935\u093f\u0926\u094d\u092f\u093e\u0930\u094d\u0925\u0940-\u0936\u093f\u0915\u094d\u0937\u0915 \u092e\u0942\u0932\u094d\u092f\u093e\u0902\u0915\u0928, \u091c\u0932\u094d\u0932\u094b\u0937 \u0936\u093f\u0915\u094d\u0937\u0923\u093e\u091a\u093e, \u0905\u092d\u094d\u092f\u093e\u0938\u0926\u094c\u0930\u093e, \u0938\u092e\u0941\u092a\u0926\u0947\u0936\u0928 \u0905\u0938\u0947 \u0938\u092e\u093e\u0935\u0947\u0936 \u0906\u0939\u0947.\n\nProvision for Educational facilities include student-teacher assessment, Jallosh Shikshanacha, study tours & counselling, etc.\n\n#PCMCBudget2024_25",
                  "id": "477167415712554_714563887515621"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-21T06:35:47+0000",
                          "message": "Very good initiative"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "54.55",
                  "negative": "0.00",
                  "neutral": "45.45"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T12:23:42+0000",
                  "message": "\u0936\u0939\u0930\u093e\u091a\u094d\u092f\u093e \u0938\u094c\u0902\u0926\u0930\u094d\u092f\u093e\u0924 \u0935\u093e\u0922 \u0915\u0930\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0935 \u092e\u0941\u0932\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u092e\u0948\u0926\u093e\u0928\u0940 \u0916\u0947\u0933\u093e\u0902\u091a\u0940 \u0930\u0942\u091a\u0940 \u0935\u093e\u0922\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u092a\u0941\u0922\u0940\u0932 \u0924\u0930\u0924\u0941\u0926\u0940 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u094d\u092f\u093e \u0906\u0939\u0947\u0924.\n\nSaid provisions have been made to enhance the beauty of #PCMC & create interest in children for outdoor activities.\n\n#PCMCBudget2024_25",
                  "id": "477167415712554_714552077516802"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [
                      {
                          "date_time": "2024-02-20T14:35:24+0000",
                          "message": "Hmm, \u092a\u093f\u0902\u092a\u0933\u0947 \u0938\u094c\u0926\u093e\u0917\u0930 \u0932\u093e \u0917\u0930\u0940\u092c \u0932\u094b\u0915\u0902 \u0930\u093e\u0939\u0924\u093e\u0924, \u0924\u094d\u092f\u093e\u0902\u091a\u094d\u092f\u093e \u092e\u0941\u0932\u093e\u0902\u0938\u093e\u0920\u0940 \u0939\u094d\u092f\u093e\u091a\u093e \u092b\u093e\u092f\u0926\u093e\u091a \u0939\u094b\u0908\u0932"
                      }
                  ],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-20T12:56:02+0000",
                          "message": "\u092e\u094b\u0936\u0940 \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0940\u0932 \u0909\u0926\u094d\u092f\u093e\u0928\u0947 \u0915\u0927\u0940 \u0935\u093f\u0915\u0938\u093f\u0924 \u0939\u094b \u0939\u094b\u0923\u093e\u0930"
                      }
                  ]
              },
              "reports": {
                  "positive": "46.15",
                  "negative": "7.69",
                  "neutral": "46.15"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T05:30:30+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u0947 \u0905\u0902\u0926\u093e\u091c\u092a\u0924\u094d\u0930\u0915\u0968\u0966\u0968\u096a-\u0968\u0966\u0968\u096b \u0926\u093f.-\u0968\u0966 \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0938\u0915\u093e\u0933\u0940 \u0967\u0967\u0935\u093e...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_357852063796195"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-20T06:14:47+0000",
                          "message": "Very good budget...PCMC India"
                      },
                      {
                          "date_time": "2024-02-20T05:50:49+0000",
                          "message": "Good Budget...PCMC"
                      },
                      {
                          "date_time": "2024-02-20T05:53:23+0000",
                          "message": "Pls take care of senior citizens with more walking areas,parks, cycling tracks near Nehru Nagar area."
                      },
                      {
                          "date_time": "2024-02-20T05:55:10+0000",
                          "message": "Focus on more electric buses to reduce rising pollution"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-20T05:55:44+0000",
                          "message": "Last mile connectivity from metro stations required."
                      },
                      {
                          "date_time": "2024-02-20T19:20:21+0000",
                          "message": "\u092a\u093f\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921\u093c \u0906\u092f\u0942\u0915\u094d\u0924 \u0936\u0947\u0916\u0930 \u0938\u093f\u0902\u0939 \u0938\u093e\u0939\u0947\u092c \u0935\u093e\u0932\u094d\u0939\u0947\u0915\u0935\u093e\u0921\u0940 \u0917\u0942\u0930\u0942\u0935\u094d\u0926\u093e\u0930\u093e \u0930\u094b\u0921  \u092e\u092e\u0940\u0932\u0940 \u091a\u094c\u0915  \u0938\u0930\u094d\u0935\u0947 \u0928\u092c\u0930 126. \u092f\u093e \u0920\u093f\u0915\u093e\u0923\u0940 PMRDA \u0905\u0930\u0915\u094d\u0937\u093f\u0924 \u091c\u093e\u0917\u0947 \u092e\u0927\u094d\u092f\u0947 \u0935\u093f\u0930\u0917\u0942\u0933\u093e \u0915\u0947\u0926\u094d\u0930 \u0906\u0930\u0915\u094d\u0937\u093f\u0924 \u0905\u0938\u0924\u093e\u0928\u0940 \u092a\u0923 \u0924\u094d\u092f\u093e \u0920\u093f\u0915\u093e\u0923\u0940 \u0938\u094d\u0925\u093e\u0928\u0940\u0915 \u092c\u093f\u0932\u094d\u0921\u0930 \u0915\u0921\u0942\u0928 \u0915\u093e\u0939\u0940 \u0905\u0927\u093f\u0915\u093e\u0930\u0940 \u092f\u093e\u0928\u093e \u092e\u0945\u0928\u0947\u091c \u0915\u0930\u0942\u0928  \u0938\u0930\u094d\u0935\u0947 \u0928\u0902\u092c\u0930 126 \u092f\u093e \u0915\u092e\u0930\u094d\u0936\u093f\u092f\u0932 \u092c\u093f\u0932\u094d\u0921\u093f\u0902\u0917 \u090a\u092d\u093e \u0930\u093e\u0939\u093f\u0932\u0940 \u0906\u0939\u0947 \u0939\u093f \u091c\u093e\u0917\u093e \u092e\u0939\u093e\u0928\u0917\u0930 \u092a\u093e\u0932\u0940\u0915\u0947\u0928\u0947 \u0924\u093e\u092c\u094d\u092f\u093e \u092e\u0927\u094d\u092f\u0947 \u0918\u0947\u090a\u0928 \u092f\u094b\u0917\u094d\u092f \u0924\u093f \u0915\u093e\u0930\u0935\u093e\u0908 \u091d\u093e\u0932\u0940\u091a \u092a\u093e\u0939\u0940\u091c\u0947 \u0924\u0938\u0947\u091a \u0938\u0930\u094d\u0935\u0947 \u0928\u092c\u0930 133  \u092e\u0927\u0940 \u092a\u0923  \u092f\u093e \u0938\u0930\u094d\u0935\u0947 \u0928\u0902\u092c\u0930 \u092e\u0927\u093f \u092a\u0923 PMRDA \u091c\u093e\u0917\u093e \u0905\u0930\u0915\u094d\u0937\u093f\u0924 \u0906\u0939\u0947 \u0924\u093f\u0925 \u092a\u0923 \u0915\u093e\u0930\u0935\u093e\u0908 \u0935\u094d\u0939\u093e\u092f\u0932\u093e \u0939\u0935\u0940 \u091c\u092f \u092e\u0939\u093e\u0930\u093e\u0937\u094d\u091f\u094d\u0930"
                      }
                  ]
              },
              "reports": {
                  "positive": "52.63",
                  "negative": "5.26",
                  "neutral": "42.11"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-14T14:58:03+0000",
                  "message": "#PCMC \u0924\u0930\u094d\u092b\u0947 \u0926\u093f. \u0967\u096b \u0924\u0947 \u0967\u096f \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0926\u0930\u092e\u094d\u092f\u093e\u0928 \u091b\u0924\u094d\u0930\u092a\u0924\u0940 \u0936\u093f\u0935\u093e\u091c\u0940 \u092e\u0939\u093e\u0930\u093e\u091c \u0935\u093f\u091a\u093e\u0930 \u092a\u094d\u0930\u092c\u094b\u0927\u0928 \u092a\u0930\u094d\u0935 \u0968\u0966\u0968\u096a \u0906\u092f\u094b\u091c\u093f\u0924 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u092f\u0947\u0924 \u0906\u0939\u0947.\n\n\u0939\u093e \u0910\u0924\u093f\u0939\u093e\u0938\u093f\u0915 \u0938\u094b\u0939\u0933\u093e \u0905\u0928\u0941\u092d\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092c\u0939\u0941\u0938\u0902\u0916\u094d\u092f\u0947\u0928\u0947 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u0939\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940!\n\n#\u0936\u093f\u0935\u091c\u092f\u0902\u0924\u0940",
                  "id": "477167415712554_711275481177795"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "52.63",
                  "negative": "5.26",
                  "neutral": "42.11"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-10T15:07:26+0000",
                  "message": "\u0935\u093f\u0915\u0938\u093f\u0924 \u092d\u093e\u0930\u0924 \u0938\u0902\u0915\u0932\u094d\u092a \u092f\u093e\u0924\u094d\u0930\u093e - \u0936\u0939\u0930\u0940 \u092e\u094b\u0939\u0940\u092e \n\n\u0909\u0926\u094d\u092f\u093e \u0926\u093f. \u0967\u0967 \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0930\u094b\u091c\u0940 \u0906\u092f\u0908\u0938\u0940 \u092e\u094b\u092c\u093e\u0908\u0932 \u0925\u093f\u090f\u091f\u0930 \u0935\u094d\u0939\u0945\u0928 \u092a\u094d\u0930\u093e\u0925\u092e\u093f\u0915 \u0936\u093e\u0933\u093e, \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0947 \u0938. \u0967\u0966 \u0935\u093e. \u0935 \u092a\u093e\u0923\u094d\u092f\u093e\u091a\u094d\u092f\u093e \u091f\u093e\u0915\u0940\u091c\u0935\u0933, \u091a\u0915\u094d\u0930\u092a\u093e\u0923\u0940 \u0935\u0938\u093e\u0939\u0924, \u092d\u094b\u0938\u0930\u0940 \u092f\u0947\u0925\u0947 \u0926\u0941. \u0969 \u0935\u093e \u092f\u0947\u0923\u093e\u0930 \u0906\u0939\u0947. \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092f\u093e\u0935\u0947\u0933\u0940 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u093e\u0939\u0942\u0928 \u0935\u093f\u0935\u093f\u0927 \u092f\u094b\u091c\u0928\u093e\u0902\u091a\u093e \u0932\u093e\u092d \u0918\u094d\u092f\u093e\u0935\u093e \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940.\n\n#ViksitBharatSankalpYatra\n#PCMC",
                  "id": "477167415712554_708842108087799"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [
                      {
                          "date_time": "2024-02-10T15:19:19+0000",
                          "message": "\u092e\u094b\u0926\u0940 \u0938\u0930\u0915\u093e\u0930 \u091a\u093e \u092a\u094d\u0930\u091a\u093e\u0930 \u0906\u0924\u093e \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0915\u0930\u0923\u093e\u0930 \u0915\u093e??  \u0915\u093f\u092e\u093e\u0928 \u0928\u093e\u0935 \u0924\u0930\u0940 \u0926\u0947\u0936\u093e\u091a\u0902 \u0935\u093e\u092a\u0930\u093e ,\u092e\u094b\u0926\u0940 \u092e\u094d\u0939\u0923\u091c\u0947 \u0926\u0947\u0936 \u0928\u093e\u0939\u0940 \u091c\u0930\u093e \u092d\u093e\u0928\u093e\u0935\u0930 \u092f\u093e \u092a\u093e\u0932\u093f\u0915\u093e \u092a\u094d\u0930\u0936\u093e\u0938\u0928"
                      }
                  ],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-10T15:21:10+0000",
                          "message": "\u0906\u0924\u093e\u092a\u0930\u094d\u092f\u0902\u0924 \u0926\u093f\u0932\u0947\u0932\u094d\u092f\u093e \u0917\u0945\u0930\u0902\u091f\u094d\u092f\u093e\u091a \u0915\u093e\u092f \u091d\u093e\u0932\u0902 \u0924\u0947 \u092a\u0923 \u0938\u093e\u0902\u0917\u093e\u092f\u0932\u093e \u0935\u093f\u0938\u0930\u0942 \u0928\u0915\u093e \u092e\u094d\u0939\u0923\u091c\u0947 \u091d\u093e\u0932\u0902"
                      }
                  ]
              },
              "reports": {
                  "positive": "47.62",
                  "negative": "9.52",
                  "neutral": "42.86"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-07T07:02:43+0000",
                  "message": "On #WorldCancerDay, Pimpri Chinchwad Municipal corporation's creative anti-tobacco campaign converts red stains into brilliant rangoli, encouraging a tobacco-free lifestyle and cleanliness.\n\nEnergetic rallies advocate for health and environmental beauty, mobilising residents to create a healthier neighbourhood.\n\nAdopting a tobacco-free lifestyle and promoting cleanliness to create a healthier, cleaner community.\n#SwachhBharatGov \n#MissionLiFE \n#MajhiVasundharaAbhiyan4 \n#MaharashtraDGIPR \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \n#SwachhBharatMissionUrban \n#SafaiMitraSuraksha \nMajhi Vasundhara \nSwachh Bharat Mission - Urban \nMinistry of Housing and Urban Affairs \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_706832468288763"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-07T08:00:49+0000",
                          "message": "\u0938\u094d\u0935\u091a\u094d\u091b PCMC \u0938\u0941\u0902\u0926\u0930 PCMC"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "9.09",
                  "neutral": "40.91"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-02T03:13:21+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1149063529410415"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-02T03:43:00+0000",
                          "message": "Extat spot"
                      },
                      {
                          "date_time": "2024-02-02T05:33:13+0000",
                          "message": "Army rowing node Nashik phata in Pune kasarwadi"
                      },
                      {
                          "date_time": "2024-02-02T05:55:19+0000",
                          "message": "Abhi he"
                      },
                      {
                          "date_time": "2024-02-02T03:42:48+0000",
                          "message": "Spardha kuth ahet"
                      },
                      {
                          "date_time": "2024-02-02T05:55:37+0000",
                          "message": "Just start hogi"
                      }
                  ]
              },
              "reports": {
                  "positive": "40.74",
                  "negative": "7.41",
                  "neutral": "51.85"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-01T02:21:24+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_933574645151535"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-01T02:34:15+0000",
                          "message": "Punya madhe training center kuth ahe"
                      },
                      {
                          "date_time": "2024-02-01T05:17:07+0000",
                          "message": "Congratulations\ud83c\udf89"
                      },
                      {
                          "date_time": "2024-02-01T04:55:50+0000",
                          "message": "CME DAPODI"
                      }
                  ]
              },
              "reports": {
                  "positive": "36.67",
                  "negative": "6.67",
                  "neutral": "56.67"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-31T11:05:57+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_906025557567804"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T11:07:33+0000",
                          "message": "Haa soyal"
                      },
                      {
                          "date_time": "2024-01-31T11:08:40+0000",
                          "message": "Kya hua"
                      }
                  ]
              },
              "reports": {
                  "positive": "34.38",
                  "negative": "6.25",
                  "neutral": "59.38"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-31T02:15:56+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_764377222385020"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T05:19:05+0000",
                          "message": "Chal Bhai Tarun \ud83d\udd25"
                      },
                      {
                          "date_time": "2024-01-31T03:49:13+0000",
                          "message": "\ud83d\udc4c\ud83d\udc4c"
                      }
                  ]
              },
              "reports": {
                  "positive": "32.35",
                  "negative": "5.88",
                  "neutral": "61.76"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T12:12:40+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1345383646150642"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T14:39:08+0000",
                          "message": "Available *100% Original Protein and Supplements @ \n *KALYANI NAGAR* \n *Next to Gold Gym,*\n& 3M Car Care.\n9423218811\n www.mynutrify.com\n *Free Home Delivery in all over Pune*\n\n *Some products having Special Offer!* \ud83c\udf89\u2728 Buy any protein or gainer , and receive a complimentary shaker bottle! Limited time deal, grab yours now! \ud83d\udcaa\ud83c\udffc"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "34.29",
                  "negative": "5.71",
                  "neutral": "60.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T06:20:56+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0938\u0902\u092f\u0941\u0915\u094d\u0924 \u0935\u093f\u0926\u094d\u092f\u092e\u093e\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966  \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0926\u093f. \u0968\u096d \u091c\u093e\u0928\u0947\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0930\u094b\u091c\u0940 \u0915\u0947 \u090f\u0938 \u092c\u0940 \u091a\u094c\u0915 \u0924\u0947 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938  \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u092a\u094d\u0932\u0949\u0917\u0947\u0925\u0949\u0928 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940, \u092f\u093e\u092e\u0927\u094d\u092f\u0947 \u092e\u0939\u093e\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u0947 \u0938\u0930\u094d\u0935 \u0905\u0927\u093f\u0915\u093e\u0930\u0940, \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0935 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u092f\u093e\u0902\u091a\u0947 \u0967\u0966\u0966 \u0938\u094d\u0935\u092f\u0902\u0938\u0947\u0935\u0915 \u0938\u0939\u092d\u093e\u0917\u0940 \u091d\u093e\u0932\u0947 \u0939\u094b\u0924\u0947. \n#SwachhBharatGov \n#MissionLiFE \n#MaharashtraDGIPR \n#MajhiVasundharaAbhiyan4 \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs \nSwachh Bharat Mission - Urban \nCMOMaharashtra",
                  "id": "477167415712554_701969138775096"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-31T15:53:35+0000",
                          "message": "Great"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "36.11",
                  "negative": "5.56",
                  "neutral": "58.33"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T06:16:34+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e\u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0968\u096c \u091c\u093e\u0928\u0947\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0930\u094b\u091c\u0940 \u0938\u094d\u0915\u093e\u092f \u0938\u094d\u0915\u093e\u092f\u092a\u0930 \u0938\u094b\u0938\u093e\u092f\u091f\u0940 \u0924\u0925\u093e\u0935\u0921\u0947 \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u092a\u094d\u0932\u0949\u0917\u0947\u0925\u0949\u0928 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940. \nOn behalf of Pimpri Chinchwad Municipal Corporation, a Plogathon was conducted on 26th January 2024 by Sky Skipper Society in Tathavade area under Swachh Survekshan 2024 and Majhi Vasundhara Mission 4.0.\n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#SwachhBharatMissionUrban  \n#SafaimitraSurakshaChallenge  \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nSwachh Bharat Mission - Urban \nMajhi Vasundhara  \nSwachh Maharashtra Mission -Urban  \nMinistry of Housing and Urban Affairs",
                  "id": "477167415712554_701966738775336"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T13:08:36+0000",
                          "message": "Pimpri Chinchwad Municipal Corporation \u0932\u094b\u0915\u0947\u0936\u0928 \u0924\u093e\u0925\u0935\u0921\u0947 \u0928\u0938\u0941\u0928 \u0928\u093f\u0917\u0921\u0940 \u092a\u094d\u0930\u093e\u0927\u093f\u0915\u0930\u0923 \u0906\u0939\u0947."
                      }
                  ]
              },
              "reports": {
                  "positive": "35.14",
                  "negative": "5.41",
                  "neutral": "59.46"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T03:30:33+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_245662221913687"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T03:58:59+0000",
                          "message": "Best of luck all Rower's"
                      },
                      {
                          "date_time": "2024-01-30T07:01:01+0000",
                          "message": "Love \u2764"
                      },
                      {
                          "date_time": "2024-01-30T05:13:14+0000",
                          "message": "Nice"
                      },
                      {
                          "date_time": "2024-01-30T03:57:35+0000",
                          "message": "Nice"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T06:45:39+0000",
                          "message": "Jai mp \ud83d\udd25\ud83d\udd25\ud83d\udd25\ud83d\udd25\ud83d\udd25"
                      },
                      {
                          "date_time": "2024-01-30T05:52:06+0000",
                          "message": "Thanks for live"
                      },
                      {
                          "date_time": "2024-01-30T03:37:24+0000",
                          "message": "Venue?"
                      },
                      {
                          "date_time": "2024-01-30T06:01:25+0000",
                          "message": "Single mai Punjab ka kya hua"
                      },
                      {
                          "date_time": "2024-01-30T05:51:20+0000",
                          "message": "Hlo bro"
                      },
                      {
                          "date_time": "2024-01-30T05:51:55+0000",
                          "message": "Commatery mai team ka confirm kar do"
                      },
                      {
                          "date_time": "2024-01-30T08:17:00+0000",
                          "message": "Hlo"
                      },
                      {
                          "date_time": "2024-01-30T09:02:07+0000",
                          "message": "Last 750 pe"
                      },
                      {
                          "date_time": "2024-01-30T09:01:49+0000",
                          "message": "Baki teams ko bhi dekya karo fir army walo ko kue dekyte ho"
                      }
                  ]
              },
              "reports": {
                  "positive": "34.00",
                  "negative": "4.00",
                  "neutral": "62.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T16:54:36+0000",
                  "message": "Rowers, Are you ready?\n\nGet ready to experience the thrill and adventure!\n\n\u0930\u094b\u0935\u094d\u0939\u0930\u094d\u0938, \u0924\u0941\u092e\u094d\u0939\u0940 \u0924\u092f\u093e\u0930 \u0906\u0939\u093e\u0924 \u0915\u093e?\n\n\u0930\u094b\u092e\u093e\u0902\u091a\u0915 \u0930\u094b\u0908\u0902\u0917 \u0905\u0928\u0941\u092d\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0938\u091c\u094d\u091c \u0935\u094d\u0939\u093e!\n\n#RowingChampionship #PCMC",
                  "id": "477167415712554_701646018807408"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T10:19:39+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "35.29",
                  "negative": "3.92",
                  "neutral": "60.78"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T11:30:27+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_415611457692116"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-29T11:52:56+0000",
                          "message": "Good to see the event"
                      },
                      {
                          "date_time": "2024-01-30T02:26:23+0000",
                          "message": "The Indian Senior Rowing nationals have started, all the very best to all involved as I am still based in O.Z. Coach P."
                      },
                      {
                          "date_time": "2024-01-30T02:17:03+0000",
                          "message": "So very proud of you all:)"
                      },
                      {
                          "date_time": "2024-01-29T11:36:45+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T07:24:01+0000",
                          "message": "W4 heats"
                      }
                  ]
              },
              "reports": {
                  "positive": "39.29",
                  "negative": "3.57",
                  "neutral": "57.14"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T03:21:36+0000",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_720860216470673"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-29T03:40:04+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "40.35",
                  "negative": "3.51",
                  "neutral": "56.14"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-27T04:56:51+0000",
                  "message": "\u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u0915\u0943\u092a\u092f\u093e \u0928\u094b\u0902\u0926 \u0918\u094d\u092f\u093e\u0935\u0940 \u0935 \u0938\u0939\u0915\u093e\u0930\u094d\u092f \u0915\u0930\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940.\n\n#PCMC #WaterSupply",
                  "id": "477167415712554_700114308960579"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-27T05:28:17+0000",
                          "message": "\u0927\u0928\u094d\u092f\u0935\u093e\u0926"
                      }
                  ]
              },
              "reports": {
                  "positive": "39.66",
                  "negative": "3.45",
                  "neutral": "56.90"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-27T04:43:16+0000",
                  "message": "\u091c\u0917\u0926\u094d\u0917\u0941\u0930\u0942 \u0938\u0902\u0924 \u0924\u0941\u0915\u093e\u0930\u093e\u092e \u092e\u0939\u093e\u0930\u093e\u091c \u0938\u0902\u0924\u092a\u0940\u0920 \u092a\u094d\u0930\u0935\u0947\u0936 \u0938\u094b\u0921\u0924 \u092a\u094d\u0930\u0915\u094d\u0930\u093f\u092f\u093e \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1825970254521333"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-27T05:40:57+0000",
                          "message": "Awaj"
                      },
                      {
                          "date_time": "2024-01-27T12:08:53+0000",
                          "message": "\u092c\u0939\u0941\u0924 \u092c\u0922\u093c\u093f\u092f\u093e \u0914\u0930 \u0938\u0924\u094d\u092f\u0964"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-27T06:29:47+0000",
                          "message": "\ud83d\udc4d"
                      },
                      {
                          "date_time": "2024-01-27T10:43:24+0000",
                          "message": "\ud83d\ude4f\ud83d\ude4f\ud83d\ude4f"
                      },
                      {
                          "date_time": "2024-01-27T06:50:26+0000",
                          "message": "\ud83d\udc4d"
                      },
                      {
                          "date_time": "2024-01-27T06:55:43+0000",
                          "message": "\ud83d\udc4d\ud83d\udc46\ud83d\udc4c\ud83d\udc4c"
                      },
                      {
                          "date_time": "2024-01-27T06:54:19+0000",
                          "message": "Thanks \ud83d\ude4f\ud83d\ude4f\ud83d\ude4f"
                      },
                      {
                          "date_time": "2024-01-27T05:56:11+0000",
                          "message": "\ud83d\udc4c\ud83d\udc4c\ud83d\udc4c\ud83d\udc4c"
                      }
                  ]
              },
              "reports": {
                  "positive": "37.88",
                  "negative": "3.03",
                  "neutral": "59.09"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-24T09:40:31+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e \u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0936\u094d\u0930\u0940 \u0938\u0902\u0924 \u0936\u093f\u0930\u094b\u092e\u0923\u0940 \u0938\u093e\u0935\u0924\u093e \u092e\u0939\u093e\u0930\u093e\u091c \u0909\u0926\u094d\u092f\u093e\u0928, \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0947 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u093f\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n\nOn behalf of Pimpri Chinchwad Municipal Corporation, a cleanliness campaign was conducted at Sri Sant Shiromani Savata Maharaj Udyan, Jadhavwadi under Swachh Survekshan 2024 and Majhi Vasundhara Mission 4.0.\n#SwachhBharatGov \n#MissionLiFE \n#MaharashtraDGIPR \n#MajhiVasundharaAbhiyan4 \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \n@majhivasundharaabhiyan_4.0 \n@mohua__india \n@sbmurbangov \n@cmomaharashtra_",
                  "id": "477167415712554_698458935792783"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T09:22:33+0000",
                          "message": "\u091c\u0917\u0924\u093e\u092a \u0928\u0917\u0930 \u0932\u0947\u0928 \u0928 6 \u092e\u0927\u094d\u092f\u0947 \u0915\u093f\u0924\u0940 \u0924\u0915\u094d\u0930\u093e\u0930\u0940 \u0915\u0947\u0932\u094d\u092f\u093e \u0924\u0930\u0940 \u0915\u091a\u0930\u093e \u0909\u091a\u0932\u0924 \u0928\u093e\u0939\u0940\u0924 \u092f\u0947\u0925\u0940\u0932 \u0932\u094b\u0915 \u0925\u0902\u0921\u0940 \u0924\u093e\u092a \u092e\u0941\u0933\u0947 \u0906\u091c\u093e\u0930\u0940 \u092a\u0921\u0932\u0947 \u0906\u0939\u0947\u0924 . \n\u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092b\u0915\u094d\u0924 \u091c\u093e\u0939\u093f\u0930\u093e\u0924\u0940 \u092e\u0927\u094d\u092f\u0947 \u092a\u093e\u0932\u093f\u0915\u093e \u0926\u093e\u0916\u0935\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937\u093e\u0924 \u0915\u093f\u0924\u0940\u0924\u0930\u0940 \u0936\u0939\u0930\u093e\u0924 \u0915\u091a\u0930\u093e \u091c\u093e\u0917\u094b\u091c\u093e\u0917\u0940 \u0906\u0939\u0947"
                      }
                  ]
              },
              "reports": {
                  "positive": "37.31",
                  "negative": "2.99",
                  "neutral": "59.70"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-24T06:11:29+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e \u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0906\u0923\u093f \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0936\u093f\u0935\u0938\u0943\u0937\u094d\u091f\u0940 \u092a\u093e\u0930\u094d\u0915, \u0921\u093e\u0902\u0917\u0947 \u091a\u094c\u0915 \u092f\u0947\u0925\u0940\u0932 \u0909\u0926\u094d\u092f\u093e\u0928 \u0906\u0923\u093f \u0909\u0926\u094d\u092f\u093e\u0928\u093e\u091a\u094d\u092f\u093e \u0906\u0924\u0940\u0932 \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u093f\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\nOn behalf of the Pimpri Chinchwad Municipal Corporation, a cleanliness drive was carried out under Swachh Survekshan 2024 and Majhi Vasundhara Abhiyan 4.0 in Shivshristi Park, Dange Chowk and the park and the inner area of \u200b\u200bthe park.\n#SwachhBharatGov \n#SwachhSurvekshan2024Maharashtra \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhSurvekshan2024 \n#SwachhBharatMissionUrban \nMinistry of Housing and Urban Affairs \nMajhi Vasundhara \nSwachh Bharat Mission - Urban \nHardeep Singh Puri",
                  "id": "477167415712554_698388422466501"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T12:45:40+0000",
                          "message": "\u0938\u094d\u0935\u091a\u094d\u091b\u0924\u0947\u091a\u094d\u092f\u093e \u092e\u0939\u093e\u0928\u0917\u0930 \u092a\u093e\u0932\u093f\u0915\u093e \u092b\u0915\u094d\u0924 \u092c\u093e\u0924\u093e \u092e\u093e\u0930\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937\u093e\u0924 \u0936\u0939\u0930\u093e\u0924 \u0920\u0940\u0915 \u0920\u093f\u0915\u093e\u0923\u0940 \u0905\u0928\u0947\u0915 \u0920\u093f\u0915\u093e\u0923\u0940 \u0915\u091a\u0931\u094d\u092f\u093e\u091a\u0947 \u0922\u0940\u0917 \u0906\u0939\u0947. \u0935\u093e\u0930\u0902\u0935\u093e\u0930 \u0924\u0915\u094d\u0930\u093e\u0930 \u0915\u0930\u0942\u0928 \u0938\u0941\u0926\u094d\u0927\u093e \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0916\u0941\u0930\u094d\u091a\u0940\u0935\u0930 \u092c\u0938\u0942\u0928 \u0930\u093e\u0939\u0924\u093e\u0924\n\u092f\u093e\u091a\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937 \u0909\u0926\u093e\u0939\u0930\u0923 \u0917 \u092a\u094d\u0930\u092d\u093e\u0917 \u091c\u0917\u0924\u093e\u092a \u0928\u0917\u0930 \u0932\u0947\u0928 \u0928 6 \u092a\u093e\u0936\u0940\u0932 \u0928\u093e\u0932\u094d\u092f\u093e\u091a\u0947 \u0938\u093e\u0902\u0921\u092a\u093e\u0923\u0940 \u092e\u0941\u0933\u0947 \u0924\u0947\u0925\u0940\u0932 \u0928\u093e\u0917\u0930\u093f\u0915 \u0924\u093e\u092a \u0925\u0902\u0921\u0940\u0928\u0947 \u0917\u094d\u0930\u0938\u094d\u0924 \u0906\u0939\u0947\u0924 \u092a\u094d\u0930\u0936\u093e\u0938\u0928 \u0935\u093e\u0930\u0902\u0935\u093e\u0930 \u0938\u093e\u0902\u0917\u0942\u0928 \u0915\u091a\u0930\u093e \u0915\u093e\u0922\u0924 \u0928\u093e\u0939\u0940\u0924 \u092e\u0940\u0939\u0940 \u0905\u0928\u0947\u0915 \u0935\u0947\u0933\u093e \u0938\u093e\u0902\u0917\u093f\u0924\u0932\u0947 \u0938\u093e\u0930\u0925\u0940 \u0935\u0930 \u0924\u0915\u094d\u0930\u093e\u0930 \u0939\u0940 \u0915\u0947\u0932\u0940 \u092a\u0923 \u0915\u093e\u0939\u0940\u091a \u0915\u0930\u0924 \u0928\u093e\u0939\u0940 . \n\n\u092e\u0940 \u0924\u0930 \u090f\u0915\u091a \u0938\u0927\u094d\u092f\u093e \u092b\u094b\u091f\u094b \u0936\u0947\u092f\u0930 \u0915\u0930\u0924\u094b \u092c\u093e\u0915\u0940 \u0920\u093f\u0915\u093e\u0923\u0940 \u0915\u093e\u092f \u0905\u0935\u0938\u094d\u0925\u093e \u0905\u0938\u0947\u0932 \u0906\u092a\u0923\u091a \u0935\u093f\u091a\u093e\u0930 \u0915\u0930\u093e\u0935\u093e"
                      }
                  ]
              },
              "reports": {
                  "positive": "36.76",
                  "negative": "2.94",
                  "neutral": "60.29"
              }
          }
      ],
      "analysis_done_at": "02/27/2024, 15:54:35",
      "source": "FACEBOOK"
  },
  {
      "_id": "65ddb5562b1213c0cd2242b5",
      "account_name": "pcmc",
      "name": "Sentimental Analysis",
      "posts_with_comment_analysis": [
          {
              "post": {
                  "created_time": "2024-02-27T06:14:30+0000",
                  "message": "\u092e\u0939\u093e\u0930\u093e\u0937\u094d\u091f\u094d\u0930 \u0936\u093e\u0938\u0928\u093e\u091a\u094d\u092f\u093e \u0938\u093e\u0902\u0938\u094d\u0915\u0943\u0924\u093f\u0915 \u0915\u093e\u0930\u094d\u092f \u0935\u093f\u092d\u093e\u0917 \u0935 \u091c\u093f\u0932\u094d\u0939\u093e\u0927\u093f\u0915\u093e\u0930\u0940, \u092a\u0941\u0923\u0947 \u092f\u093e\u0902\u091a\u094d\u092f\u093e\u0924\u0930\u094d\u092b\u0947 \u0926\u093f.\u0968\u096e \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0924\u0947 \u0969 \u092e\u093e\u0930\u094d\u091a \u0926\u0930\u092e\u094d\u092f\u093e\u0928 \u092e\u0939\u093e\u0938\u0902\u0938\u094d\u0915\u0943\u0924\u0940 \u092e\u0939\u094b\u0924\u094d\u0938\u0935 \u0968\u0966\u0968\u096a \u0938\u093e\u0939\u093f\u0924\u094d\u092f\u0930\u0924\u094d\u0928 \u092a\u0941\u0923\u0947 \u091c\u093f\u0932\u094d\u0939\u094d\u092f\u093e\u0924\u0940\u0932 \u0935\u093f\u0935\u093f\u0927 \u0920\u093f\u0915\u093e\u0923\u0940 \u0906\u092f\u094b\u091c\u093f\u0924 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u093e \u0906\u0939\u0947.\n\n\u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092c\u0939\u0941\u0938\u0902\u0916\u094d\u092f\u0947\u0928\u0947 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u0939\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940!",
                  "id": "477167415712554_718200447151965"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-27T06:51:50+0000",
                          "message": "\u0938\u093e\u0939\u093f\u0924\u094d\u092f \u0930\u0924\u094d\u0928  \u0939\u0947 \u0920\u093f\u0915\u093e\u0923 \u0928\u0947\u092e\u0915\u0947 \u0915\u0941\u0920\u0947 \u0906\u0939\u0947"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-27T07:50:52+0000",
                          "message": "Pimpri Chinchwad Municipal Corporation \u0909\u0917\u093e\u091a \u092a\u094b\u0938\u094d\u091f \u0915\u0930\u093e\u092f\u091a\u0940 \u092e\u094d\u0939\u0923\u0941\u0928 \u0915\u0930\u0941 \u0928\u0915\u093e. \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u093e \u0924\u0940 \u092a\u094b\u0938\u094d\u091f \u0935\u093e\u091a\u0924\u093e \u092a\u0923 \u0906\u0932\u0940 \u092a\u093e\u0939\u093f\u091c\u0947 \u0939\u0940 \u0915\u093e\u0933\u091c\u0940 \u0918\u094d\u092f\u093e."
                      }
                  ]
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-27T04:23:59+0000",
                  "message": "\u0915\u0927\u0940 \u0938\u0939\u094d\u092f\u093e\u0926\u094d\u0930\u0940\u091a\u094d\u092f\u093e \u0921\u094b\u0902\u0917\u0930\u093e\u0924 \u0924\u0930 \u0915\u0927\u0940 \u0938\u0902\u0924\u093e\u0902\u091a\u094d\u092f\u093e \u0936\u092c\u094d\u0926\u093e\u0924, \n\u0915\u0927\u0940 \u0907\u0924\u093f\u0939\u093e\u0938\u093e\u091a\u094d\u092f\u093e \u092a\u093e\u0928\u093e\u0924 \u0924\u0930 \u0915\u0927\u0940 \u092f\u093e \u092d\u0942\u092e\u0940\u0935\u0930\u0940\u0932 \u092e\u093e\u0923\u0938\u093e\u0902\u091a\u094d\u092f\u093e \u092e\u0928\u093e\u0924!\n\n\u0906\u092e\u094d\u0939\u0940 \u0936\u094b\u0927\u0932\u0902, \u091c\u092a\u0932\u0902, \u0905\u0928\u0941\u092d\u0935\u0932\u0902 \u0906\u0939\u0947 \u092e\u0930\u093e\u0920\u0940\u092a\u0923...\n\n\u092e\u0930\u093e\u0920\u0940 \u092d\u093e\u0937\u093e \u0917\u094c\u0930\u0935 \u0926\u093f\u0928\u093e\u091a\u094d\u092f\u093e \u0939\u093e\u0930\u094d\u0926\u093f\u0915 \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e!\n\n#\u0917\u094c\u0930\u0935_\u092e\u0930\u093e\u0920\u0940\u091a\u093e #\u092e\u0930\u093e\u0920\u0940_\u092d\u093e\u0937\u093e_\u0917\u094c\u0930\u0935_\u0926\u093f\u0928 #PCMC",
                  "id": "477167415712554_718164153822261"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-23T10:46:35+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0938\u0948\u0928\u093f\u0915 \u092d\u0935\u0928, \u0926\u093f\u0918\u0940 \u092f\u0947\u0925\u0947 RRR \u0915\u0947\u0902\u0926\u094d\u0930  \u0909\u092d\u093e\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0947 \u0906\u0923\u093f \u092f\u093e\u092c\u093e\u092c\u0924 \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u091c\u0928\u091c\u093e\u0917\u0943\u0924\u0940 \u0926\u0947\u0916\u0940\u0932 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhSurvekshan2024 \n#SwachhSurvekshan2024Maharashtra \n#MissionLiFE \n#MajhiVasundharaAbhiyan4 \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \n#SwachhBharatGov \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs \nSwachh Bharat Mission - Urban \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_716114644027212"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-23T15:43:43+0000",
                          "message": "Good effort , keep it up \ud83d\udc4fLet me know if as a responsible citizen I can also help the community."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "66.67",
                  "negative": "0.00",
                  "neutral": "33.33"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-23T10:43:46+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0938\u0902\u0924 \u0917\u093e\u0921\u0917\u0947 \u092e\u0939\u093e\u0930\u093e\u091c \u091c\u092f\u0902\u0924\u0940 \u0928\u093f\u092e\u093f\u0924\u094d\u0924 \u0915\u093f\u0935\u0933\u0947 \u0935\u093f\u0915\u093e\u0938 \u0928\u0917\u0930 \u0930\u0939\u093f\u0935\u093e\u0936\u0940 \u0938\u0902\u0918 \u0906\u0923\u093f \u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0928\u092a\u093e \u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0938\u0902\u092f\u0941\u0915\u094d\u0924 \u0935\u093f\u0926\u094d\u092f\u092e\u093e\u0928\u0947 \u090f\u092e \u092c\u0940 \u0915\u0948\u0902\u092a \u0924\u0947 \u092e\u0941\u0915\u093e\u0908 \u091a\u094c\u0915 \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nSwachh Bharat Mission - Urban \nSwachh Maharashtra Mission -Urban \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs",
                  "id": "477167415712554_716113100694033"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-23T10:58:58+0000",
                          "message": "\u0905\u0924\u093f\u0936\u092f \u0938\u0941\u0902\u0926\u0930 \u0915\u093e\u092e \u0935 \u0928\u093f\u092f\u094b\u091c\u0928"
                      },
                      {
                          "date_time": "2024-02-25T03:47:05+0000",
                          "message": "Good effort on cleanliness..Our city PCMC should win 1st Prize this time in All India Ranking.We can beat Mysore and Indore also.Lets all citizen come together and help local government in their efforts.Also all citizens should maintain highest level of cleanliness near their home and offices."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "80.00",
                  "negative": "0.00",
                  "neutral": "20.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T17:03:42+0000",
                  "message": "\u092f\u0936\u0938\u094d\u0935\u0940 \u0915\u093e\u092e\u0917\u093f\u0930\u0940\u092c\u0926\u094d\u0926\u0932 \u0905\u092d\u093f\u0928\u0902\u0926\u0928!\n\n\u0907\u0902\u0921\u0938\u094d\u091f\u094d\u0930\u0940\u0905\u0932 \u0938\u094d\u092a\u094b\u0930\u094d\u091f\u0938 \u0905\u0938\u094b\u0938\u093f\u090f\u0936\u0928\u0924\u0930\u094d\u092b\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u091f\u0940-\u0968\u0966 \u0915\u094d\u0930\u093f\u0915\u0947\u091f \u0938\u094d\u092a\u0930\u094d\u0927\u0947\u091a\u094d\u092f\u093e \u0905\u0902\u0924\u093f\u092e \u0938\u093e\u092e\u0928\u094d\u092f\u093e\u0924 \u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u092a\u093e\u0932\u093f\u0915\u093e \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0915\u094d\u0930\u093f\u0915\u0947\u091f \u0938\u0902\u0918\u093e\u0928\u0947 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u0938\u0902\u0918\u093e\u0935\u0930 \u092e\u093e\u0924 \u0915\u0930\u0924 \u0935\u093f\u091c\u0947\u0924\u0947\u092a\u0926 \u092a\u091f\u0915\u093e\u0935\u0932\u0947. \n\n\u0935\u093f\u091c\u0947\u0924\u094d\u092f\u093e \u0938\u0902\u0918\u093e\u091a\u0947 \u0906\u092f\u0941\u0915\u094d\u0924 \u0924\u0925\u093e \u092a\u094d\u0930\u0936\u093e\u0938\u0915 \u0936\u0947\u0916\u0930 \u0938\u093f\u0902\u0939 \u092f\u093e\u0902\u0928\u0940 \u0915\u094c\u0924\u0941\u0915 \u0915\u0947\u0932\u0947 \u0905\u0938\u0941\u0928 \u092f\u0936\u093e\u092c\u0926\u094d\u0926\u0932 \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e\u0926\u0947\u0916\u0940\u0932 \u0926\u093f\u0932\u094d\u092f\u093e.\n\nThe winning fifer!\n\nThe #PCMC employee cricket team won the title by defeating the Tata Motors team in the final match of the T20 cricket tournament organized by the Industrial Sports Association.\n\n#WellPlayed #PCMCUpdates",
                  "id": "477167415712554_715206974117979"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-21T17:27:02+0000",
                          "message": "Congratulations all Tim"
                      },
                      {
                          "date_time": "2024-02-22T09:49:20+0000",
                          "message": "Wow... Congratulations \ud83d\udc4f \ud83d\udc4f \ud83d\udc4f \ud83c\udf89 \ud83c\udf89 Keep it"
                      }
                  ]
              },
              "reports": {
                  "positive": "57.14",
                  "negative": "0.00",
                  "neutral": "42.86"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T06:26:16+0000",
                  "message": "\u091c\u0936\u0940 \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u0947\u0935\u093f\u0937\u092f\u0940\u091a\u0940 \u0917\u094b\u0921\u0940 \u092e\u0928\u093e\u0924\u0942\u0928 \u0915\u0927\u0940\u0939\u0940 \u0938\u0902\u092a\u0924 \u0928\u093e\u0939\u0940 \u0924\u0938\u0947\u091a \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u0947\u0924\u0942\u0928 \u0936\u093f\u0915\u0932\u0947\u0932\u094d\u092f\u093e \u0917\u094b\u0937\u094d\u091f\u0940 \u0915\u0927\u0940\u0939\u0940 \u0935\u093f\u0938\u094d\u092e\u0930\u0923\u093e\u0924 \u091c\u093e\u0924 \u0928\u093e\u0939\u0940\u0924. \n\n\u091c\u093e\u0917\u0924\u093f\u0915 \u092e\u093e\u0924\u0943\u092d\u093e\u0937\u093e \u0926\u093f\u0928\u093e\u091a\u094d\u092f\u093e \u0938\u0930\u094d\u0935\u093e\u0902\u0928\u093e \u0936\u0941\u092d\u0947\u091a\u094d\u091b\u093e!\n\n#\u092e\u093e\u0924\u0943\u092d\u093e\u0937\u093e\n#InternationalMotherTongueDay",
                  "id": "477167415712554_714960150809328"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-21T10:43:53+0000",
                          "message": "\u0906\u0924\u093e \u0939\u094d\u092f\u093e \u0936\u0941\u092d\u0926\u093f\u0928\u0940 \u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0916\u093e\u0924\u094d\u092f\u093e\u091a\u0947 \u0928\u093e\u0935 \u092e\u0930\u093e\u0920\u0940\u0924 \u0915\u0930\u0942\u0928 \u091f\u093e\u0915\u093e"
                      },
                      {
                          "date_time": "2024-02-21T09:48:55+0000",
                          "message": "\u0924\u0941\u092e\u091a\u094d\u092f\u093e \u0916\u093e\u0924\u094d\u092f\u093e\u091a\u0947 \u0928\u093e\u0935 \u0906\u092a\u0932\u094d\u092f\u093e \u092e\u093e\u092f\u092e\u0930\u093e\u0920\u0940 \u0915\u0930\u093e\n\n\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u2705\ud83d\ude0d"
                      }
                  ]
              },
              "reports": {
                  "positive": "44.44",
                  "negative": "0.00",
                  "neutral": "55.56"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-21T06:14:06+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u0924\u0930\u094d\u092b\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u092e\u0928\u092a\u093e \u0936\u093e\u0933\u093e, \u0928\u0947\u0939\u0930\u0942\u0928\u0917\u0930  \u092f\u0947\u0925\u0947 \u092a\u0925\u0928\u093e\u091f\u094d\u092f\u093e\u091a\u094d\u092f\u093e \u092e\u093e\u0927\u094d\u092f\u092e\u093e\u0924\u0942\u0928 \u0935\u093f\u0926\u094d\u092f\u093e\u0930\u094d\u0925\u094d\u092f\u093e\u0902\u092e\u0927\u094d\u092f\u0947 (\u0913\u0932\u093e, \u0938\u0941\u0915\u093e, \u0938\u0945\u0928\u093f\u091f\u0930\u0940, \u0918\u0930\u0917\u0941\u0924\u0940 \u0918\u093e\u0924\u0915, \u092a\u094d\u0932\u093e\u0938\u094d\u091f\u093f\u0915) \u0905\u0936\u093e \u092a\u093e\u091a \u092a\u094d\u0930\u0915\u093e\u0930\u091a\u094d\u092f\u093e \u0915\u091a\u0930\u093e \u0935\u0930\u094d\u0917\u0940\u0915\u0930\u0923\u093e\u0935\u093f\u0937\u092f\u0940 \u091c\u0928\u091c\u093e\u0917\u0943\u0924\u0940 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940, \u0924\u0938\u0947\u091a \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u0947\u091a\u0940 \u0935 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u0947\u091a\u0940 \u0938\u093e\u092e\u0942\u0939\u093f\u0915 \u0936\u092a\u0925\u0939\u0940 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n#SwachhSurvekshan2024 \n#SwachhSurvekshan2024Maharashtra \n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhBharatMissionUrban \nMajhi Vasundhara \nSwachh Bharat Mission - Urban  \nMinistry of Housing and Urban Affairs \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_714956687476341"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-21T06:31:00+0000",
                          "message": "We should all participate in Cleanliness as a community and make PCMC proud.All citizens should do their bit and should take onus to clean 100 sq foot area around their residence and office.This will infact help make INDIA cleaner."
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "0.00",
                  "neutral": "50.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T12:52:09+0000",
                  "message": "\u0936\u093f\u0915\u094d\u0937\u0923 \u0935\u093f\u0937\u092f\u0915 \u0938\u0941\u0935\u093f\u0927\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u0935\u093f\u0926\u094d\u092f\u093e\u0930\u094d\u0925\u0940-\u0936\u093f\u0915\u094d\u0937\u0915 \u092e\u0942\u0932\u094d\u092f\u093e\u0902\u0915\u0928, \u091c\u0932\u094d\u0932\u094b\u0937 \u0936\u093f\u0915\u094d\u0937\u0923\u093e\u091a\u093e, \u0905\u092d\u094d\u092f\u093e\u0938\u0926\u094c\u0930\u093e, \u0938\u092e\u0941\u092a\u0926\u0947\u0936\u0928 \u0905\u0938\u0947 \u0938\u092e\u093e\u0935\u0947\u0936 \u0906\u0939\u0947.\n\nProvision for Educational facilities include student-teacher assessment, Jallosh Shikshanacha, study tours & counselling, etc.\n\n#PCMCBudget2024_25",
                  "id": "477167415712554_714563887515621"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-21T06:35:47+0000",
                          "message": "Very good initiative"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "54.55",
                  "negative": "0.00",
                  "neutral": "45.45"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T12:23:42+0000",
                  "message": "\u0936\u0939\u0930\u093e\u091a\u094d\u092f\u093e \u0938\u094c\u0902\u0926\u0930\u094d\u092f\u093e\u0924 \u0935\u093e\u0922 \u0915\u0930\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0935 \u092e\u0941\u0932\u093e\u0902\u092e\u0927\u094d\u092f\u0947 \u092e\u0948\u0926\u093e\u0928\u0940 \u0916\u0947\u0933\u093e\u0902\u091a\u0940 \u0930\u0942\u091a\u0940 \u0935\u093e\u0922\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u092a\u0941\u0922\u0940\u0932 \u0924\u0930\u0924\u0941\u0926\u0940 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u094d\u092f\u093e \u0906\u0939\u0947\u0924.\n\nSaid provisions have been made to enhance the beauty of #PCMC & create interest in children for outdoor activities.\n\n#PCMCBudget2024_25",
                  "id": "477167415712554_714552077516802"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [
                      {
                          "date_time": "2024-02-20T14:35:24+0000",
                          "message": "Hmm, \u092a\u093f\u0902\u092a\u0933\u0947 \u0938\u094c\u0926\u093e\u0917\u0930 \u0932\u093e \u0917\u0930\u0940\u092c \u0932\u094b\u0915\u0902 \u0930\u093e\u0939\u0924\u093e\u0924, \u0924\u094d\u092f\u093e\u0902\u091a\u094d\u092f\u093e \u092e\u0941\u0932\u093e\u0902\u0938\u093e\u0920\u0940 \u0939\u094d\u092f\u093e\u091a\u093e \u092b\u093e\u092f\u0926\u093e\u091a \u0939\u094b\u0908\u0932"
                      }
                  ],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-20T12:56:02+0000",
                          "message": "\u092e\u094b\u0936\u0940 \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0940\u0932 \u0909\u0926\u094d\u092f\u093e\u0928\u0947 \u0915\u0927\u0940 \u0935\u093f\u0915\u0938\u093f\u0924 \u0939\u094b \u0939\u094b\u0923\u093e\u0930"
                      }
                  ]
              },
              "reports": {
                  "positive": "46.15",
                  "negative": "7.69",
                  "neutral": "46.15"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-20T05:30:30+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u0947 \u0905\u0902\u0926\u093e\u091c\u092a\u0924\u094d\u0930\u0915\u0968\u0966\u0968\u096a-\u0968\u0966\u0968\u096b \u0926\u093f.-\u0968\u0966 \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0938\u0915\u093e\u0933\u0940 \u0967\u0967\u0935\u093e...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_357852063796195"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-20T06:14:47+0000",
                          "message": "Very good budget...PCMC India"
                      },
                      {
                          "date_time": "2024-02-20T05:50:49+0000",
                          "message": "Good Budget...PCMC"
                      },
                      {
                          "date_time": "2024-02-20T05:53:23+0000",
                          "message": "Pls take care of senior citizens with more walking areas,parks, cycling tracks near Nehru Nagar area."
                      },
                      {
                          "date_time": "2024-02-20T05:55:10+0000",
                          "message": "Focus on more electric buses to reduce rising pollution"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-20T05:55:44+0000",
                          "message": "Last mile connectivity from metro stations required."
                      },
                      {
                          "date_time": "2024-02-20T19:20:21+0000",
                          "message": "\u092a\u093f\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921\u093c \u0906\u092f\u0942\u0915\u094d\u0924 \u0936\u0947\u0916\u0930 \u0938\u093f\u0902\u0939 \u0938\u093e\u0939\u0947\u092c \u0935\u093e\u0932\u094d\u0939\u0947\u0915\u0935\u093e\u0921\u0940 \u0917\u0942\u0930\u0942\u0935\u094d\u0926\u093e\u0930\u093e \u0930\u094b\u0921  \u092e\u092e\u0940\u0932\u0940 \u091a\u094c\u0915  \u0938\u0930\u094d\u0935\u0947 \u0928\u092c\u0930 126. \u092f\u093e \u0920\u093f\u0915\u093e\u0923\u0940 PMRDA \u0905\u0930\u0915\u094d\u0937\u093f\u0924 \u091c\u093e\u0917\u0947 \u092e\u0927\u094d\u092f\u0947 \u0935\u093f\u0930\u0917\u0942\u0933\u093e \u0915\u0947\u0926\u094d\u0930 \u0906\u0930\u0915\u094d\u0937\u093f\u0924 \u0905\u0938\u0924\u093e\u0928\u0940 \u092a\u0923 \u0924\u094d\u092f\u093e \u0920\u093f\u0915\u093e\u0923\u0940 \u0938\u094d\u0925\u093e\u0928\u0940\u0915 \u092c\u093f\u0932\u094d\u0921\u0930 \u0915\u0921\u0942\u0928 \u0915\u093e\u0939\u0940 \u0905\u0927\u093f\u0915\u093e\u0930\u0940 \u092f\u093e\u0928\u093e \u092e\u0945\u0928\u0947\u091c \u0915\u0930\u0942\u0928  \u0938\u0930\u094d\u0935\u0947 \u0928\u0902\u092c\u0930 126 \u092f\u093e \u0915\u092e\u0930\u094d\u0936\u093f\u092f\u0932 \u092c\u093f\u0932\u094d\u0921\u093f\u0902\u0917 \u090a\u092d\u093e \u0930\u093e\u0939\u093f\u0932\u0940 \u0906\u0939\u0947 \u0939\u093f \u091c\u093e\u0917\u093e \u092e\u0939\u093e\u0928\u0917\u0930 \u092a\u093e\u0932\u0940\u0915\u0947\u0928\u0947 \u0924\u093e\u092c\u094d\u092f\u093e \u092e\u0927\u094d\u092f\u0947 \u0918\u0947\u090a\u0928 \u092f\u094b\u0917\u094d\u092f \u0924\u093f \u0915\u093e\u0930\u0935\u093e\u0908 \u091d\u093e\u0932\u0940\u091a \u092a\u093e\u0939\u0940\u091c\u0947 \u0924\u0938\u0947\u091a \u0938\u0930\u094d\u0935\u0947 \u0928\u092c\u0930 133  \u092e\u0927\u0940 \u092a\u0923  \u092f\u093e \u0938\u0930\u094d\u0935\u0947 \u0928\u0902\u092c\u0930 \u092e\u0927\u093f \u092a\u0923 PMRDA \u091c\u093e\u0917\u093e \u0905\u0930\u0915\u094d\u0937\u093f\u0924 \u0906\u0939\u0947 \u0924\u093f\u0925 \u092a\u0923 \u0915\u093e\u0930\u0935\u093e\u0908 \u0935\u094d\u0939\u093e\u092f\u0932\u093e \u0939\u0935\u0940 \u091c\u092f \u092e\u0939\u093e\u0930\u093e\u0937\u094d\u091f\u094d\u0930"
                      }
                  ]
              },
              "reports": {
                  "positive": "52.63",
                  "negative": "5.26",
                  "neutral": "42.11"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-14T14:58:03+0000",
                  "message": "#PCMC \u0924\u0930\u094d\u092b\u0947 \u0926\u093f. \u0967\u096b \u0924\u0947 \u0967\u096f \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0926\u0930\u092e\u094d\u092f\u093e\u0928 \u091b\u0924\u094d\u0930\u092a\u0924\u0940 \u0936\u093f\u0935\u093e\u091c\u0940 \u092e\u0939\u093e\u0930\u093e\u091c \u0935\u093f\u091a\u093e\u0930 \u092a\u094d\u0930\u092c\u094b\u0927\u0928 \u092a\u0930\u094d\u0935 \u0968\u0966\u0968\u096a \u0906\u092f\u094b\u091c\u093f\u0924 \u0915\u0930\u0923\u094d\u092f\u093e\u0924 \u092f\u0947\u0924 \u0906\u0939\u0947.\n\n\u0939\u093e \u0910\u0924\u093f\u0939\u093e\u0938\u093f\u0915 \u0938\u094b\u0939\u0933\u093e \u0905\u0928\u0941\u092d\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092c\u0939\u0941\u0938\u0902\u0916\u094d\u092f\u0947\u0928\u0947 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u0939\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940!\n\n#\u0936\u093f\u0935\u091c\u092f\u0902\u0924\u0940",
                  "id": "477167415712554_711275481177795"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "52.63",
                  "negative": "5.26",
                  "neutral": "42.11"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-10T15:07:26+0000",
                  "message": "\u0935\u093f\u0915\u0938\u093f\u0924 \u092d\u093e\u0930\u0924 \u0938\u0902\u0915\u0932\u094d\u092a \u092f\u093e\u0924\u094d\u0930\u093e - \u0936\u0939\u0930\u0940 \u092e\u094b\u0939\u0940\u092e \n\n\u0909\u0926\u094d\u092f\u093e \u0926\u093f. \u0967\u0967 \u092b\u0947\u092c\u094d\u0930\u0941\u0935\u093e\u0930\u0940 \u0930\u094b\u091c\u0940 \u0906\u092f\u0908\u0938\u0940 \u092e\u094b\u092c\u093e\u0908\u0932 \u0925\u093f\u090f\u091f\u0930 \u0935\u094d\u0939\u0945\u0928 \u092a\u094d\u0930\u093e\u0925\u092e\u093f\u0915 \u0936\u093e\u0933\u093e, \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0947 \u0938. \u0967\u0966 \u0935\u093e. \u0935 \u092a\u093e\u0923\u094d\u092f\u093e\u091a\u094d\u092f\u093e \u091f\u093e\u0915\u0940\u091c\u0935\u0933, \u091a\u0915\u094d\u0930\u092a\u093e\u0923\u0940 \u0935\u0938\u093e\u0939\u0924, \u092d\u094b\u0938\u0930\u0940 \u092f\u0947\u0925\u0947 \u0926\u0941. \u0969 \u0935\u093e \u092f\u0947\u0923\u093e\u0930 \u0906\u0939\u0947. \u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u092f\u093e\u0935\u0947\u0933\u0940 \u0909\u092a\u0938\u094d\u0925\u093f\u0924 \u0930\u093e\u0939\u0942\u0928 \u0935\u093f\u0935\u093f\u0927 \u092f\u094b\u091c\u0928\u093e\u0902\u091a\u093e \u0932\u093e\u092d \u0918\u094d\u092f\u093e\u0935\u093e \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940.\n\n#ViksitBharatSankalpYatra\n#PCMC",
                  "id": "477167415712554_708842108087799"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [
                      {
                          "date_time": "2024-02-10T15:19:19+0000",
                          "message": "\u092e\u094b\u0926\u0940 \u0938\u0930\u0915\u093e\u0930 \u091a\u093e \u092a\u094d\u0930\u091a\u093e\u0930 \u0906\u0924\u093e \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0915\u0930\u0923\u093e\u0930 \u0915\u093e??  \u0915\u093f\u092e\u093e\u0928 \u0928\u093e\u0935 \u0924\u0930\u0940 \u0926\u0947\u0936\u093e\u091a\u0902 \u0935\u093e\u092a\u0930\u093e ,\u092e\u094b\u0926\u0940 \u092e\u094d\u0939\u0923\u091c\u0947 \u0926\u0947\u0936 \u0928\u093e\u0939\u0940 \u091c\u0930\u093e \u092d\u093e\u0928\u093e\u0935\u0930 \u092f\u093e \u092a\u093e\u0932\u093f\u0915\u093e \u092a\u094d\u0930\u0936\u093e\u0938\u0928"
                      }
                  ],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-10T15:21:10+0000",
                          "message": "\u0906\u0924\u093e\u092a\u0930\u094d\u092f\u0902\u0924 \u0926\u093f\u0932\u0947\u0932\u094d\u092f\u093e \u0917\u0945\u0930\u0902\u091f\u094d\u092f\u093e\u091a \u0915\u093e\u092f \u091d\u093e\u0932\u0902 \u0924\u0947 \u092a\u0923 \u0938\u093e\u0902\u0917\u093e\u092f\u0932\u093e \u0935\u093f\u0938\u0930\u0942 \u0928\u0915\u093e \u092e\u094d\u0939\u0923\u091c\u0947 \u091d\u093e\u0932\u0902"
                      }
                  ]
              },
              "reports": {
                  "positive": "47.62",
                  "negative": "9.52",
                  "neutral": "42.86"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-07T07:02:43+0000",
                  "message": "On #WorldCancerDay, Pimpri Chinchwad Municipal corporation's creative anti-tobacco campaign converts red stains into brilliant rangoli, encouraging a tobacco-free lifestyle and cleanliness.\n\nEnergetic rallies advocate for health and environmental beauty, mobilising residents to create a healthier neighbourhood.\n\nAdopting a tobacco-free lifestyle and promoting cleanliness to create a healthier, cleaner community.\n#SwachhBharatGov \n#MissionLiFE \n#MajhiVasundharaAbhiyan4 \n#MaharashtraDGIPR \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \n#SwachhBharatMissionUrban \n#SafaiMitraSuraksha \nMajhi Vasundhara \nSwachh Bharat Mission - Urban \nMinistry of Housing and Urban Affairs \nSwachh Maharashtra Mission -Urban",
                  "id": "477167415712554_706832468288763"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-02-07T08:00:49+0000",
                          "message": "\u0938\u094d\u0935\u091a\u094d\u091b PCMC \u0938\u0941\u0902\u0926\u0930 PCMC"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "50.00",
                  "negative": "9.09",
                  "neutral": "40.91"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-02T03:13:21+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1149063529410415"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-02T03:43:00+0000",
                          "message": "Extat spot"
                      },
                      {
                          "date_time": "2024-02-02T05:33:13+0000",
                          "message": "Army rowing node Nashik phata in Pune kasarwadi"
                      },
                      {
                          "date_time": "2024-02-02T05:55:19+0000",
                          "message": "Abhi he"
                      },
                      {
                          "date_time": "2024-02-02T03:42:48+0000",
                          "message": "Spardha kuth ahet"
                      },
                      {
                          "date_time": "2024-02-02T05:55:37+0000",
                          "message": "Just start hogi"
                      }
                  ]
              },
              "reports": {
                  "positive": "40.74",
                  "negative": "7.41",
                  "neutral": "51.85"
              }
          },
          {
              "post": {
                  "created_time": "2024-02-01T02:21:24+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_933574645151535"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-02-01T02:34:15+0000",
                          "message": "Punya madhe training center kuth ahe"
                      },
                      {
                          "date_time": "2024-02-01T05:17:07+0000",
                          "message": "Congratulations\ud83c\udf89"
                      },
                      {
                          "date_time": "2024-02-01T04:55:50+0000",
                          "message": "CME DAPODI"
                      }
                  ]
              },
              "reports": {
                  "positive": "36.67",
                  "negative": "6.67",
                  "neutral": "56.67"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-31T11:05:57+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_906025557567804"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T11:07:33+0000",
                          "message": "Haa soyal"
                      },
                      {
                          "date_time": "2024-01-31T11:08:40+0000",
                          "message": "Kya hua"
                      }
                  ]
              },
              "reports": {
                  "positive": "34.38",
                  "negative": "6.25",
                  "neutral": "59.38"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-31T02:15:56+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_764377222385020"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T05:19:05+0000",
                          "message": "Chal Bhai Tarun \ud83d\udd25"
                      },
                      {
                          "date_time": "2024-01-31T03:49:13+0000",
                          "message": "\ud83d\udc4c\ud83d\udc4c"
                      }
                  ]
              },
              "reports": {
                  "positive": "32.35",
                  "negative": "5.88",
                  "neutral": "61.76"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T12:12:40+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967 \u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b \u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1345383646150642"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T14:39:08+0000",
                          "message": "Available *100% Original Protein and Supplements @ \n *KALYANI NAGAR* \n *Next to Gold Gym,*\n& 3M Car Care.\n9423218811\n www.mynutrify.com\n *Free Home Delivery in all over Pune*\n\n *Some products having Special Offer!* \ud83c\udf89\u2728 Buy any protein or gainer , and receive a complimentary shaker bottle! Limited time deal, grab yours now! \ud83d\udcaa\ud83c\udffc"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "34.29",
                  "negative": "5.71",
                  "neutral": "60.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T06:20:56+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u092f\u093e\u0902\u091a\u094d\u092f\u093e \u0938\u0902\u092f\u0941\u0915\u094d\u0924 \u0935\u093f\u0926\u094d\u092f\u092e\u093e\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966  \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0926\u093f. \u0968\u096d \u091c\u093e\u0928\u0947\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0930\u094b\u091c\u0940 \u0915\u0947 \u090f\u0938 \u092c\u0940 \u091a\u094c\u0915 \u0924\u0947 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938  \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u092a\u094d\u0932\u0949\u0917\u0947\u0925\u0949\u0928 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940, \u092f\u093e\u092e\u0927\u094d\u092f\u0947 \u092e\u0939\u093e\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u0947 \u0938\u0930\u094d\u0935 \u0905\u0927\u093f\u0915\u093e\u0930\u0940, \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0935 \u091f\u093e\u091f\u093e \u092e\u094b\u091f\u0930\u094d\u0938 \u092f\u093e\u0902\u091a\u0947 \u0967\u0966\u0966 \u0938\u094d\u0935\u092f\u0902\u0938\u0947\u0935\u0915 \u0938\u0939\u092d\u093e\u0917\u0940 \u091d\u093e\u0932\u0947 \u0939\u094b\u0924\u0947. \n#SwachhBharatGov \n#MissionLiFE \n#MaharashtraDGIPR \n#MajhiVasundharaAbhiyan4 \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nMajhi Vasundhara \nMinistry of Housing and Urban Affairs \nSwachh Bharat Mission - Urban \nCMOMaharashtra",
                  "id": "477167415712554_701969138775096"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-31T15:53:35+0000",
                          "message": "Great"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "36.11",
                  "negative": "5.56",
                  "neutral": "58.33"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T06:16:34+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e\u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0968\u096c \u091c\u093e\u0928\u0947\u0935\u093e\u0930\u0940 \u0968\u0966\u0968\u096a \u0930\u094b\u091c\u0940 \u0938\u094d\u0915\u093e\u092f \u0938\u094d\u0915\u093e\u092f\u092a\u0930 \u0938\u094b\u0938\u093e\u092f\u091f\u0940 \u0924\u0925\u093e\u0935\u0921\u0947 \u092f\u093e \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u092a\u094d\u0932\u0949\u0917\u0947\u0925\u0949\u0928 \u0918\u0947\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940. \nOn behalf of Pimpri Chinchwad Municipal Corporation, a Plogathon was conducted on 26th January 2024 by Sky Skipper Society in Tathavade area under Swachh Survekshan 2024 and Majhi Vasundhara Mission 4.0.\n#SwachhBharatGov \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#SwachhBharatMissionUrban  \n#SafaimitraSurakshaChallenge  \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \nSwachh Bharat Mission - Urban \nMajhi Vasundhara  \nSwachh Maharashtra Mission -Urban  \nMinistry of Housing and Urban Affairs",
                  "id": "477167415712554_701966738775336"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T13:08:36+0000",
                          "message": "Pimpri Chinchwad Municipal Corporation \u0932\u094b\u0915\u0947\u0936\u0928 \u0924\u093e\u0925\u0935\u0921\u0947 \u0928\u0938\u0941\u0928 \u0928\u093f\u0917\u0921\u0940 \u092a\u094d\u0930\u093e\u0927\u093f\u0915\u0930\u0923 \u0906\u0939\u0947."
                      }
                  ]
              },
              "reports": {
                  "positive": "35.14",
                  "negative": "5.41",
                  "neutral": "59.46"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-30T03:30:33+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_245662221913687"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T03:58:59+0000",
                          "message": "Best of luck all Rower's"
                      },
                      {
                          "date_time": "2024-01-30T07:01:01+0000",
                          "message": "Love \u2764"
                      },
                      {
                          "date_time": "2024-01-30T05:13:14+0000",
                          "message": "Nice"
                      },
                      {
                          "date_time": "2024-01-30T03:57:35+0000",
                          "message": "Nice"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T06:45:39+0000",
                          "message": "Jai mp \ud83d\udd25\ud83d\udd25\ud83d\udd25\ud83d\udd25\ud83d\udd25"
                      },
                      {
                          "date_time": "2024-01-30T05:52:06+0000",
                          "message": "Thanks for live"
                      },
                      {
                          "date_time": "2024-01-30T03:37:24+0000",
                          "message": "Venue?"
                      },
                      {
                          "date_time": "2024-01-30T06:01:25+0000",
                          "message": "Single mai Punjab ka kya hua"
                      },
                      {
                          "date_time": "2024-01-30T05:51:20+0000",
                          "message": "Hlo bro"
                      },
                      {
                          "date_time": "2024-01-30T05:51:55+0000",
                          "message": "Commatery mai team ka confirm kar do"
                      },
                      {
                          "date_time": "2024-01-30T08:17:00+0000",
                          "message": "Hlo"
                      },
                      {
                          "date_time": "2024-01-30T09:02:07+0000",
                          "message": "Last 750 pe"
                      },
                      {
                          "date_time": "2024-01-30T09:01:49+0000",
                          "message": "Baki teams ko bhi dekya karo fir army walo ko kue dekyte ho"
                      }
                  ]
              },
              "reports": {
                  "positive": "34.00",
                  "negative": "4.00",
                  "neutral": "62.00"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T16:54:36+0000",
                  "message": "Rowers, Are you ready?\n\nGet ready to experience the thrill and adventure!\n\n\u0930\u094b\u0935\u094d\u0939\u0930\u094d\u0938, \u0924\u0941\u092e\u094d\u0939\u0940 \u0924\u092f\u093e\u0930 \u0906\u0939\u093e\u0924 \u0915\u093e?\n\n\u0930\u094b\u092e\u093e\u0902\u091a\u0915 \u0930\u094b\u0908\u0902\u0917 \u0905\u0928\u0941\u092d\u0935\u0923\u094d\u092f\u093e\u0938\u093e\u0920\u0940 \u0938\u091c\u094d\u091c \u0935\u094d\u0939\u093e!\n\n#RowingChampionship #PCMC",
                  "id": "477167415712554_701646018807408"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-30T10:19:39+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "35.29",
                  "negative": "3.92",
                  "neutral": "60.78"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T11:30:27+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u093e \u0935 \u0906\u0930\u094d\u092e\u0940 \u0930\u094b\u0908\u0902\u0917 \u0928\u094b\u0921 \u0938\u0940 \u090f\u092e \u0908 \u092a\u0941\u0923\u0947 \u0906\u092f\u094b\u091c\u093f\u0924 \u096a\u0967\u0935\u0940 \u0938\u093f\u0928\u093f\u092f\u0930 \u0935 \u0968\u096b\u0935\u0940 \u0913\u092a\u0928 \u0938\u094d\u092a\u094d\u0930\u093f\u0902\u091f \u0930\u093e\u0937\u094d\u091f\u094d\u0930\u0940\u092f \u0930\u094b\u0908\u0902\u0917 \u091a\u0945\u092e\u094d\u092a\u093f\u092f\u0928\u0936\u093f\u092a \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_415611457692116"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-29T11:52:56+0000",
                          "message": "Good to see the event"
                      },
                      {
                          "date_time": "2024-01-30T02:26:23+0000",
                          "message": "The Indian Senior Rowing nationals have started, all the very best to all involved as I am still based in O.Z. Coach P."
                      },
                      {
                          "date_time": "2024-01-30T02:17:03+0000",
                          "message": "So very proud of you all:)"
                      },
                      {
                          "date_time": "2024-01-29T11:36:45+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-30T07:24:01+0000",
                          "message": "W4 heats"
                      }
                  ]
              },
              "reports": {
                  "positive": "39.29",
                  "negative": "3.57",
                  "neutral": "57.14"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-29T03:21:36+0000",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_720860216470673"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-29T03:40:04+0000",
                          "message": "Good"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": []
              },
              "reports": {
                  "positive": "40.35",
                  "negative": "3.51",
                  "neutral": "56.14"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-27T04:56:51+0000",
                  "message": "\u0928\u093e\u0917\u0930\u093f\u0915\u093e\u0902\u0928\u0940 \u0915\u0943\u092a\u092f\u093e \u0928\u094b\u0902\u0926 \u0918\u094d\u092f\u093e\u0935\u0940 \u0935 \u0938\u0939\u0915\u093e\u0930\u094d\u092f \u0915\u0930\u093e\u0935\u0947 \u0939\u0940 \u0935\u093f\u0928\u0902\u0924\u0940.\n\n#PCMC #WaterSupply",
                  "id": "477167415712554_700114308960579"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-27T05:28:17+0000",
                          "message": "\u0927\u0928\u094d\u092f\u0935\u093e\u0926"
                      }
                  ]
              },
              "reports": {
                  "positive": "39.66",
                  "negative": "3.45",
                  "neutral": "56.90"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-27T04:43:16+0000",
                  "message": "\u091c\u0917\u0926\u094d\u0917\u0941\u0930\u0942 \u0938\u0902\u0924 \u0924\u0941\u0915\u093e\u0930\u093e\u092e \u092e\u0939\u093e\u0930\u093e\u091c \u0938\u0902\u0924\u092a\u0940\u0920 \u092a\u094d\u0930\u0935\u0947\u0936 \u0938\u094b\u0921\u0924 \u092a\u094d\u0930\u0915\u094d\u0930\u093f\u092f\u093e \u0968\u0966\u0968\u096a...",
                  "story": "Pimpri Chinchwad Municipal Corporation was live.",
                  "id": "477167415712554_1825970254521333"
              },
              "comments": {
                  "positive_description": [
                      {
                          "date_time": "2024-01-27T05:40:57+0000",
                          "message": "Awaj"
                      },
                      {
                          "date_time": "2024-01-27T12:08:53+0000",
                          "message": "\u092c\u0939\u0941\u0924 \u092c\u0922\u093c\u093f\u092f\u093e \u0914\u0930 \u0938\u0924\u094d\u092f\u0964"
                      }
                  ],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-27T06:29:47+0000",
                          "message": "\ud83d\udc4d"
                      },
                      {
                          "date_time": "2024-01-27T10:43:24+0000",
                          "message": "\ud83d\ude4f\ud83d\ude4f\ud83d\ude4f"
                      },
                      {
                          "date_time": "2024-01-27T06:50:26+0000",
                          "message": "\ud83d\udc4d"
                      },
                      {
                          "date_time": "2024-01-27T06:55:43+0000",
                          "message": "\ud83d\udc4d\ud83d\udc46\ud83d\udc4c\ud83d\udc4c"
                      },
                      {
                          "date_time": "2024-01-27T06:54:19+0000",
                          "message": "Thanks \ud83d\ude4f\ud83d\ude4f\ud83d\ude4f"
                      },
                      {
                          "date_time": "2024-01-27T05:56:11+0000",
                          "message": "\ud83d\udc4c\ud83d\udc4c\ud83d\udc4c\ud83d\udc4c"
                      }
                  ]
              },
              "reports": {
                  "positive": "37.88",
                  "negative": "3.03",
                  "neutral": "59.09"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-24T09:40:31+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e \u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0935 \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0936\u094d\u0930\u0940 \u0938\u0902\u0924 \u0936\u093f\u0930\u094b\u092e\u0923\u0940 \u0938\u093e\u0935\u0924\u093e \u092e\u0939\u093e\u0930\u093e\u091c \u0909\u0926\u094d\u092f\u093e\u0928, \u091c\u093e\u0927\u0935\u0935\u093e\u0921\u0940 \u092f\u0947\u0925\u0947 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u093f\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\n\nOn behalf of Pimpri Chinchwad Municipal Corporation, a cleanliness campaign was conducted at Sri Sant Shiromani Savata Maharaj Udyan, Jadhavwadi under Swachh Survekshan 2024 and Majhi Vasundhara Mission 4.0.\n#SwachhBharatGov \n#MissionLiFE \n#MaharashtraDGIPR \n#MajhiVasundharaAbhiyan4 \n#SwachhBharatMissionUrban \n#SwachhSurvekshan2024Maharashtra \n#SwachhSurvekshan2024 \n@majhivasundharaabhiyan_4.0 \n@mohua__india \n@sbmurbangov \n@cmomaharashtra_",
                  "id": "477167415712554_698458935792783"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T09:22:33+0000",
                          "message": "\u091c\u0917\u0924\u093e\u092a \u0928\u0917\u0930 \u0932\u0947\u0928 \u0928 6 \u092e\u0927\u094d\u092f\u0947 \u0915\u093f\u0924\u0940 \u0924\u0915\u094d\u0930\u093e\u0930\u0940 \u0915\u0947\u0932\u094d\u092f\u093e \u0924\u0930\u0940 \u0915\u091a\u0930\u093e \u0909\u091a\u0932\u0924 \u0928\u093e\u0939\u0940\u0924 \u092f\u0947\u0925\u0940\u0932 \u0932\u094b\u0915 \u0925\u0902\u0921\u0940 \u0924\u093e\u092a \u092e\u0941\u0933\u0947 \u0906\u091c\u093e\u0930\u0940 \u092a\u0921\u0932\u0947 \u0906\u0939\u0947\u0924 . \n\u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092b\u0915\u094d\u0924 \u091c\u093e\u0939\u093f\u0930\u093e\u0924\u0940 \u092e\u0927\u094d\u092f\u0947 \u092a\u093e\u0932\u093f\u0915\u093e \u0926\u093e\u0916\u0935\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937\u093e\u0924 \u0915\u093f\u0924\u0940\u0924\u0930\u0940 \u0936\u0939\u0930\u093e\u0924 \u0915\u091a\u0930\u093e \u091c\u093e\u0917\u094b\u091c\u093e\u0917\u0940 \u0906\u0939\u0947"
                      }
                  ]
              },
              "reports": {
                  "positive": "37.31",
                  "negative": "2.99",
                  "neutral": "59.70"
              }
          },
          {
              "post": {
                  "created_time": "2024-01-24T06:11:29+0000",
                  "message": "\u092a\u093f\u0902\u092a\u0930\u0940 \u091a\u093f\u0902\u091a\u0935\u0921 \u092e\u0939\u093e\u0928\u0917\u0930\u092a\u093e\u0932\u093f\u0915\u0947\u091a\u094d\u092f\u093e \u0935\u0924\u0940\u0928\u0947 \u0938\u094d\u0935\u091a\u094d\u091b \u0938\u0930\u094d\u0935\u0947\u0915\u094d\u0937\u0923 \u0968\u0966\u0968\u096a \u0906\u0923\u093f \u092e\u093e\u091d\u0940 \u0935\u0938\u0941\u0902\u0927\u0930\u093e \u0905\u092d\u093f\u092f\u093e\u0928 \u096a.\u0966 \u0905\u0902\u0924\u0930\u094d\u0917\u0924 \u0936\u093f\u0935\u0938\u0943\u0937\u094d\u091f\u0940 \u092a\u093e\u0930\u094d\u0915, \u0921\u093e\u0902\u0917\u0947 \u091a\u094c\u0915 \u092f\u0947\u0925\u0940\u0932 \u0909\u0926\u094d\u092f\u093e\u0928 \u0906\u0923\u093f \u0909\u0926\u094d\u092f\u093e\u0928\u093e\u091a\u094d\u092f\u093e \u0906\u0924\u0940\u0932 \u092a\u0930\u093f\u0938\u0930\u093e\u0924 \u0938\u094d\u0935\u091a\u094d\u091b\u0924\u093e \u092e\u094b\u0939\u093f\u092e \u0930\u093e\u092c\u0935\u093f\u0923\u094d\u092f\u093e\u0924 \u0906\u0932\u0940.\nOn behalf of the Pimpri Chinchwad Municipal Corporation, a cleanliness drive was carried out under Swachh Survekshan 2024 and Majhi Vasundhara Abhiyan 4.0 in Shivshristi Park, Dange Chowk and the park and the inner area of \u200b\u200bthe park.\n#SwachhBharatGov \n#SwachhSurvekshan2024Maharashtra \n#MajhiVasundharaAbhiyan4 \n#MissionLiFE \n#MaharashtraDGIPR \n#SwachhSurvekshan2024 \n#SwachhBharatMissionUrban \nMinistry of Housing and Urban Affairs \nMajhi Vasundhara \nSwachh Bharat Mission - Urban \nHardeep Singh Puri",
                  "id": "477167415712554_698388422466501"
              },
              "comments": {
                  "positive_description": [],
                  "negative_description": [],
                  "neutral_description": [
                      {
                          "date_time": "2024-01-31T12:45:40+0000",
                          "message": "\u0938\u094d\u0935\u091a\u094d\u091b\u0924\u0947\u091a\u094d\u092f\u093e \u092e\u0939\u093e\u0928\u0917\u0930 \u092a\u093e\u0932\u093f\u0915\u093e \u092b\u0915\u094d\u0924 \u092c\u093e\u0924\u093e \u092e\u093e\u0930\u0924\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937\u093e\u0924 \u0936\u0939\u0930\u093e\u0924 \u0920\u0940\u0915 \u0920\u093f\u0915\u093e\u0923\u0940 \u0905\u0928\u0947\u0915 \u0920\u093f\u0915\u093e\u0923\u0940 \u0915\u091a\u0931\u094d\u092f\u093e\u091a\u0947 \u0922\u0940\u0917 \u0906\u0939\u0947. \u0935\u093e\u0930\u0902\u0935\u093e\u0930 \u0924\u0915\u094d\u0930\u093e\u0930 \u0915\u0930\u0942\u0928 \u0938\u0941\u0926\u094d\u0927\u093e \u0915\u0930\u094d\u092e\u091a\u093e\u0930\u0940 \u0916\u0941\u0930\u094d\u091a\u0940\u0935\u0930 \u092c\u0938\u0942\u0928 \u0930\u093e\u0939\u0924\u093e\u0924\n\u092f\u093e\u091a\u0947 \u092a\u094d\u0930\u0924\u094d\u092f\u0915\u094d\u0937 \u0909\u0926\u093e\u0939\u0930\u0923 \u0917 \u092a\u094d\u0930\u092d\u093e\u0917 \u091c\u0917\u0924\u093e\u092a \u0928\u0917\u0930 \u0932\u0947\u0928 \u0928 6 \u092a\u093e\u0936\u0940\u0932 \u0928\u093e\u0932\u094d\u092f\u093e\u091a\u0947 \u0938\u093e\u0902\u0921\u092a\u093e\u0923\u0940 \u092e\u0941\u0933\u0947 \u0924\u0947\u0925\u0940\u0932 \u0928\u093e\u0917\u0930\u093f\u0915 \u0924\u093e\u092a \u0925\u0902\u0921\u0940\u0928\u0947 \u0917\u094d\u0930\u0938\u094d\u0924 \u0906\u0939\u0947\u0924 \u092a\u094d\u0930\u0936\u093e\u0938\u0928 \u0935\u093e\u0930\u0902\u0935\u093e\u0930 \u0938\u093e\u0902\u0917\u0942\u0928 \u0915\u091a\u0930\u093e \u0915\u093e\u0922\u0924 \u0928\u093e\u0939\u0940\u0924 \u092e\u0940\u0939\u0940 \u0905\u0928\u0947\u0915 \u0935\u0947\u0933\u093e \u0938\u093e\u0902\u0917\u093f\u0924\u0932\u0947 \u0938\u093e\u0930\u0925\u0940 \u0935\u0930 \u0924\u0915\u094d\u0930\u093e\u0930 \u0939\u0940 \u0915\u0947\u0932\u0940 \u092a\u0923 \u0915\u093e\u0939\u0940\u091a \u0915\u0930\u0924 \u0928\u093e\u0939\u0940 . \n\n\u092e\u0940 \u0924\u0930 \u090f\u0915\u091a \u0938\u0927\u094d\u092f\u093e \u092b\u094b\u091f\u094b \u0936\u0947\u092f\u0930 \u0915\u0930\u0924\u094b \u092c\u093e\u0915\u0940 \u0920\u093f\u0915\u093e\u0923\u0940 \u0915\u093e\u092f \u0905\u0935\u0938\u094d\u0925\u093e \u0905\u0938\u0947\u0932 \u0906\u092a\u0923\u091a \u0935\u093f\u091a\u093e\u0930 \u0915\u0930\u093e\u0935\u093e"
                      }
                  ]
              },
              "reports": {
                  "positive": "36.76",
                  "negative": "2.94",
                  "neutral": "60.29"
              }
          }
      ],
      "analysis_done_at": "02/27/2024, 15:39:40",
      "source": "FACEBOOK"
  }
]

