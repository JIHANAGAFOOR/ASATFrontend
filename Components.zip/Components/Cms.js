import React, { Component } from "react";

class Cms extends Component {
  render() {
    return <div>
      <br/>
      <br/>
      <br/>
      this is Cms
    </div>;
  }
}

export default Cms;
