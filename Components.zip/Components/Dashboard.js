import React, { Component } from "react";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import CircularProgress from "@material-ui/core/CircularProgress";
import "../App.css";
import {
  fetchtwitterAnalysis,
  fetchgetword,
  fetchtwitterPostCount,
  fetchtwittersearch,
} from "../Reducers/actions";
import { connect } from "react-redux";
import i18next from "i18next";
import { withRouter } from "react-router-dom";
import Typography from "@material-ui/core/Typography";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";
import Toolbar from "@material-ui/core/Toolbar";
import { Table } from "react-bootstrap";
import Button from "@material-ui/core/Button";
import { DropdownButton, Dropdown } from "react-bootstrap";
import Modal from "@material-ui/core/Modal";
import CloseIcon from "@material-ui/icons/Close";
import ReactWordcloud from "react-wordcloud";
import { ExportCSV } from "./ExportCSV";
import { MenuItem, FormControl, Select } from "@material-ui/core";
import * as URLS from "../Reducers/Constants";
import axios from "axios";
import MetricWidget from "./MetricWidget";
import CommentsModal from "./CommentsModal";
import SentimentalPieChart from "./SentimentalPieChart";
import SentimentalPieChartModal from "./SentimentalPieChartModal";
import PostCountBarChart from "./PostCountBarChart";
import PostCountBarChartModal from "./PostCountBarChartModal";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,Label,
} from "recharts";
import PrintIcon from "@material-ui/icons/Print";
import IconButton from "@material-ui/core/IconButton";
import ZoomOutMapIcon from "@material-ui/icons/ZoomOutMap";
import * as am4core from "@amcharts/amcharts4/core";
import * as am4plugins_wordCloud from "@amcharts/amcharts4/plugins/wordCloud";

// import am4themes_animated from "@amcharts/amcharts4/themes/animated";
// am4core.useTheme(am4themes_animated);
const COLORS = [
  "#28E589",
  "#9FE819",
  "#C2AE4A",
  "#59B15D",
  "#016F08",
  "#DDF9B5",
  "#401E17",
  "#1E4C83",
  "#1A762C",
  "#48E4CD",
  "#CF9FB5",
  "#285C8C",
  "#A6139C",
  "#05F8A6",
  "#F01D58",
  "#3E9C94",
  "#16ACBD",
  "#2D42C7",
  "#4B8FF3",
  "#FE41F6",
  "#30C7D1",
  "#C600A3",
  "#78DF86",
  "#ABCEB9",
  "#BC37E9",
  "#F192EF",
  "#14A571",
  "#39A1C3",
  "#A7B838",
  "#7BF203",
  "#23171B",
  "#CF7E7F",
  "#E25BFB",
  "#138F5C",
  "#BB41AD",
  "#AA9519",
  "#2102DA",
  "#BAB613",
  "#9A19CC",
  "#683164",
  "#64ED1C",
  "#960F60",
  "#8F8176",
  "#BA19D1",
  "#4A42D1",
  "#F504F3",
  "#B2DA11",
  "#DBC7FB",
  "#0F8831",
  "#5F7D17",
  "#D1C34C",
  "#148479",
  "#3B3B1C",
  "#5B84CD",
  "#CF7B9D",
  "#9D21C3",
  "#F3EF45",
  "#4DD5CB",
  "#781969",
  "#57BEBD",
  "#BFE5FD",
  "#4EF022",
  "#E1DFC7",
  "#3E7ECB",
  "#942A57",
  "#119EF1",
  "#57ACDB",
  "#9CD98A",
  "#0A4006",
  "#686B7A",
  "#0737C1",
  "#C4A9EF",
  "#698E01",
  "#006016",
  "#062FF8",
  "#20C715",
  "#99EBEE",
  "#F02E89",
  "#3612C8",
  "#13D740",
  "#E1E749",
  "#7CC358",
  "#6264BC",
  "#5E912F",
  "#E5CA4A",
  "#810492",
  "#EA878F",
  "#F47CDE",
  "#11D6A6",
  "#12F8BD",
  "#06C12D",
  "#78F8B1",
  "#C1C72F",
  "#067545",
  "#0BAB5E",
  "#0BCE22",
  "#76FDA2",
  "#05A67A",
  "#D1887C",
  "#75E94B",
  "#D222BA",
  "#3C6CFD",
  "#88848E",
  "#FDB6A6",
  "#7382AA",
  "#722C0C",
  "#E081F8",
  "#0A5DB5",
  "#2F6BF9",
  "#7299B6",
  "#F6DC10",
  "#B2C68E",
  "#789C3E",
  "#AC6362",
  "#A06F46",
  "#E616CA",
  "#9AE845",
  "#5CC131",
  "#C94DDE",
  "#45EB39",
  "#306AE5",
  "#5BC168",
  "#F9B229",
  "#328442",
  "#7A29C1",
  "#B1D259",
  "#308446",
  "#35DD53",
  "#7651BF",
  "#E92BF9",
  "#ECCDC5",
  "#46FE36",
  "#77DE59",
  "#1A2A6D",
  "#268653",
  "#504C16",
  "#B7E2C3",
  "#2D647E",
  "#20ED64",
  "#E6E4C1",
  "#806C44",
  "#D660BE",
  "#DEC53F",
  "#9B367F",
  "#53CA9F",
  "#5E31D5",
  "#66E2AE",
  "#82EA7D",
  "#AB7E5A",
  "#C1B44D",
  "#4C1363",
  "#318EBD",
  "#636866",
  "#E17671",
  "#35C6BE",
  "#565D99",
  "#7DB928",
  "#31398E",
  "#2F93CB",
  "#D7A22A",
  "#7125C7",
  "#CB17B1",
  "#2EE93D",
  "#0D58D6",
  "#9D0DD4",
  "#B32933",
  "#2547B3",
  "#0B0A74",
  "#691318",
  "#FF1F1C",
  "#D30ED6",
  "#1637BC",
  "#DB395C",
  "#8B267D",
  "#C9C90E",
  "#EEB6F9",
  "#49A122",
  "#43C3F4",
  "#5E3E65",
  "#ACED7E",
  "#F7FA4C",
  "#8933A9",
  "#85A884",
  "#F16EB1",
  "#3A0C00",
  "#71C487",
  "#ECACFE",
  "#FBDA5E",
  "#D5D322",
  "#E6787F",
  "#96C6B9",
  "#E3FA2C",
  "#B01372",
  "#765793",
  "#DB6217",
  "#2E367E",
  "#CB4BAE",
  "#158D82",
  "#031A0D",
  "#07C230",
  "#C81F0E",
  "#8264C0",
  "#A074B3",
  "#DB1800",
  "#1FA1BA",
  "#F85DB8",
  "#24B52F",
  "#FFBD04",
  "#A6EA85",
  "#70CF90",
  "#219635",
  "#3AD350",
  "#F8A898",
  "#3477C3",
  "#244F89",
  "#C87E81",
  "#57268F",
  "#972CEF",
  "#9B200A",
  "#517BB7",
  "#857A0F",
  "#86A858",
  "#417876",
  "#B7545E",
  "#D6B6AD",
  "#5F557D",
  "#5EDC81",
  "#B55EDA",
  "#9A986F",
  "#6A2F6E",
  "#19366B",
  "#173EB3",
  "#E0A5AC",
  "#227EA5",
  "#75DB24",
  "#A525BB",
  "#8E46B5",
  "#20B0E9",
  "#55D807",
  "#32ACCA",
  "#F84B30",
  "#035C75",
  "#A6D779",
  "#2A172B",
  "#940B52",
  "#540374",
  "#3560B1",
  "#F8F314",
  "#3EC851",
  "#5F9A7F",
  "#7A153E",
  "#8F7099",
  "#6C9CF4",
  "#DAC1E2",
  "#33A761",
  "#A338E2",
  "#FE88AE",
  "#A09570",
  "#77F245",
  "#9F5DE0",
  "#5ABA4B",
  "#1158ED",
  "#2DF7B3",
  "#8FF89A",
  "#2C61B8",
  "#8B5644",
  "#7B8CC3",
  "#9FA7A6",
  "#83B1E0",
  "#26E4B7",
  "#92C2FA",
  "#7DA5F2",
  "#4B1CD4",
  "#FED59F",
  "#8D8F40",
  "#2154EA",
  "#84768A",
  "#C0F5CE",
  "#16A069",
  "#956BB6",
  "#82019D",
  "#39E232",
  "#D0A3A8",
  "#D7C685",
  "#ED4C78",
  "#5D6A12",
  "#9C1989",
  "#7F085F",
  "#4DDAF1",
  "#63AA38",
  "#9662B0",
  "#EF4378",
  "#314D27",
  "#BF4707",
  "#80CD6B",
  "#75ECA8",
  "#F1F646",
  "#BFB227",
  "#4DB2AD",
  "#9289EB",
  "#CC2E6D",
  "#432B22",
  "#00E987",
  "#716B90",
  "#5C415E",
  "#5A6316",
  "#06C553",
  "#61B48F",
  "#6BF3E2",
  "#428BCF",
  "#5BCD09",
  "#41984F",
  "#396655",
  "#5E4F11",
  "#78F83B",
  "#61315E",
  "#CCA0C0",
  "#8CFA7D",
  "#51996F",
  "#C6E8E3",
  "#9B3193",
  "#9A4006",
  "#4BB7A7",
  "#50DFB1",
  "#BED5DE",
  "#2356E5",
  "#240416",
  "#30A581",
  "#EF18DB",
  "#DD62A4",
  "#05E4FF",
  "#0A64FB",
  "#FC4F6F",
  "#7A02AD",
  "#9DCC38",
  "#1E196B",
  "#DD6024",
  "#01E653",
  "#283EFB",
  "#6FCDB3",
  "#C30A5F",
  "#62F46B",
  "#3FAF75",
  "#D1B632",
  "#6FAD16",
  "#C3FAC1",
  "#D152BE",
  "#F80E8F",
  "#E3BA8D",
  "#1FAAE3",
  "#754817",
  "#6945FB",
  "#D00FDA",
  "#671B11",
  "#94FB54",
  "#4BBFFF",
  "#F2684B",
  "#F3EB79",
  "#103D81",
  "#0A38D6",
  "#B2543F",
  "#C976CC",
  "#0AB305",
  "#5BD8DC",
  "#893DF2",
  "#1F4E02",
  "#3790E3",
  "#A6397D",
  "#49D7AD",
  "#C297AB",
  "#AF8FB8",
  "#2EF3DB",
  "#544C47",
  "#DC74A6",
  "#EB0B67",
  "#8D9DD2",
  "#7E27C1",
  "#38812D",
  "#DE7010",
  "#6388B5",
  "#01D956",
  "#863D2F",
  "#85D4D3",
  "#8691C3",
  "#E0A071",
  "#1E9527",
  "#97DCFE",
  "#8484ED",
  "#430CEC",
  "#4BBB3D",
  "#B3498D",
  "#05326F",
  "#D546CA",
  "#D4AAEC",
  "#35779B",
  "#DE7C60",
  "#3CC1AA",
  "#1A567A",
  "#D1527B",
  "#333008",
  "#E0B9D7",
  "#3E089F",
  "#BF0108",
  "#AA80F7",
  "#F1DC2D",
  "#36350C",
  "#A43565",
  "#74AA44",
  "#B267EC",
  "#887B2F",
  "#BF99CC",
  "#52F685",
  "#5CD954",
  "#ACED3C",
  "#D2D14A",
  "#4DF996",
  "#571D63",
  "#CE1067",
  "#497F98",
  "#3B4911",
  "#7F6EDE",
  "#790AE2",
  "#B5541A",
  "#788CB7",
  "#534E27",
  "#75397B",
  "#963123",
  "#048107",
  "#2CF2CD",
  "#905FE6",
  "#C59541",
  "#9B1139",
  "#446C42",
  "#38BC18",
  "#2C9916",
  "#F9E338",
  "#F39EAC",
  "#CFD019",
  "#0FB3FA",
  "#9D9582",
  "#85B696",
  "#083871",
  "#26F24F",
  "#4AE352",
  "#E0371B",
  "#9C72F3",
  "#8B9354",
  "#F98A36",
  "#06069F",
  "#C2B509",
  "#36D583",
  "#8F2D28",
  "#36B6F6",
  "#566B01",
  "#D18E83",
  "#320DB1",
  "#E5FE2C",
  "#535C98",
  "#9460FE",
  "#C9B303",
  "#43AF00",
  "#B0D662",
  "#F2110A",
  "#A75A59",
  "#035340",
  "#82AC76",
  "#9BDDB7",
  "#8D21D8",
  "#7251CB",
  "#464119",
  "#9B0AB8",
  "#CDDBBE",
  "#82EF9E",
  "#9458CD",
  "#580B65",
  "#42CC72",
  "#4D85B0",
  "#79AC1D",
  "#8AC618",
  "#D9BBB8",
  "#67BCB1",
  "#D70782",
  "#9412C5",
  "#3FE214",
  "#A2F236",
  "#18B14E",
  "#E56413",
  "#2B1D3E",
  "#3C4FF3",
  "#0D6041",
  "#B8325A",
  "#EDACB4",
  "#D7494D",
  "#DA4B82",
  "#A58E1B",
  "#CEA1E4",
  "#6E1A99",
  "#42A294",
  "#C3CD0A",
  "#88DC88",
  "#F523AF",
  "#90B465",
  "#158868",
  "#F74ADA",
  "#89156A",
  "#C277C1",
  "#E7727D",
  "#50B1E4",
  "#7CCC72",
  "#05E05B",
  "#E6B79B",
  "#27A178",
  "#FD9148",
  "#792FDE",
  "#028CB5",
  "#FD0CF6",
  "#A8B148",
  "#1E476A",
  "#F36934",
  "#BB7547",
  "#D5E338",
  "#AFF8FB",
  "#4670FE",
  "#A79352",
  "#007536",
  "#99F534",
  "#A700A8",
  "#FC2765",
  "#C38DD5",
  "#9A9BBE",
  "#4C1313",
  "#3F5C57",
  "#47834A",
  "#99411E",
  "#88B793",
  "#5652DE",
  "#D40708",
  "#491297",
  "#D49786",
  "#B492C2",
  "#9E0446",
  "#71F519",
  "#18B3ED",
  "#F39265",
  "#3EDD3F",
  "#4534E4",
  "#AFC21D",
  "#264EA0",
  "#6618BB",
  "#88D010",
  "#EE6B38",
  "#651FAB",
  "#760FB6",
  "#1DEFDE",
  "#EF65C3",
  "#859495",
  "#8C452F",
  "#62632E",
  "#C50266",
  "#E53326",
  "#88BBFE",
  "#3622C5",
  "#0C30CB",
  "#932542",
  "#CF7287",
  "#BB51B7",
  "#11F444",
  "#A46BA5",
  "#D132D7",
  "#5F8483",
  "#04E6E0",
  "#8DAF24",
  "#F233E5",
  "#913C47",
  "#2A0FF5",
  "#E11F2B",
  "#001E94",
  "#E0B491",
  "#D13EF3",
  "#B5C143",
  "#F14012",
  "#3E2103",
  "#60A5E0",
  "#1B6A7C",
  "#A6F7A9",
  "#A18397",
  "#4152FC",
  "#FEC6B9",
  "#1EF614",
  "#442D20",
  "#487A33",
  "#8E7970",
  "#F94E82",
  "#521FB5",
  "#8F2097",
  "#88C4A1",
  "#34A8BB",
  "#37CA83",
  "#A5A8F9",
  "#6D7E27",
  "#F61067",
  "#824F45",
  "#8CDDB6",
  "#723BBB",
  "#34754D",
  "#3A54FD",
  "#53D4B6",
  "#3018A0",
  "#16CB08",
  "#5AAE1B",
  "#C4F5DA",
  "#49AA6B",
  "#F0D994",
  "#4E177B",
  "#DBB5DF",
  "#3F52B5",
  "#DF31D7",
  "#F97008",
  "#D70B48",
  "#A24756",
  "#9687F6",
  "#9827F1",
  "#B4BA7B",
  "#D5D8AF",
  "#25F7BA",
  "#E6E370",
  "#8670FB",
  "#C76CF0",
  "#3C3015",
  "#8FF105",
  "#7ADB4F",
  "#0431B2",
  "#B975AC",
  "#B5F4F5",
  "#0AB8EA",
  "#17050B",
  "#7693A1",
  "#509C2C",
  "#414BE1",
  "#137D33",
  "#2690AF",
  "#A334AD",
  "#8D225B",
  "#07FB7D",
  "#449AE6",
  "#56A8B1",
  "#79DB6E",
  "#AD900E",
  "#A051A1",
  "#76BDF4",
  "#E977CE",
  "#E6A13E",
  "#22A86B",
  "#3067F6",
  "#1F8E7F",
  "#2737D5",
  "#36DAC5",
  "#197CDD",
  "#7BA00E",
  "#C815F7",
  "#2D4D47",
  "#459DBF",
  "#C5E6D1",
  "#F82BAC",
  "#99D181",
  "#DF5161",
  "#09F66E",
  "#7FC38F",
  "#DA3FBD",
  "#FF10FD",
  "#657909",
  "#8E14C9",
  "#7EB8CA",
  "#BD2F0C",
  "#8FA5F6",
  "#3D1B71",
  "#B515EB",
  "#E6D9B6",
  "#6A72A5",
  "#98ACB7",
  "#6031AD",
  "#8D728B",
  "#9FA038",
  "#7A05F2",
  "#89E8F0",
  "#3A3CB2",
  "#31ABF9",
  "#81C02C",
  "#24BF98",
  "#69D07D",
  "#A474D3",
  "#B5EA13",
  "#88A021",
  "#004E76",
  "#BAF28B",
  "#E6F376",
  "#091CC8",
  "#4A3496",
  "#24B4F2",
  "#14EF74",
  "#15DBE1",
  "#B369A1",
  "#5404D0",
  "#A756ED",
  "#51C2A0",
  "#9644E5",
  "#5C0999",
  "#6C0CEC",
  "#C9B8D9",
  "#521126",
  "#B13333",
  "#25CA77",
  "#1CF0C3",
  "#401E2E",
  "#C2383D",
  "#9B33D9",
  "#BE348F",
  "#0D8D58",
  "#5A67C7",
  "#3CE649",
  "#F0CD85",
  "#B2CCBF",
  "#2E7C5B",
  "#A2DAA4",
  "#182893",
  "#D80DC1",
  "#6192D9",
  "#A4EB37",
  "#2EF495",
  "#5EEC5C",
  "#AECDF7",
  "#542FDF",
  "#E81F69",
  "#C4A0AD",
  "#25D7D0",
  "#8F0672",
  "#7DC42B",
  "#2A8B58",
  "#5B540F",
  "#B355CD",
  "#07CF3B",
  "#71A5EF",
  "#9DBAA4",
  "#C22D0F",
  "#4C91BC",
  "#975A79",
  "#84154D",
  "#04DAEF",
  "#64F7A7",
  "#ACF711",
  "#438CD3",
  "#963D3A",
  "#959BF0",
  "#8D23A4",
  "#5DCAFB",
  "#288542",
  "#0F604A",
  "#A61093",
  "#7900B6",
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        {/* <p className="label">{`${label} : ${payload[0].value} %`}</p> */}
        <p className="label">{`${payload[0].name} : # ${payload[0].value} `}</p>
      </div>
    );
  }

  return null;
};

const CustomTooltip1 = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip1">
        <p>{`${label}`}</p>
        <p>{`${payload[0].name} : ${payload[0].value} tweet per day `}</p>
      </div>
    );
  }

  return null;
};

const CustomTooltip2 = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        {/* <p className="label">{`${label} : ${payload[0].value} %`}</p> */}
        <p className="label">{`${payload[0].name} : ${payload[0].value} %`}</p>
      </div>
    );
  }

  return null;
};

// import "tippy.js/dist/tippy.css";
// import "tippy.js/animations/scale.css";
const options = {
  colors: ["#18ffff", "#00e5ff", "#00b8d4", "#ff9800", "#ffe0b2", "#ffcc80"],
  enableTooltip: true,
  deterministic: true,
  fontFamily: "impact",
  fontSizes: [20, 60],
  fontStyle: "normal",
  fontWeight: "bold",
  padding: 1,
  rotations: 3,
  rotationAngles: [0, 90],
  scale: "sqrt",
  spiral: "archimedean",
  transitionDuration: 1000,
  width: 700,
  height: 400,
};

class Dashboard extends Component {
  componentDidMount() {
    let { dispatch } = this.props;

    dispatch(fetchtwitterAnalysis());
    dispatch(fetchgetword());
    dispatch(fetchtwitterPostCount());
  }
  constructor() {
    super();
    this.state = {
      // isAddUserOpen: false,
      retweetopen: false,
      twittercount: false,
      twittersenti: false,
      twitterhash: false,
      twitterlang: false,
      twitteruserment: false,
      twittercontext: false,
      twitterpos: false,
      twitternegative: false,
      twitterneutral: false,
      twitterch: null,
    };
    // this.baseState = this.state;
    // this.handleOpenretweet = this.handleOpenretweet.bind(this);
    // this.handleCloseretweet = this.handleCloseretweet.bind(this);
  }

  static jsfiddleUrl = "https://jsfiddle.net/alidingling/3Leoa7f4/";

  handleMouseEnter = (o) => {
    const { dataKey } = o;
    const { opacity } = this.state;
    this.setState({
      opacity: { ...opacity, [dataKey]: 0.5 },
    });
  };

  handleMouseLeave = (o) => {
    const { dataKey } = o;
    const { opacity } = this.state;
    this.setState({
      opacity: { ...opacity, [dataKey]: 1 },
    });
  };

  handleOpenretweet = (e) => {
    e.preventDefault();
    this.setState({ retweetopen: true });
  };

  handleCloseretweet = (e) => {
    e.preventDefault();
    this.setState({ retweetopen: false });
  };

  handleOpentwittercount = (e) => {
    e.preventDefault();
    this.setState({ twittercount: true });
  };

  handleClosetwittercount = (e) => {
    e.preventDefault();
    this.setState({ twittercount: false });
  };

  handleOpentwittersenti = (e) => {
    e.preventDefault();
    this.setState({ twittersenti: true });
  };

  handleClosetwittersenti = (e) => {
    e.preventDefault();
    this.setState({ twittersenti: false });
  };

  handleOpentwitterhash = (e) => {
    e.preventDefault();
    this.setState({ twitterhash: true });
  };
  handleClosetwitterhash = (e) => {
    e.preventDefault();
    this.setState({ twitterhash: false });
  };

  handleOpentwitterlang = (e) => {
    e.preventDefault();
    this.setState({ twitterlang: true });
  };

  handleClosetwitterlang = (e) => {
    e.preventDefault();
    this.setState({ twitterlang: false });
  };

  handleOpentwitteruserment = (e) => {
    e.preventDefault();
    this.setState({ twitteruserment: true });
  };

  handleClosetwitteruserment = (e) => {
    e.preventDefault();
    this.setState({ twitteruserment: false });
  };

  handleOpentwittercontext = (e) => {
    e.preventDefault();
    this.setState({ twittercontext: true });
  };

  handleClosetwittercontext = (e) => {
    e.preventDefault();
    this.setState({ twittercontext: false });
  };

  handleOpentwitterpos = (e) => {
    e.preventDefault();
    this.setState({ twitterpos: true });
  };

  handleClosetwitterpos = (e) => {
    e.preventDefault();
    this.setState({ twitterpos: false });
  };

  handleOpentwitternegative = (e) => {
    e.preventDefault();
    this.setState({ twitternegative: true });
  };

  handleClosetwitternegative = (e) => {
    e.preventDefault();
    this.setState({ twitternegative: false });
  };

  handleOpentwitterneutral = (e) => {
    e.preventDefault();
    this.setState({ twitterneutral: true });
  };

  handleClosetwitterneutral = (e) => {
    e.preventDefault();
    this.setState({ twitterneutral: false });
  };

  twiterchangeWord = async (e) => {
    this.props.dispatch(fetchtwittersearch(e.target.value));
  };

  render() {
    const lang1 = localStorage.getItem("twsearch") || "default";
    let getWords = this.props.getwords || [];

    //context model
    var words = [];
    if (this.props.twitterAnalysis) {
      words = this.props.twitterAnalysis
        .find((item) => item.name.toLowerCase() === "context analysis")
        ?.report.context.map((word) => ({ text: word.tag, value: word.value }));
    }

    let twitterpostvalue = [];
    let twitternegative = [];
    let twitterneutral = [];

    let totalTweets = "--";
    let totalRetweets = "--";
    let totalFollowers = "--";

    let arr = [];
    if (this.props.twittersent) {
      let objs = this.props.twittersent.report || {};
      arr = Object.keys(objs).map((key) => ({
        name: i18next.t(key),
        value: Number(objs[key]),
      }));

      let twittercomments = this.props.twittersent?.comments;
      if (twittercomments) {
        twitterpostvalue = twittercomments["positive_comments"];
        twitternegative = twittercomments["negative_comments"];
        twitterneutral = twittercomments["neutral_comments"];
      }
    }

    if (this.props.twitterAnalysis) {
      let word = this.props.twitterAnalysis.find(
        (item) => item.name.toLowerCase() === "context analysis"
      )?.report.context;
      var x = word;
    }

    let chart = am4core.create("chartdiv", am4plugins_wordCloud.WordCloud);
    chart.logo.disabled = true;
    let series = chart.series.push(new am4plugins_wordCloud.WordCloudSeries());

    series.colors = new am4core.ColorSet();
    series.colors.passOptions = {};
    series.accuracy = 4;
    series.randomness = 0;
    series.heatRules.push({
      target: series.labels.template,
      property: "fill",
      min: am4core.color("#ff9800"),
      max: am4core.color("#00bcd4"),
      dataField: "value",
    });
    // series.step = 15;
    // series.rotationThreshold = 0.7;
    // series.maxCount = 200;
    // series.minWordLength = 2;
    series.labels.template.tooltipText = "{word}: {value}";
    // series.fontFamily = "Courier New";
    series.maxFontSize = am4core.percent(30);
    series.dataFields.word = "tag";
    series.dataFields.value = "value";
    series.data = x;

    //hashtag analysisone
    let arrsnone = [];
    let arrsntwo = [];
    let arrhash = [];

    //trend analysis
    let arrtrend = [];
    //trend analysis tweet count
    let arrtrendone = [];
    //language distcount
    let arrtrendtwo = [];

    if (this.props.twitterAnalysis && this.props.twitterAnalysis.length > 0) {
      const socialNetworkAnalysis = this.props.twitterAnalysis.find(
        (item) => item.name.toLowerCase() === "social network analysis"
      );
      if (socialNetworkAnalysis) {
        const socialNetworkAnalysisReport = socialNetworkAnalysis.report;

        let objsnone = socialNetworkAnalysisReport?.user_mentions || [];
        arrsnone = objsnone.map((item) => ({
          name: item.created_at,
          value: item.user_name.length,
        }));

        let objsntwo = socialNetworkAnalysisReport?.replied_screen_name || {};
        arrsntwo = Object.keys(objsntwo).map((key) => ({
          name: i18next.t(key),
          value: Number(objsntwo[key]),
        }));

        totalTweets = socialNetworkAnalysisReport?.total_tweets||"";
        totalRetweets = socialNetworkAnalysisReport?.total_retweets||"";
        totalFollowers = socialNetworkAnalysisReport?.followers_count||"";
      }

      const hashtagAnalysis = this.props.twitterAnalysis.find(
        (item) => item.name === ""
      );
      if (hashtagAnalysis) {
        const objhash = hashtagAnalysis?.report["hash_tags"] || {};
        arrhash = Object.keys(objhash).map((key) => ({
          name: key,
          value: Number(objhash[key]),
        }));
      }

      const trendAnalysis = this.props.twitterAnalysis.find(
        (item) => item.name.toLowerCase() === "trend analysis"
      );
      if (trendAnalysis) {
        let objtrend = trendAnalysis?.report?.re_tweet_distribution;
        arrtrend = objtrend; //Object.keys(objtrend).map(key => ({name: key, distribution: objtrend[key]}))

        let objtrendtwo = trendAnalysis?.report?.language_distribution || {};
        arrtrendtwo = Object.keys(objtrendtwo).map((key) => ({
          language: i18next.t(key),
          count: Number(objtrendtwo[key]),
        }));
      }
    }

    if (this.props.twitterPostCount) {
      let posts = this.props.twitterPostCount["no of posts"] || {};
      if (posts) {
        arrtrendone = Object.keys(posts).map((key) => ({
          name: key.slice(0, 10),
          count: posts[key],
        }));
      }
    }

    const twitterfileName = "comments";

    return (
      <div
        style={{
          flexGrow: "1",
          paddingLeft: "20px",
          paddingRight: "20px",
          paddingTop: "100px",
        }}
        className="body"
      >
        <Toolbar variant="dense">
          <Typography
            variant="h5"
            style={{ flexGrow: "1", marginBottom: "10px" }}
          >
            {i18next.t("Twitter Analysis")}
          </Typography>
          <Breadcrumbs aria-label="breadcrumb" textalign="right">
            <Link color="inherit">{i18next.t("Dashboard")}</Link>

            <Typography color="textPrimary">
              {i18next.t("Twitter Analysis")}{" "}
            </Typography>
          </Breadcrumbs>
        </Toolbar>

        <CommentsModal
          title="Positive Comments"
          open={this.state.twitterpos}
          handleCloseModal={this.handleClosetwitterpos}
          comments={twitterpostvalue}
          fileName={twitterfileName}
        />

        <CommentsModal
          title="Negative Comments"
          open={this.state.twitternegative}
          handleCloseModal={this.handleClosetwitternegative}
          comments={twitternegative}
          fileName={twitterfileName}
        />

        <CommentsModal
          title="Neutral Comments"
          open={this.state.twitterneutral}
          handleCloseModal={this.handleClosetwitterneutral}
          comments={twitterneutral}
          fileName={twitterfileName}
        />

        <Modal open={this.state.retweetopen} onClose={this.handleCloseretweet}>
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                // height:"5vw",
                // background: "#90caf9",
                padding: "10px",
                // textAlignVertical: "center",
              }}
            >
              <Typography>{i18next.t("")}</Typography>
              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleCloseretweet}>
                  <CloseIcon />
                </IconButton>
              </div>

              {/* <button onClick={() => window.print()}>PRINT</button> */}
              <ResponsiveContainer height={800} width={1800}>
                <LineChart
                  width={500}
                  height={200}
                  data={
                    this.props.twitterAnalysis !== undefined ? (
                      arrtrend
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  margin={{
                    top: 10,
                    right: 30,
                    left: 0,
                    bottom: 0,
                  }}
                >
                    
                 <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="created_at" />
                  <YAxis />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  <Line
                    type="monotone"
                    dataKey="retweet_count"
                    stroke="#00aced"
                    fill="#ff9800"
                  />
                  <Legend layout="vertical" verticalAlign="top" align="right" />
                </LineChart>
              </ResponsiveContainer>
            </Paper>
          </div>
        </Modal>

        <PostCountBarChartModal
          dataArray={arrtrendone}
          open={this.state.twittercount}
          title="Twitter Count"
          datekey="name"
          countkey="count"
          handleClose={this.handleClosetwittercount}
        />

        <SentimentalPieChartModal
          dataArray={arr}
          open={this.state.twittersenti}
          title="Sentimental Analysis"
          handleClose={this.handleClosetwittersenti}
        />

        <Modal
          open={this.state.twitterhash}
          onClose={this.handleClosetwitterhash}
        >
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                // height:"5vw",
                // background: "#90caf9",
                padding: "10px",
                // textAlignVertical: "center",
              }}
            >
              <Typography>{i18next.t("HashTag Analysis")}</Typography>
              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleClosetwitterhash}>
                  <CloseIcon />
                </IconButton>
              </div>
              <ResponsiveContainer height={800} width={1800}>
                <PieChart width={500} height={200}>
                  <Pie
                    data={
                      this.props.twitterAnalysis !== undefined ? (
                        arrhash
                      ) : (
                        <p>
                          <CircularProgress />
                        </p>
                      )
                    }
                    cx={900}
                    cy={350}
                    labelLine={true}
                    label
                    outerRadius={275}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {arrhash.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                    label
                  </Pie>
                  <Legend  verticalAlign="top" align="right" />
                  <Tooltip content={<CustomTooltip />} />

                 
                </PieChart>
              </ResponsiveContainer>

              {/* <h2 align="center">HASHTAG ANALYSIS</h2> */}
            </Paper>
          </div>
        </Modal>
        <Modal
          open={this.state.twitterlang}
          onClose={this.handleClosetwitterlang}
        >
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                // height:"5vw",
                // background: "#90caf9",
                padding: "10px",
                // textAlignVertical: "center",
              }}
            >
              <Typography>{i18next.t("Language Distribution")} </Typography>
              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleClosetwitterlang}>
                  <CloseIcon />
                </IconButton>
              </div>
              <ResponsiveContainer height={800} width={1800}>
                <BarChart
                  width={500}
                  height={300}
                  data={
                    this.props.twitterAnalysis !== undefined ? (
                      arrtrendtwo
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                  barSize={50}
                >
                  <XAxis
                    dataKey="language"
                    scale="point"
                    padding={{ left: 10, right: 10 }}
                    >
                    <Label value={"Language --->"} offset={-2} position="insideBottom"/> 
                  </XAxis>
                  <YAxis />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  <Legend />
                  <CartesianGrid strokeDasharray="3 3" />
                  <Bar
                    dataKey="count"
                    fill="#00aced"
                    background={{ fill: "#eee" }}
                    name="Count"
                  />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </div>
        </Modal>
        <Modal
          open={this.state.twitteruserment}
          onClose={this.handleClosetwitteruserment}
        >
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                // height:"5vw",
                // background: "#90caf9",
                padding: "10px",
                // textAlignVertical: "center",
              }}
            >
              <Typography>
                {" "}
	    {i18next.t("Social Network Analysis")}
              </Typography>
              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleClosetwitteruserment}>
                  <CloseIcon />
                </IconButton>
              </div>
              {/* <Typography>User mentions</Typography> */}
              <ResponsiveContainer height={800} width={1800}>
                <BarChart
                  width={500}
                  height={300}
                  data={
                    this.props.twitterAnalysis !== undefined ? (
                      arrsnone
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  layout="vertical"
                  // margin={{
                  //   top: 5,
                  //   right: 30,
                  //   left: 20,
                  //   bottom: 5,
                  // }}
                  // barSize={20}
                >
                  <XAxis
                    type="number"
                    // hide
                    dataKey="value">
                    <Label value={"Language --->"} offset={-2} position="insideBottom"/> 
                  </XAxis>
                  <YAxis
                    type="category"
                    // hide
                    dataKey="name"
                    //   scale="point"
                    //   padding={{ left: 10, right: 10 }}
                  />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  {/* <Legend /> */}
                  <CartesianGrid strokeDasharray="3 3" />
                  <Bar
                    dataKey="value"
                    fill="#00aced"
                    background={{ fill: "#eee" }}
                    
                  />
                </BarChart>
              </ResponsiveContainer>

              {/* <h2 align="center">SENTIMENTAL ANALYSIS</h2> */}
            </Paper>
          </div>
        </Modal>
        <Modal
          open={this.state.twittercontext}
          onClose={this.handleClosetwittercontext}
        >
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                // height:"5vw",
                // background: "#90caf9",
                padding: "10px",
                // textAlignVertical: "center",
              }}
            >
              <Typography>{i18next.t(" Contextual Analysis----")} </Typography>

              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleClosetwittercontext}>
                  <CloseIcon />
                </IconButton>
              </div>

              <div style={{ width: "1800px", height: "800px" }}>
                <ReactWordcloud options={options} words={words} />
              </div>
            </Paper>
          </div>
        </Modal>

        <Grid container spacing={3} justify="space-between">
          <MetricWidget
            iconType="twitter"
            backgroundColor="#00aced"
            // backgroundColor="#517FA3"
            name="Tweets"
            count={totalTweets}
          />

          <MetricWidget
            iconType="twitter"
            backgroundColor="#00aced"
            // backgroundColor="#C23584"
            name="Retweets"
            count={totalRetweets}
          />

          <MetricWidget
            iconType="twitter"
            backgroundColor="#00aced"
            // backgroundColor="#F77736"
            name="Followers"
            count={totalFollowers}
          />
        </Grid>
        {/* Three widgets end */}

        {/* </AppBar> */}
        <br />

        <div class="row mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
               
                  paddingBottom: "10px",
                }}
              >
                <div class="d-flex bd-highlight">
                  <div class="mr-auto pt-2 bd-highlight">
                    {i18next.t("Contextual Analysis")}
                  </div>
                  <div class="bd-highlight">
                    <div align="right">
                      <Button
                        // variant="contained"
                        // color="primary"
                        onClick={this.handleOpentwittercontext}
                      >
                        <ZoomOutMapIcon />
                      </Button>
                    </div>
                  </div>
                </div>
              </Typography>

              <div
                id={
                  "chartdiv" ? (
                    "chartdiv"
                  ) : (
                    <p>
                      {" "}
                      <CircularProgress />
                    </p>
                  )
                }
                style={{
                  width: "100%",
                  height: "400px",
                  textAlign: "center",
                  verticalAlign: "middle",
                  // marginTop:"23%"
                }}
              ></div>
            </Paper>
          </div>
          <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
          <ResponsiveContainer height={300} width="100%">
            <SentimentalPieChart
              dataArray={arr}
              title="Twitter Sentimental Analysis"
              handleOpenPositive={this.handleOpentwitterpos}
              handleOpenNegative={this.handleOpentwitternegative}
              handleOpenNeutral={this.handleOpentwitterneutral}
              handleChangeWord={this.twiterchangeWord}
              language={lang1}
              words={getWords}
              handleZoomout={this.handleOpentwittersenti}
            />
              </ResponsiveContainer>
          </div>
          {/* Hashtag analysis start */}
          <div class="col-12 col-sm-12 col-md-12 col-lg-4 col-xl-4">
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                  paddingBottom: "10px",
                }}
              >
                <div class="d-flex bd-highlight ">
                  <div class="mr-auto pt-2 bd-highlight">
                    {" "}
                    {i18next.t("Hash Tag Analysis")}
                  </div>
                  <div class=" bd-highlight">
                    {" "}
                    <Button
                      // variant="contained"
                      // color="primary"
                      onClick={this.handleOpentwitterhash}
                    >
                      <ZoomOutMapIcon />
                    </Button>
                  </div>
                </div>
              </Typography>

              <ResponsiveContainer height={400} width="100%">
                <PieChart width={250} height={250}>
                  <Pie
                    data={
                      this.props.twitterAnalysis !== undefined ? (
                        arrhash
                      ) : (
                        <p>
                          <CircularProgress />
                        </p>
                      )
                    }
                    // cx={110}
                    // cy={100}
                    labelLine={false}
                    // label={renderCustomizedLabel}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {arrhash.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />

                  {/* <Legend layout="vertical" verticalAlign="top" align="right" /> */}
                </PieChart>
              </ResponsiveContainer>

              {/* <h2 align="center">HASHTAG ANALYSIS</h2> */}
            </Paper>
          </div>
        </div>

        <div class="row mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                  paddingBottom: "10px",
                  marginBottom: "10px",
                }}
              >
                <div class="d-flex bd-highlight ">
                  <div class="mr-auto pt-2 bd-highlight">
                    {" "}
                    {i18next.t("Language Distribution")}
                  </div>
                  <div class=" bd-highlight">
                    {" "}
                    <Button
                      // variant="contained"
                      // color="primary"
                      onClick={this.handleOpentwitterlang}
                    >
                      <ZoomOutMapIcon />
                    </Button>
                  </div>
                </div>
              </Typography>

              <ResponsiveContainer height={392} width="100%">
                <BarChart
                  width={500}
                  height={300}
                  data={
                    this.props.twitterAnalysis !== undefined ? (
                      arrtrendtwo
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  margin={{
                    top: 5,
                    right: 30,
                    left: 0,
                    bottom: 5,
                  }}
                  barSize={20}
                >
                  <XAxis
                    dataKey="language"
                    scale="point"
                    padding={{ left: 40, right: 20 }} >

                <Label value={"Language --->"} offset={-2} position="insideBottom"/> 
                </XAxis>
                  <YAxis />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  {/* <Tooltip content={<CustomTooltip />} /> */}
                  <Legend verticalAlign="top"/>
                  <Bar
                    dataKey="count"
                    fill="#00aced"
                    background={{ fill: "#eee" }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </div>

          <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-7">
            <PostCountBarChart
              dataArray={arrtrendone}
              title="Twitter Count"
              datekey="name"
              countkey="count"
              totalPosts="----"
              handleZoomout={this.handleOpentwittercount}
              labelling="Count"
              />
          </div>
        </div>

        <div class="row  mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                  paddingBottom: "10px",
                  marginBottom: "10px",
                }}
              >
                <div class="d-flex bd-highlight ">
                  <div class="mr-auto pt-2 bd-highlight">
                    {" "}
                    {i18next.t("Retweet distribution")}
                  </div>
                  <div class=" bd-highlight">
                    {" "}
                    <Button
                      // variant="contained"
                      // color="primary"
                      onClick={this.handleOpenretweet}
                    >
                      <ZoomOutMapIcon />
                    </Button>
                  </div>
                </div>
              </Typography>

              <ResponsiveContainer height={250} width="100%">
                <LineChart
                  width={500}
                  height={200}
                  data={
                    this.props.twitterAnalysis !== undefined ? (
                      arrtrend
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  margin={{
                    top: 0,
                    right: 30,
                    left: 0,
                    bottom: 10,
                  }}
                >
                  <Legend layout="vertical" verticalAlign="top" align="right" />
                  {/* <CartesianGrid strokeDasharray="3 3" /> */}
                  <XAxis dataKey="created_at" 
                  >
                  <Label value={"Date--->"} offset={0} position="insideBottom"/> 
                </XAxis>
                  <YAxis />
                  <Tooltip
                    cursor={{ fill: "#03a9f4" }}
                    contentStyle={{ color: "#143491" }}
                  />
                  <Line
                    type="monotone"
                    dataKey="retweet_count"
                    stroke="#00aced"
                    fill="#ff9800"
                    name="Retweet Count"
                  />
                </LineChart>
              </ResponsiveContainer>
            </Paper>
          </div>

          <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-7">
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                  paddingBottom: "10px",
                  marginBottom: "10px",
                }}
              >
                

                <div class="d-flex bd-highlight">
                  <div class="mr-auto pt-2 bd-highlight">
                    {" "}
                    {i18next.t("Social Network Analysis")}
                  </div>
                  <div class=" bd-highlight">
                    {" "}
                    <Button
                      // variant="contained"
                      // color="primary"
                      onClick={this.handleOpentwitteruserment}
                    >
                      <ZoomOutMapIcon />
                    </Button>
                  </div>
                </div>
              </Typography>

              <ResponsiveContainer height={250} width="100%">
                <BarChart
                  width={500}
                  height={300}
                  data={
                    this.props.twitterAnalysis !== undefined ? (
                      arrsnone
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  layout="vertical"
                  margin={{
                    top: 5,
                    right: 30,
                    left: 40,
                    bottom: 10,
                  }}
                  // barSize={20}
                >
                  <XAxis
                    type="number"
                    // hide
                    dataKey="value"
                    // scale="point"
                    // padding={{ left: 10, right: 10 }}
                    >
                    <Label value={"Value --->"} offset={-2} position="insideBottom"/> 
                  </XAxis>
                  <YAxis
                    type="category"
                    // hide
                    dataKey="name"
                    //   scale="point"
                    //   padding={{ left: 10, right: 10 }}
                  />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  {/* <Legend /> */}
                  {/* <CartesianGrid strokeDasharray="3 3" /> */}
                  <Bar
                    dataKey="value"
                    fill="#00aced"
                    background={{ fill: "#eee" }}
                  />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  if (state.twitterAnalysis && state.getword && state.twitterPostCount) {
    return {
      twitterAnalysis: state.twitterAnalysis ? state.twitterAnalysis : [],
      twittersent: state.twitterAnalysis
        ? state.twitterAnalysis.find(
            (obj) => obj.name.toLowerCase() === "sentimental analysis"
          )
        : {},
      twitterPostCount: state.twitterPostCount ? state.twitterPostCount : [],
      getwords: state.getword ? state.getword : [],
    };
  } else {
    console.log("No data found");
  }
}
export default withRouter(connect(mapStateToProps)(Dashboard));
