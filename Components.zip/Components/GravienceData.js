export const GrevienceData=[
    {
        "SrNo.": "1",
        "TokenNumber": "H131554",
        "OpenDate": "01/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2",
        "TokenNumber": "H131556",
        "OpenDate": "01/01/2020",
        "CloseDate": "02/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3",
        "TokenNumber": "H131557",
        "OpenDate": "01/01/2020",
        "CloseDate": "04/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4",
        "TokenNumber": "H131559",
        "OpenDate": "01/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "5",
        "TokenNumber": "H131560",
        "OpenDate": "01/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "6",
        "TokenNumber": "H131563",
        "OpenDate": "01/01/2020",
        "CloseDate": "02/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "7",
        "TokenNumber": "H131565",
        "OpenDate": "01/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "8",
        "TokenNumber": "H131566",
        "OpenDate": "01/01/2020",
        "CloseDate": "01/01/2020",
        "CompletionTime": "0",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "9",
        "TokenNumber": "H131571",
        "OpenDate": "01/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "10",
        "TokenNumber": "H131568",
        "OpenDate": "01/01/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "77",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "11",
        "TokenNumber": "H131573",
        "OpenDate": "01/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "12",
        "TokenNumber": "H131574",
        "OpenDate": "01/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "68",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "13",
        "TokenNumber": "H131575",
        "OpenDate": "01/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "14",
        "TokenNumber": "H131577",
        "OpenDate": "01/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "15",
        "TokenNumber": "H131579",
        "OpenDate": "01/01/2020",
        "CloseDate": "02/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "16",
        "TokenNumber": "H131583",
        "OpenDate": "01/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "12",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "17",
        "TokenNumber": "H131587",
        "OpenDate": "01/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "18",
        "TokenNumber": "H131588",
        "OpenDate": "01/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "19",
        "TokenNumber": "H131590",
        "OpenDate": "01/01/2020",
        "CloseDate": "01/01/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "20",
        "TokenNumber": "H131593",
        "OpenDate": "01/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "26",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "21",
        "TokenNumber": "H131596",
        "OpenDate": "01/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "22",
        "TokenNumber": "H131599",
        "OpenDate": "01/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "23",
        "TokenNumber": "H131598",
        "OpenDate": "01/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "24",
        "TokenNumber": "H131600",
        "OpenDate": "01/01/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "61",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "25",
        "TokenNumber": "H131601",
        "OpenDate": "01/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "26",
        "TokenNumber": "H131602",
        "OpenDate": "01/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "27",
        "TokenNumber": "H131603",
        "OpenDate": "01/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "28",
        "TokenNumber": "H131604",
        "OpenDate": "01/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "29",
        "TokenNumber": "H131605",
        "OpenDate": "01/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "30",
        "TokenNumber": "H131606",
        "OpenDate": "02/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "31",
        "TokenNumber": "H131607",
        "OpenDate": "02/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "32",
        "TokenNumber": "H131609",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "33",
        "TokenNumber": "H131611",
        "OpenDate": "02/01/2020",
        "CloseDate": "02/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "34",
        "TokenNumber": "H131612",
        "OpenDate": "02/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "35",
        "TokenNumber": "H131613",
        "OpenDate": "02/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "36",
        "TokenNumber": "H131615",
        "OpenDate": "02/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "37",
        "TokenNumber": "H131614",
        "OpenDate": "02/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "38",
        "TokenNumber": "H131617",
        "OpenDate": "02/01/2020",
        "CloseDate": "04/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "39",
        "TokenNumber": "H131618",
        "OpenDate": "02/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "40",
        "TokenNumber": "H131620",
        "OpenDate": "02/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "41",
        "TokenNumber": "H131619",
        "OpenDate": "02/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "42",
        "TokenNumber": "H131621",
        "OpenDate": "02/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "27",
        "Subject": "Illegal Hording / Flex",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "43",
        "TokenNumber": "H131625",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "44",
        "TokenNumber": "H131627",
        "OpenDate": "02/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "45",
        "TokenNumber": "H131629",
        "OpenDate": "02/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "46",
        "TokenNumber": "H131632",
        "OpenDate": "02/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "47",
        "TokenNumber": "H131631",
        "OpenDate": "02/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "26",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "48",
        "TokenNumber": "H131630",
        "OpenDate": "02/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "49",
        "TokenNumber": "H131633",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "50",
        "TokenNumber": "H131057",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "51",
        "TokenNumber": "H131636",
        "OpenDate": "02/01/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "60",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "52",
        "TokenNumber": "H131637",
        "OpenDate": "02/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "53",
        "TokenNumber": "H131638",
        "OpenDate": "02/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "54",
        "TokenNumber": "H131641",
        "OpenDate": "02/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "55",
        "TokenNumber": "H131643",
        "OpenDate": "02/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "56",
        "TokenNumber": "H131646",
        "OpenDate": "02/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "57",
        "TokenNumber": "H131651",
        "OpenDate": "02/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "58",
        "TokenNumber": "H131650",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "59",
        "TokenNumber": "H131652",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "60",
        "TokenNumber": "H131653",
        "OpenDate": "02/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "61",
        "TokenNumber": "H131656",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "62",
        "TokenNumber": "H131658",
        "OpenDate": "02/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "26",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "63",
        "TokenNumber": "H131665",
        "OpenDate": "02/01/2020",
        "CloseDate": "03/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "64",
        "TokenNumber": "H131664",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "65",
        "TokenNumber": "H131667",
        "OpenDate": "02/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "66",
        "TokenNumber": "H131669",
        "OpenDate": "02/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "67",
        "TokenNumber": "H131670",
        "OpenDate": "02/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "68",
        "TokenNumber": "H131671",
        "OpenDate": "02/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "69",
        "TokenNumber": "H131672",
        "OpenDate": "02/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "16",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "70",
        "TokenNumber": "H131674",
        "OpenDate": "02/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "11",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "71",
        "TokenNumber": "H131675",
        "OpenDate": "02/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "72",
        "TokenNumber": "H131677",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "73",
        "TokenNumber": "H131679",
        "OpenDate": "02/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "74",
        "TokenNumber": "H131680",
        "OpenDate": "02/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "75",
        "TokenNumber": "H131681",
        "OpenDate": "02/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "76",
        "TokenNumber": "H131683",
        "OpenDate": "02/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "77",
        "TokenNumber": "H131684",
        "OpenDate": "02/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "26",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "78",
        "TokenNumber": "H131686",
        "OpenDate": "02/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "79",
        "TokenNumber": "H131687",
        "OpenDate": "02/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "80",
        "TokenNumber": "H131690",
        "OpenDate": "03/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "81",
        "TokenNumber": "H131691",
        "OpenDate": "03/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "82",
        "TokenNumber": "H131692",
        "OpenDate": "03/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "83",
        "TokenNumber": "H131695",
        "OpenDate": "03/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "84",
        "TokenNumber": "H131697",
        "OpenDate": "03/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "85",
        "TokenNumber": "H131699",
        "OpenDate": "03/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "86",
        "TokenNumber": "H131689",
        "OpenDate": "03/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "87",
        "TokenNumber": "H131700",
        "OpenDate": "03/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "88",
        "TokenNumber": "H131703",
        "OpenDate": "03/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "89",
        "TokenNumber": "H131705",
        "OpenDate": "03/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "90",
        "TokenNumber": "H131704",
        "OpenDate": "03/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "91",
        "TokenNumber": "H131706",
        "OpenDate": "03/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "92",
        "TokenNumber": "H131707",
        "OpenDate": "03/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "93",
        "TokenNumber": "H131709",
        "OpenDate": "03/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "94",
        "TokenNumber": "H131710",
        "OpenDate": "03/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "95",
        "TokenNumber": "H131712",
        "OpenDate": "03/01/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "103",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "96",
        "TokenNumber": "H131714",
        "OpenDate": "03/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "97",
        "TokenNumber": "H131713",
        "OpenDate": "03/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "24",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "98",
        "TokenNumber": "H131720",
        "OpenDate": "03/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "99",
        "TokenNumber": "H131723",
        "OpenDate": "03/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "100",
        "TokenNumber": "H131724",
        "OpenDate": "03/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "101",
        "TokenNumber": "H131725",
        "OpenDate": "03/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "102",
        "TokenNumber": "H131726",
        "OpenDate": "03/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "11",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "103",
        "TokenNumber": "H131730",
        "OpenDate": "03/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "104",
        "TokenNumber": "H131732",
        "OpenDate": "03/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "105",
        "TokenNumber": "H131733",
        "OpenDate": "03/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "106",
        "TokenNumber": "H131735",
        "OpenDate": "03/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "107",
        "TokenNumber": "H131737",
        "OpenDate": "03/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "108",
        "TokenNumber": "H131739",
        "OpenDate": "03/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "109",
        "TokenNumber": "H131740",
        "OpenDate": "03/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "110",
        "TokenNumber": "H131744",
        "OpenDate": "03/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "19",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "111",
        "TokenNumber": "H131746",
        "OpenDate": "03/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "112",
        "TokenNumber": "H131750",
        "OpenDate": "03/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "113",
        "TokenNumber": "H131752",
        "OpenDate": "04/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "114",
        "TokenNumber": "H131753",
        "OpenDate": "04/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "115",
        "TokenNumber": "H131754",
        "OpenDate": "04/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "116",
        "TokenNumber": "H131755",
        "OpenDate": "04/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "117",
        "TokenNumber": "H131756",
        "OpenDate": "04/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "2",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "118",
        "TokenNumber": "H131758",
        "OpenDate": "04/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "119",
        "TokenNumber": "H131759",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "120",
        "TokenNumber": "H131762",
        "OpenDate": "04/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "121",
        "TokenNumber": "H131764",
        "OpenDate": "04/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "122",
        "TokenNumber": "H131765",
        "OpenDate": "04/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "123",
        "TokenNumber": "H131766",
        "OpenDate": "04/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "124",
        "TokenNumber": "H131768",
        "OpenDate": "04/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "9",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "125",
        "TokenNumber": "H131774",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "126",
        "TokenNumber": "H131775",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "127",
        "TokenNumber": "H131777",
        "OpenDate": "04/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "128",
        "TokenNumber": "H131784",
        "OpenDate": "04/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "129",
        "TokenNumber": "H131783",
        "OpenDate": "04/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "130",
        "TokenNumber": "H131786",
        "OpenDate": "04/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "131",
        "TokenNumber": "H131789",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "132",
        "TokenNumber": "H131790",
        "OpenDate": "04/01/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "102",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "133",
        "TokenNumber": "H131791",
        "OpenDate": "04/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "134",
        "TokenNumber": "H131792",
        "OpenDate": "04/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "135",
        "TokenNumber": "H131796",
        "OpenDate": "04/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "136",
        "TokenNumber": "H131798",
        "OpenDate": "04/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "137",
        "TokenNumber": "H131799",
        "OpenDate": "04/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "24",
        "Subject": "Irregular Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "138",
        "TokenNumber": "H131801",
        "OpenDate": "04/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "139",
        "TokenNumber": "H131803",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "140",
        "TokenNumber": "H131805",
        "OpenDate": "04/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "141",
        "TokenNumber": "H131806",
        "OpenDate": "04/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "142",
        "TokenNumber": "H131807",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "143",
        "TokenNumber": "H131809",
        "OpenDate": "04/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "144",
        "TokenNumber": "H131810",
        "OpenDate": "04/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "28",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "145",
        "TokenNumber": "H131811",
        "OpenDate": "04/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "146",
        "TokenNumber": "H131812",
        "OpenDate": "04/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "147",
        "TokenNumber": "H131813",
        "OpenDate": "04/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "148",
        "TokenNumber": "H131814",
        "OpenDate": "04/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "149",
        "TokenNumber": "H131817",
        "OpenDate": "04/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "150",
        "TokenNumber": "H131821",
        "OpenDate": "04/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "151",
        "TokenNumber": "H131822",
        "OpenDate": "04/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "152",
        "TokenNumber": "H131823",
        "OpenDate": "04/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "153",
        "TokenNumber": "H131824",
        "OpenDate": "05/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "154",
        "TokenNumber": "H131833",
        "OpenDate": "05/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "155",
        "TokenNumber": "H131834",
        "OpenDate": "05/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "156",
        "TokenNumber": "H131836",
        "OpenDate": "05/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "157",
        "TokenNumber": "H131838",
        "OpenDate": "05/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "158",
        "TokenNumber": "H131839",
        "OpenDate": "05/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "159",
        "TokenNumber": "H131840",
        "OpenDate": "05/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "160",
        "TokenNumber": "H131844",
        "OpenDate": "05/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "161",
        "TokenNumber": "H131846",
        "OpenDate": "05/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "162",
        "TokenNumber": "H131848",
        "OpenDate": "05/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "163",
        "TokenNumber": "H131849",
        "OpenDate": "05/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "164",
        "TokenNumber": "H131853",
        "OpenDate": "05/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "165",
        "TokenNumber": "H131855",
        "OpenDate": "05/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "166",
        "TokenNumber": "H131856",
        "OpenDate": "05/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "167",
        "TokenNumber": "H131857",
        "OpenDate": "05/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "168",
        "TokenNumber": "H131858",
        "OpenDate": "05/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "169",
        "TokenNumber": "H131860",
        "OpenDate": "05/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "170",
        "TokenNumber": "H131843",
        "OpenDate": "05/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "171",
        "TokenNumber": "H131862",
        "OpenDate": "05/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "172",
        "TokenNumber": "H131863",
        "OpenDate": "05/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "173",
        "TokenNumber": "H131864",
        "OpenDate": "05/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "174",
        "TokenNumber": "H131865",
        "OpenDate": "05/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "175",
        "TokenNumber": "H131866",
        "OpenDate": "05/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "176",
        "TokenNumber": "H131867",
        "OpenDate": "05/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "177",
        "TokenNumber": "H131868",
        "OpenDate": "05/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "178",
        "TokenNumber": "H131871",
        "OpenDate": "05/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "179",
        "TokenNumber": "H131872",
        "OpenDate": "05/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "180",
        "TokenNumber": "H131875",
        "OpenDate": "05/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "181",
        "TokenNumber": "H131876",
        "OpenDate": "05/01/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "89",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "182",
        "TokenNumber": "H131878",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "183",
        "TokenNumber": "H131879",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "184",
        "TokenNumber": "H131880",
        "OpenDate": "06/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "185",
        "TokenNumber": "H131882",
        "OpenDate": "06/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "186",
        "TokenNumber": "H131881",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "187",
        "TokenNumber": "H131883",
        "OpenDate": "06/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "188",
        "TokenNumber": "H131884",
        "OpenDate": "06/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "189",
        "TokenNumber": "H131885",
        "OpenDate": "06/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "190",
        "TokenNumber": "H131887",
        "OpenDate": "06/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "191",
        "TokenNumber": "H131886",
        "OpenDate": "06/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "192",
        "TokenNumber": "H131888",
        "OpenDate": "06/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "193",
        "TokenNumber": "H131889",
        "OpenDate": "06/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "194",
        "TokenNumber": "H131891",
        "OpenDate": "06/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "195",
        "TokenNumber": "H131892",
        "OpenDate": "06/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "196",
        "TokenNumber": "H131893",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "197",
        "TokenNumber": "H131894",
        "OpenDate": "06/01/2020",
        "CloseDate": "06/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "198",
        "TokenNumber": "H131896",
        "OpenDate": "06/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "199",
        "TokenNumber": "H131898",
        "OpenDate": "06/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "2",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "200",
        "TokenNumber": "H131899",
        "OpenDate": "06/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "201",
        "TokenNumber": "H131901",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "202",
        "TokenNumber": "H131905",
        "OpenDate": "06/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "203",
        "TokenNumber": "H131908",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "204",
        "TokenNumber": "H131909",
        "OpenDate": "06/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "23",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "205",
        "TokenNumber": "H131912",
        "OpenDate": "06/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "206",
        "TokenNumber": "H131913",
        "OpenDate": "06/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "207",
        "TokenNumber": "H131914",
        "OpenDate": "06/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "208",
        "TokenNumber": "H131917",
        "OpenDate": "06/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "22",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "209",
        "TokenNumber": "H131918",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "210",
        "TokenNumber": "H131920",
        "OpenDate": "06/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "211",
        "TokenNumber": "H131919",
        "OpenDate": "06/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "212",
        "TokenNumber": "H131922",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "213",
        "TokenNumber": "ZR4239",
        "OpenDate": "06/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "214",
        "TokenNumber": "H131923",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "215",
        "TokenNumber": "H131925",
        "OpenDate": "06/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "216",
        "TokenNumber": "H131926",
        "OpenDate": "06/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "217",
        "TokenNumber": "H131927",
        "OpenDate": "06/01/2020",
        "CloseDate": "07/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "218",
        "TokenNumber": "H131929",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "219",
        "TokenNumber": "H131930",
        "OpenDate": "06/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "26",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "220",
        "TokenNumber": "H131932",
        "OpenDate": "06/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "221",
        "TokenNumber": "H131933",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "222",
        "TokenNumber": "H131935",
        "OpenDate": "06/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "223",
        "TokenNumber": "H131938",
        "OpenDate": "06/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "224",
        "TokenNumber": "H131944",
        "OpenDate": "06/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "225",
        "TokenNumber": "H131949",
        "OpenDate": "06/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "226",
        "TokenNumber": "H131951",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "227",
        "TokenNumber": "H131952",
        "OpenDate": "06/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "228",
        "TokenNumber": "H131953",
        "OpenDate": "06/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "229",
        "TokenNumber": "H131954",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "230",
        "TokenNumber": "H131956",
        "OpenDate": "06/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "231",
        "TokenNumber": "H131958",
        "OpenDate": "06/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "16",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "232",
        "TokenNumber": "H131960",
        "OpenDate": "06/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "233",
        "TokenNumber": "H131963",
        "OpenDate": "06/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "14",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "234",
        "TokenNumber": "H131964",
        "OpenDate": "06/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "235",
        "TokenNumber": "H131966",
        "OpenDate": "07/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "236",
        "TokenNumber": "H131969",
        "OpenDate": "07/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "237",
        "TokenNumber": "H131971",
        "OpenDate": "07/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "238",
        "TokenNumber": "H131973",
        "OpenDate": "07/01/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "69",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "239",
        "TokenNumber": "H131974",
        "OpenDate": "07/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "240",
        "TokenNumber": "H131977",
        "OpenDate": "07/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "241",
        "TokenNumber": "H131981",
        "OpenDate": "07/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "8",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "242",
        "TokenNumber": "H131980",
        "OpenDate": "07/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "243",
        "TokenNumber": "H131984",
        "OpenDate": "07/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "244",
        "TokenNumber": "H131988",
        "OpenDate": "07/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "245",
        "TokenNumber": "H131979",
        "OpenDate": "07/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "20",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "246",
        "TokenNumber": "H131989",
        "OpenDate": "07/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "247",
        "TokenNumber": "H131991",
        "OpenDate": "07/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "248",
        "TokenNumber": "H131992",
        "OpenDate": "07/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "249",
        "TokenNumber": "H131994",
        "OpenDate": "07/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "250",
        "TokenNumber": "H131995",
        "OpenDate": "07/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "251",
        "TokenNumber": "H131998",
        "OpenDate": "07/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "252",
        "TokenNumber": "H132001",
        "OpenDate": "07/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "253",
        "TokenNumber": "H132002",
        "OpenDate": "07/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "254",
        "TokenNumber": "H132003",
        "OpenDate": "07/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "255",
        "TokenNumber": "H132004",
        "OpenDate": "07/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "256",
        "TokenNumber": "H132006",
        "OpenDate": "07/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "257",
        "TokenNumber": "H132007",
        "OpenDate": "07/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "258",
        "TokenNumber": "H132009",
        "OpenDate": "07/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "15",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "259",
        "TokenNumber": "H132010",
        "OpenDate": "07/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "260",
        "TokenNumber": "H132011",
        "OpenDate": "07/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "261",
        "TokenNumber": "H132012",
        "OpenDate": "07/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "262",
        "TokenNumber": "H132013",
        "OpenDate": "07/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "263",
        "TokenNumber": "H132014",
        "OpenDate": "07/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "264",
        "TokenNumber": "H132015",
        "OpenDate": "07/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "20",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "265",
        "TokenNumber": "H132017",
        "OpenDate": "07/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "266",
        "TokenNumber": "H132018",
        "OpenDate": "07/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "267",
        "TokenNumber": "H132026",
        "OpenDate": "08/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "268",
        "TokenNumber": "H132028",
        "OpenDate": "08/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "269",
        "TokenNumber": "H132029",
        "OpenDate": "08/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "270",
        "TokenNumber": "H132031",
        "OpenDate": "08/01/2020",
        "CloseDate": "09/01/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "271",
        "TokenNumber": "H132032",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "272",
        "TokenNumber": "H132020",
        "OpenDate": "08/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "273",
        "TokenNumber": "H132034",
        "OpenDate": "08/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "6",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "274",
        "TokenNumber": "H132035",
        "OpenDate": "08/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "275",
        "TokenNumber": "H132036",
        "OpenDate": "08/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "276",
        "TokenNumber": "H132037",
        "OpenDate": "08/01/2020",
        "CloseDate": "08/01/2020",
        "CompletionTime": "0",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "277",
        "TokenNumber": "H132039",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "278",
        "TokenNumber": "H132040",
        "OpenDate": "08/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "279",
        "TokenNumber": "H132044",
        "OpenDate": "08/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "280",
        "TokenNumber": "H132045",
        "OpenDate": "08/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "14",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "281",
        "TokenNumber": "H132046",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "282",
        "TokenNumber": "H132048",
        "OpenDate": "08/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "283",
        "TokenNumber": "H132050",
        "OpenDate": "08/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "284",
        "TokenNumber": "H132051",
        "OpenDate": "08/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "285",
        "TokenNumber": "H132052",
        "OpenDate": "08/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "286",
        "TokenNumber": "H132054",
        "OpenDate": "08/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "22",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "287",
        "TokenNumber": "H132055",
        "OpenDate": "08/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "288",
        "TokenNumber": "H132060",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "289",
        "TokenNumber": "H132062",
        "OpenDate": "08/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "290",
        "TokenNumber": "H132064",
        "OpenDate": "08/01/2020",
        "CloseDate": "11/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "291",
        "TokenNumber": "H132065",
        "OpenDate": "08/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "292",
        "TokenNumber": "H132066",
        "OpenDate": "08/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "293",
        "TokenNumber": "H132067",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "294",
        "TokenNumber": "H132068",
        "OpenDate": "08/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "295",
        "TokenNumber": "H132071",
        "OpenDate": "08/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "296",
        "TokenNumber": "H132074",
        "OpenDate": "08/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "297",
        "TokenNumber": "H132076",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "298",
        "TokenNumber": "H132078",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "299",
        "TokenNumber": "H132079",
        "OpenDate": "08/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "15",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "300",
        "TokenNumber": "H132080",
        "OpenDate": "08/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "301",
        "TokenNumber": "H132081",
        "OpenDate": "08/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "302",
        "TokenNumber": "H132082",
        "OpenDate": "08/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "303",
        "TokenNumber": "H132083",
        "OpenDate": "08/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "12",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "304",
        "TokenNumber": "H132085",
        "OpenDate": "08/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "305",
        "TokenNumber": "H132089",
        "OpenDate": "08/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "306",
        "TokenNumber": "H132093",
        "OpenDate": "08/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "307",
        "TokenNumber": "H132095",
        "OpenDate": "08/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "308",
        "TokenNumber": "H132097",
        "OpenDate": "08/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "309",
        "TokenNumber": "H132098",
        "OpenDate": "09/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "310",
        "TokenNumber": "H132099",
        "OpenDate": "09/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "13",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "311",
        "TokenNumber": "H132101",
        "OpenDate": "09/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "312",
        "TokenNumber": "H132102",
        "OpenDate": "09/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "313",
        "TokenNumber": "H132104",
        "OpenDate": "09/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "21",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "314",
        "TokenNumber": "H132107",
        "OpenDate": "09/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "315",
        "TokenNumber": "H132106",
        "OpenDate": "09/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "316",
        "TokenNumber": "H132110",
        "OpenDate": "09/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "317",
        "TokenNumber": "H132111",
        "OpenDate": "09/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "318",
        "TokenNumber": "H132112",
        "OpenDate": "09/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "319",
        "TokenNumber": "H132113",
        "OpenDate": "09/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "320",
        "TokenNumber": "H132114",
        "OpenDate": "09/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "321",
        "TokenNumber": "H132116",
        "OpenDate": "09/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "322",
        "TokenNumber": "H132117",
        "OpenDate": "09/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "323",
        "TokenNumber": "H132119",
        "OpenDate": "09/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "324",
        "TokenNumber": "H132120",
        "OpenDate": "09/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "325",
        "TokenNumber": "H132122",
        "OpenDate": "09/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "27",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "326",
        "TokenNumber": "H132124",
        "OpenDate": "09/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "327",
        "TokenNumber": "H132128",
        "OpenDate": "09/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "328",
        "TokenNumber": "H132131",
        "OpenDate": "09/01/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "50",
        "Subject": "Unauthorised Mobile Tower",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "329",
        "TokenNumber": "H132132",
        "OpenDate": "09/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "330",
        "TokenNumber": "H132133",
        "OpenDate": "09/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "331",
        "TokenNumber": "H132135",
        "OpenDate": "09/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "332",
        "TokenNumber": "H132136",
        "OpenDate": "09/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "333",
        "TokenNumber": "H132137",
        "OpenDate": "09/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "334",
        "TokenNumber": "H132139",
        "OpenDate": "09/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "335",
        "TokenNumber": "H132138",
        "OpenDate": "09/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "336",
        "TokenNumber": "H132140",
        "OpenDate": "09/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "337",
        "TokenNumber": "H132141",
        "OpenDate": "09/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "338",
        "TokenNumber": "H132142",
        "OpenDate": "09/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "339",
        "TokenNumber": "H132144",
        "OpenDate": "09/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "340",
        "TokenNumber": "H132145",
        "OpenDate": "09/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "341",
        "TokenNumber": "H132146",
        "OpenDate": "09/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "342",
        "TokenNumber": "H132148",
        "OpenDate": "09/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "5",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "343",
        "TokenNumber": "H132147",
        "OpenDate": "09/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "344",
        "TokenNumber": "H132149",
        "OpenDate": "09/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "345",
        "TokenNumber": "H132150",
        "OpenDate": "09/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "346",
        "TokenNumber": "H132151",
        "OpenDate": "09/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "347",
        "TokenNumber": "H132152",
        "OpenDate": "09/01/2020",
        "CloseDate": "25/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "348",
        "TokenNumber": "H132153",
        "OpenDate": "09/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "349",
        "TokenNumber": "H132154",
        "OpenDate": "09/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "350",
        "TokenNumber": "H132155",
        "OpenDate": "09/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "351",
        "TokenNumber": "H132156",
        "OpenDate": "09/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "352",
        "TokenNumber": "H132157",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "353",
        "TokenNumber": "H132158",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "354",
        "TokenNumber": "H132160",
        "OpenDate": "10/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "61",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "355",
        "TokenNumber": "H132159",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "356",
        "TokenNumber": "H132162",
        "OpenDate": "10/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "357",
        "TokenNumber": "H132163",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "358",
        "TokenNumber": "H132165",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "359",
        "TokenNumber": "H132167",
        "OpenDate": "10/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "360",
        "TokenNumber": "H132166",
        "OpenDate": "10/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "361",
        "TokenNumber": "H132170",
        "OpenDate": "10/01/2020",
        "CloseDate": "10/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "362",
        "TokenNumber": "H132171",
        "OpenDate": "10/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "25",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "363",
        "TokenNumber": "H132172",
        "OpenDate": "10/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "364",
        "TokenNumber": "H132174",
        "OpenDate": "10/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "365",
        "TokenNumber": "H132178",
        "OpenDate": "10/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "366",
        "TokenNumber": "H132176",
        "OpenDate": "10/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "367",
        "TokenNumber": "H132177",
        "OpenDate": "10/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "368",
        "TokenNumber": "H132182",
        "OpenDate": "10/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "369",
        "TokenNumber": "H132185",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "370",
        "TokenNumber": "H132186",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "371",
        "TokenNumber": "H132187",
        "OpenDate": "10/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "372",
        "TokenNumber": "H132189",
        "OpenDate": "10/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "373",
        "TokenNumber": "H132191",
        "OpenDate": "10/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "374",
        "TokenNumber": "H132192",
        "OpenDate": "10/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "375",
        "TokenNumber": "H132190",
        "OpenDate": "10/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "376",
        "TokenNumber": "H132194",
        "OpenDate": "10/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "377",
        "TokenNumber": "H132196",
        "OpenDate": "10/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "378",
        "TokenNumber": "H132201",
        "OpenDate": "10/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "19",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "379",
        "TokenNumber": "H132202",
        "OpenDate": "10/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "380",
        "TokenNumber": "H132203",
        "OpenDate": "10/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "10",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "381",
        "TokenNumber": "H132207",
        "OpenDate": "10/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "26",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "382",
        "TokenNumber": "H132208",
        "OpenDate": "10/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "8",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "383",
        "TokenNumber": "H132209",
        "OpenDate": "10/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "4",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "384",
        "TokenNumber": "H132210",
        "OpenDate": "10/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "385",
        "TokenNumber": "H132211",
        "OpenDate": "10/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "386",
        "TokenNumber": "H132213",
        "OpenDate": "10/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "387",
        "TokenNumber": "H132214",
        "OpenDate": "10/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "388",
        "TokenNumber": "H132215",
        "OpenDate": "10/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "389",
        "TokenNumber": "H132217",
        "OpenDate": "10/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "390",
        "TokenNumber": "H132218",
        "OpenDate": "10/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "391",
        "TokenNumber": "H132219",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "392",
        "TokenNumber": "H132221",
        "OpenDate": "11/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "393",
        "TokenNumber": "H132222",
        "OpenDate": "11/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "394",
        "TokenNumber": "H132224",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "395",
        "TokenNumber": "H132225",
        "OpenDate": "11/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "396",
        "TokenNumber": "H132226",
        "OpenDate": "11/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "397",
        "TokenNumber": "H132227",
        "OpenDate": "11/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "398",
        "TokenNumber": "H132230",
        "OpenDate": "11/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "399",
        "TokenNumber": "H132231",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "400",
        "TokenNumber": "H132232",
        "OpenDate": "11/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "401",
        "TokenNumber": "H132234",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "402",
        "TokenNumber": "H132235",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "403",
        "TokenNumber": "H132236",
        "OpenDate": "11/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "404",
        "TokenNumber": "H132237",
        "OpenDate": "11/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "405",
        "TokenNumber": "H132241",
        "OpenDate": "11/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "406",
        "TokenNumber": "H132239",
        "OpenDate": "11/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "407",
        "TokenNumber": "H132245",
        "OpenDate": "11/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "408",
        "TokenNumber": "H132248",
        "OpenDate": "11/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "16",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "409",
        "TokenNumber": "H132249",
        "OpenDate": "11/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "410",
        "TokenNumber": "H132250",
        "OpenDate": "11/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "411",
        "TokenNumber": "H132251",
        "OpenDate": "11/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "412",
        "TokenNumber": "H132255",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "413",
        "TokenNumber": "H132254",
        "OpenDate": "11/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "414",
        "TokenNumber": "H132256",
        "OpenDate": "11/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "415",
        "TokenNumber": "H132257",
        "OpenDate": "11/01/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "88",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "416",
        "TokenNumber": "H132258",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "417",
        "TokenNumber": "H132259",
        "OpenDate": "11/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "418",
        "TokenNumber": "H132260",
        "OpenDate": "11/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "419",
        "TokenNumber": "H132261",
        "OpenDate": "11/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "420",
        "TokenNumber": "H132264",
        "OpenDate": "11/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "421",
        "TokenNumber": "H132267",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "422",
        "TokenNumber": "H132268",
        "OpenDate": "11/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "46",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "423",
        "TokenNumber": "H132270",
        "OpenDate": "11/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "424",
        "TokenNumber": "H132272",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "425",
        "TokenNumber": "H132274",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "426",
        "TokenNumber": "H132275",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "427",
        "TokenNumber": "H132276",
        "OpenDate": "11/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "428",
        "TokenNumber": "H132277",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "429",
        "TokenNumber": "H132278",
        "OpenDate": "11/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "430",
        "TokenNumber": "H132279",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "431",
        "TokenNumber": "H132282",
        "OpenDate": "11/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "432",
        "TokenNumber": "H132283",
        "OpenDate": "11/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "433",
        "TokenNumber": "H132284",
        "OpenDate": "11/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "434",
        "TokenNumber": "H132285",
        "OpenDate": "11/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "435",
        "TokenNumber": "H132287",
        "OpenDate": "11/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "436",
        "TokenNumber": "H132290",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "437",
        "TokenNumber": "H132291",
        "OpenDate": "12/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "30",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "438",
        "TokenNumber": "H132292",
        "OpenDate": "12/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "439",
        "TokenNumber": "H132293",
        "OpenDate": "12/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "440",
        "TokenNumber": "H132294",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "441",
        "TokenNumber": "H132296",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "442",
        "TokenNumber": "H132299",
        "OpenDate": "12/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "443",
        "TokenNumber": "H132297",
        "OpenDate": "12/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "444",
        "TokenNumber": "H132298",
        "OpenDate": "12/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "445",
        "TokenNumber": "H132300",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "446",
        "TokenNumber": "H132301",
        "OpenDate": "12/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "447",
        "TokenNumber": "H132303",
        "OpenDate": "12/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "24",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "448",
        "TokenNumber": "H132304",
        "OpenDate": "12/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "24",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "449",
        "TokenNumber": "H132306",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "450",
        "TokenNumber": "H132307",
        "OpenDate": "12/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "451",
        "TokenNumber": "H132308",
        "OpenDate": "12/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "452",
        "TokenNumber": "H132309",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "453",
        "TokenNumber": "H132310",
        "OpenDate": "12/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "454",
        "TokenNumber": "H132312",
        "OpenDate": "12/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "455",
        "TokenNumber": "H132313",
        "OpenDate": "12/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "456",
        "TokenNumber": "H132314",
        "OpenDate": "12/01/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "87",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "457",
        "TokenNumber": "H132317",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "458",
        "TokenNumber": "H132318",
        "OpenDate": "12/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "459",
        "TokenNumber": "H132321",
        "OpenDate": "12/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "460",
        "TokenNumber": "H132322",
        "OpenDate": "12/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "461",
        "TokenNumber": "H132324",
        "OpenDate": "12/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "29",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "462",
        "TokenNumber": "H132325",
        "OpenDate": "13/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "463",
        "TokenNumber": "H132327",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "464",
        "TokenNumber": "H132329",
        "OpenDate": "13/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "465",
        "TokenNumber": "H132331",
        "OpenDate": "13/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "466",
        "TokenNumber": "H132332",
        "OpenDate": "13/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "467",
        "TokenNumber": "H132333",
        "OpenDate": "13/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "468",
        "TokenNumber": "H132336",
        "OpenDate": "13/01/2020",
        "CloseDate": "13/01/2020",
        "CompletionTime": "0",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "469",
        "TokenNumber": "H132337",
        "OpenDate": "13/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "470",
        "TokenNumber": "H132339",
        "OpenDate": "13/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "471",
        "TokenNumber": "H132342",
        "OpenDate": "13/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "11",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "472",
        "TokenNumber": "H132343",
        "OpenDate": "13/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "473",
        "TokenNumber": "H132344",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "474",
        "TokenNumber": "H132345",
        "OpenDate": "13/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "5",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "475",
        "TokenNumber": "H132346",
        "OpenDate": "13/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "476",
        "TokenNumber": "H132347",
        "OpenDate": "13/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "477",
        "TokenNumber": "H132349",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "478",
        "TokenNumber": "H132350",
        "OpenDate": "13/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "479",
        "TokenNumber": "H132351",
        "OpenDate": "13/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "480",
        "TokenNumber": "H132352",
        "OpenDate": "13/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "481",
        "TokenNumber": "H132353",
        "OpenDate": "13/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "23",
        "Subject": "No water supply in public toilet",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "482",
        "TokenNumber": "H132354",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "483",
        "TokenNumber": "H132355",
        "OpenDate": "13/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "484",
        "TokenNumber": "H132356",
        "OpenDate": "13/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "485",
        "TokenNumber": "H132357",
        "OpenDate": "13/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "486",
        "TokenNumber": "H132359",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "487",
        "TokenNumber": "H132360",
        "OpenDate": "13/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "9",
        "Subject": "No water supply in public toilet",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "488",
        "TokenNumber": "H132361",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "489",
        "TokenNumber": "H132363",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "490",
        "TokenNumber": "H132365",
        "OpenDate": "13/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "491",
        "TokenNumber": "H132366",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "492",
        "TokenNumber": "H132368",
        "OpenDate": "13/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "493",
        "TokenNumber": "H132367",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "494",
        "TokenNumber": "H132369",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "495",
        "TokenNumber": "H132372",
        "OpenDate": "13/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "496",
        "TokenNumber": "H132374",
        "OpenDate": "13/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "497",
        "TokenNumber": "H132376",
        "OpenDate": "13/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "11",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "498",
        "TokenNumber": "H132378",
        "OpenDate": "13/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "499",
        "TokenNumber": "H132379",
        "OpenDate": "13/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "501",
        "TokenNumber": "H132381",
        "OpenDate": "13/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "502",
        "TokenNumber": "H132382",
        "OpenDate": "13/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "14",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "503",
        "TokenNumber": "H132383",
        "OpenDate": "13/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "504",
        "TokenNumber": "H132386",
        "OpenDate": "13/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "505",
        "TokenNumber": "H132387",
        "OpenDate": "13/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "506",
        "TokenNumber": "H132388",
        "OpenDate": "13/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "507",
        "TokenNumber": "H132389",
        "OpenDate": "13/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "22",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "508",
        "TokenNumber": "H132390",
        "OpenDate": "13/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "509",
        "TokenNumber": "H132392",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "510",
        "TokenNumber": "H132391",
        "OpenDate": "13/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "511",
        "TokenNumber": "H132395",
        "OpenDate": "13/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "512",
        "TokenNumber": "H132396",
        "OpenDate": "14/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "513",
        "TokenNumber": "H132397",
        "OpenDate": "14/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "514",
        "TokenNumber": "H132398",
        "OpenDate": "14/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "22",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "515",
        "TokenNumber": "H132400",
        "OpenDate": "14/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "516",
        "TokenNumber": "H132401",
        "OpenDate": "14/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "517",
        "TokenNumber": "H132402",
        "OpenDate": "14/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "6",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "518",
        "TokenNumber": "H132403",
        "OpenDate": "14/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "519",
        "TokenNumber": "H132404",
        "OpenDate": "14/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "520",
        "TokenNumber": "H132405",
        "OpenDate": "14/01/2020",
        "CloseDate": "14/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "521",
        "TokenNumber": "H132406",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "522",
        "TokenNumber": "H132408",
        "OpenDate": "14/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "16",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "523",
        "TokenNumber": "H132411",
        "OpenDate": "14/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "524",
        "TokenNumber": "H132412",
        "OpenDate": "14/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "525",
        "TokenNumber": "H132413",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "526",
        "TokenNumber": "H132416",
        "OpenDate": "14/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "13",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "527",
        "TokenNumber": "H132415",
        "OpenDate": "14/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "528",
        "TokenNumber": "H132417",
        "OpenDate": "14/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "529",
        "TokenNumber": "H132418",
        "OpenDate": "14/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "530",
        "TokenNumber": "H132420",
        "OpenDate": "14/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "531",
        "TokenNumber": "H132422",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "532",
        "TokenNumber": "H132423",
        "OpenDate": "14/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "533",
        "TokenNumber": "H132424",
        "OpenDate": "14/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "534",
        "TokenNumber": "H132425",
        "OpenDate": "14/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "535",
        "TokenNumber": "H132426",
        "OpenDate": "14/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "536",
        "TokenNumber": "H132427",
        "OpenDate": "14/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "537",
        "TokenNumber": "H132428",
        "OpenDate": "14/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "538",
        "TokenNumber": "H132429",
        "OpenDate": "14/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "539",
        "TokenNumber": "H132430",
        "OpenDate": "14/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "540",
        "TokenNumber": "H132431",
        "OpenDate": "14/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "541",
        "TokenNumber": "H132434",
        "OpenDate": "14/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "542",
        "TokenNumber": "H132433",
        "OpenDate": "14/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "57",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "543",
        "TokenNumber": "H132436",
        "OpenDate": "14/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "544",
        "TokenNumber": "H132438",
        "OpenDate": "14/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "545",
        "TokenNumber": "H132440",
        "OpenDate": "14/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "546",
        "TokenNumber": "H132442",
        "OpenDate": "14/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "547",
        "TokenNumber": "H132443",
        "OpenDate": "14/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "548",
        "TokenNumber": "H132445",
        "OpenDate": "14/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "549",
        "TokenNumber": "H132446",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "550",
        "TokenNumber": "H132447",
        "OpenDate": "14/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "551",
        "TokenNumber": "H132448",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "552",
        "TokenNumber": "H132441",
        "OpenDate": "14/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "553",
        "TokenNumber": "H132450",
        "OpenDate": "14/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "554",
        "TokenNumber": "H132451",
        "OpenDate": "14/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "20",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "555",
        "TokenNumber": "H132452",
        "OpenDate": "14/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "556",
        "TokenNumber": "H132454",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "557",
        "TokenNumber": "H132456",
        "OpenDate": "14/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "558",
        "TokenNumber": "H132457",
        "OpenDate": "14/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "559",
        "TokenNumber": "H132459",
        "OpenDate": "14/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "560",
        "TokenNumber": "H132461",
        "OpenDate": "14/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "561",
        "TokenNumber": "H132462",
        "OpenDate": "14/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "562",
        "TokenNumber": "H132463",
        "OpenDate": "14/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "563",
        "TokenNumber": "H132465",
        "OpenDate": "14/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "564",
        "TokenNumber": "H132466",
        "OpenDate": "14/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "565",
        "TokenNumber": "H132467",
        "OpenDate": "15/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "22",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "566",
        "TokenNumber": "H132468",
        "OpenDate": "15/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "567",
        "TokenNumber": "H132470",
        "OpenDate": "15/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "568",
        "TokenNumber": "H132469",
        "OpenDate": "15/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "569",
        "TokenNumber": "H132472",
        "OpenDate": "15/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "570",
        "TokenNumber": "H132474",
        "OpenDate": "15/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "571",
        "TokenNumber": "H132475",
        "OpenDate": "15/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "572",
        "TokenNumber": "H132476",
        "OpenDate": "15/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "573",
        "TokenNumber": "H132478",
        "OpenDate": "15/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "574",
        "TokenNumber": "H132479",
        "OpenDate": "15/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "575",
        "TokenNumber": "H132482",
        "OpenDate": "15/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "576",
        "TokenNumber": "H132484",
        "OpenDate": "15/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "56",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "577",
        "TokenNumber": "H132483",
        "OpenDate": "15/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "578",
        "TokenNumber": "H132485",
        "OpenDate": "15/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "579",
        "TokenNumber": "H132486",
        "OpenDate": "15/01/2020",
        "CloseDate": "15/01/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "580",
        "TokenNumber": "H132488",
        "OpenDate": "15/01/2020",
        "CloseDate": "16/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "581",
        "TokenNumber": "H132490",
        "OpenDate": "15/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "582",
        "TokenNumber": "H132492",
        "OpenDate": "15/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "583",
        "TokenNumber": "H132491",
        "OpenDate": "15/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "584",
        "TokenNumber": "H132495",
        "OpenDate": "15/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "26",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "585",
        "TokenNumber": "H132496",
        "OpenDate": "15/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "586",
        "TokenNumber": "H132498",
        "OpenDate": "15/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "587",
        "TokenNumber": "H132500",
        "OpenDate": "15/01/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "48",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "588",
        "TokenNumber": "H132501",
        "OpenDate": "15/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "589",
        "TokenNumber": "H132502",
        "OpenDate": "15/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "590",
        "TokenNumber": "H132504",
        "OpenDate": "15/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "591",
        "TokenNumber": "H132505",
        "OpenDate": "15/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "592",
        "TokenNumber": "H132506",
        "OpenDate": "15/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "593",
        "TokenNumber": "H132509",
        "OpenDate": "15/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "594",
        "TokenNumber": "H132510",
        "OpenDate": "15/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "595",
        "TokenNumber": "H132511",
        "OpenDate": "15/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "596",
        "TokenNumber": "H132514",
        "OpenDate": "15/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "597",
        "TokenNumber": "H132516",
        "OpenDate": "15/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "598",
        "TokenNumber": "H132518",
        "OpenDate": "15/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "599",
        "TokenNumber": "H132520",
        "OpenDate": "16/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "600",
        "TokenNumber": "H132521",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "601",
        "TokenNumber": "H132522",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "602",
        "TokenNumber": "H132523",
        "OpenDate": "16/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "603",
        "TokenNumber": "H132528",
        "OpenDate": "16/01/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "604",
        "TokenNumber": "H132530",
        "OpenDate": "16/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "605",
        "TokenNumber": "H132533",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "606",
        "TokenNumber": "H132536",
        "OpenDate": "16/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "607",
        "TokenNumber": "H132537",
        "OpenDate": "16/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "608",
        "TokenNumber": "H132538",
        "OpenDate": "16/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "26",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "609",
        "TokenNumber": "H132539",
        "OpenDate": "16/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "610",
        "TokenNumber": "H132543",
        "OpenDate": "16/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "611",
        "TokenNumber": "H132545",
        "OpenDate": "16/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "612",
        "TokenNumber": "H132546",
        "OpenDate": "16/01/2020",
        "CloseDate": "17/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "613",
        "TokenNumber": "H132547",
        "OpenDate": "16/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "614",
        "TokenNumber": "H132548",
        "OpenDate": "16/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "615",
        "TokenNumber": "H132549",
        "OpenDate": "16/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "616",
        "TokenNumber": "H132551",
        "OpenDate": "16/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "617",
        "TokenNumber": "H132552",
        "OpenDate": "16/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "618",
        "TokenNumber": "H132555",
        "OpenDate": "16/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "619",
        "TokenNumber": "H132557",
        "OpenDate": "16/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "620",
        "TokenNumber": "H132558",
        "OpenDate": "16/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "621",
        "TokenNumber": "H132560",
        "OpenDate": "16/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "622",
        "TokenNumber": "H132561",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "623",
        "TokenNumber": "H132563",
        "OpenDate": "16/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "624",
        "TokenNumber": "H132565",
        "OpenDate": "16/01/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "90",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "625",
        "TokenNumber": "H132562",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "626",
        "TokenNumber": "H132566",
        "OpenDate": "16/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "627",
        "TokenNumber": "H132567",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "628",
        "TokenNumber": "H132568",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "629",
        "TokenNumber": "H132569",
        "OpenDate": "16/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "630",
        "TokenNumber": "H132573",
        "OpenDate": "16/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "631",
        "TokenNumber": "H132577",
        "OpenDate": "16/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "632",
        "TokenNumber": "H132578",
        "OpenDate": "16/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "633",
        "TokenNumber": "H132579",
        "OpenDate": "16/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "634",
        "TokenNumber": "H132580",
        "OpenDate": "16/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "635",
        "TokenNumber": "H132581",
        "OpenDate": "17/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "636",
        "TokenNumber": "H132584",
        "OpenDate": "17/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "52",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "637",
        "TokenNumber": "H132586",
        "OpenDate": "17/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "54",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "638",
        "TokenNumber": "H132587",
        "OpenDate": "17/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "639",
        "TokenNumber": "H132588",
        "OpenDate": "17/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "640",
        "TokenNumber": "H132589",
        "OpenDate": "17/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "641",
        "TokenNumber": "H132590",
        "OpenDate": "17/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "642",
        "TokenNumber": "H132591",
        "OpenDate": "17/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "643",
        "TokenNumber": "H132592",
        "OpenDate": "17/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "644",
        "TokenNumber": "H132594",
        "OpenDate": "17/01/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "42",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "645",
        "TokenNumber": "H132595",
        "OpenDate": "17/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "646",
        "TokenNumber": "H132597",
        "OpenDate": "17/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "647",
        "TokenNumber": "H132600",
        "OpenDate": "17/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "648",
        "TokenNumber": "H132602",
        "OpenDate": "17/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "649",
        "TokenNumber": "H132604",
        "OpenDate": "17/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "650",
        "TokenNumber": "H132605",
        "OpenDate": "17/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "651",
        "TokenNumber": "H132606",
        "OpenDate": "17/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "652",
        "TokenNumber": "H132609",
        "OpenDate": "17/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "653",
        "TokenNumber": "H132610",
        "OpenDate": "17/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "654",
        "TokenNumber": "H132611",
        "OpenDate": "17/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "655",
        "TokenNumber": "H132612",
        "OpenDate": "17/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "657",
        "TokenNumber": "H132616",
        "OpenDate": "17/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "658",
        "TokenNumber": "H132617",
        "OpenDate": "17/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "659",
        "TokenNumber": "H132621",
        "OpenDate": "17/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "21",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "660",
        "TokenNumber": "H132622",
        "OpenDate": "17/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "661",
        "TokenNumber": "H132623",
        "OpenDate": "17/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "662",
        "TokenNumber": "H132624",
        "OpenDate": "17/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "663",
        "TokenNumber": "H132625",
        "OpenDate": "17/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "664",
        "TokenNumber": "H132626",
        "OpenDate": "17/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "665",
        "TokenNumber": "H132627",
        "OpenDate": "17/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "666",
        "TokenNumber": "H132629",
        "OpenDate": "17/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "667",
        "TokenNumber": "H132630",
        "OpenDate": "17/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "668",
        "TokenNumber": "H132631",
        "OpenDate": "17/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "669",
        "TokenNumber": "H132632",
        "OpenDate": "17/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "670",
        "TokenNumber": "H132633",
        "OpenDate": "17/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "671",
        "TokenNumber": "H132628",
        "OpenDate": "17/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "672",
        "TokenNumber": "H132634",
        "OpenDate": "17/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "673",
        "TokenNumber": "H132635",
        "OpenDate": "17/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "674",
        "TokenNumber": "H132636",
        "OpenDate": "17/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "20",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "675",
        "TokenNumber": "H132637",
        "OpenDate": "17/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "676",
        "TokenNumber": "H132639",
        "OpenDate": "17/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "677",
        "TokenNumber": "H132641",
        "OpenDate": "18/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "678",
        "TokenNumber": "H132642",
        "OpenDate": "18/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "679",
        "TokenNumber": "H132643",
        "OpenDate": "18/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "680",
        "TokenNumber": "H132644",
        "OpenDate": "18/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "681",
        "TokenNumber": "H132645",
        "OpenDate": "18/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "682",
        "TokenNumber": "H132647",
        "OpenDate": "18/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "683",
        "TokenNumber": "H132648",
        "OpenDate": "18/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "17",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "684",
        "TokenNumber": "H132649",
        "OpenDate": "18/01/2020",
        "CloseDate": "18/01/2020",
        "CompletionTime": "0",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "685",
        "TokenNumber": "H132650",
        "OpenDate": "18/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "686",
        "TokenNumber": "H132651",
        "OpenDate": "18/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "687",
        "TokenNumber": "H132652",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "688",
        "TokenNumber": "H132654",
        "OpenDate": "18/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "689",
        "TokenNumber": "H132658",
        "OpenDate": "18/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "690",
        "TokenNumber": "H132657",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "691",
        "TokenNumber": "H132663",
        "OpenDate": "18/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "692",
        "TokenNumber": "H132664",
        "OpenDate": "18/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "693",
        "TokenNumber": "H132666",
        "OpenDate": "18/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "694",
        "TokenNumber": "H132670",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "695",
        "TokenNumber": "H132671",
        "OpenDate": "18/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "23",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "696",
        "TokenNumber": "H132672",
        "OpenDate": "18/01/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "80",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "697",
        "TokenNumber": "H132682",
        "OpenDate": "18/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "698",
        "TokenNumber": "H132126",
        "OpenDate": "18/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "699",
        "TokenNumber": "H132683",
        "OpenDate": "18/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "700",
        "TokenNumber": "H132685",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "701",
        "TokenNumber": "H132686",
        "OpenDate": "18/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "702",
        "TokenNumber": "H132688",
        "OpenDate": "18/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "703",
        "TokenNumber": "H132689",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "704",
        "TokenNumber": "H132691",
        "OpenDate": "18/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "705",
        "TokenNumber": "H132692",
        "OpenDate": "18/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "706",
        "TokenNumber": "H132694",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "707",
        "TokenNumber": "H132695",
        "OpenDate": "18/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "708",
        "TokenNumber": "H132696",
        "OpenDate": "18/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "709",
        "TokenNumber": "H132697",
        "OpenDate": "18/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "710",
        "TokenNumber": "H132698",
        "OpenDate": "18/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "711",
        "TokenNumber": "H132699",
        "OpenDate": "18/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "712",
        "TokenNumber": "H132701",
        "OpenDate": "18/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "713",
        "TokenNumber": "H132702",
        "OpenDate": "18/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "714",
        "TokenNumber": "H132703",
        "OpenDate": "19/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "715",
        "TokenNumber": "H132704",
        "OpenDate": "19/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "17",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "716",
        "TokenNumber": "H132705",
        "OpenDate": "19/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "717",
        "TokenNumber": "H132708",
        "OpenDate": "19/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "718",
        "TokenNumber": "H132709",
        "OpenDate": "19/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "719",
        "TokenNumber": "H132711",
        "OpenDate": "19/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "8",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "720",
        "TokenNumber": "H132712",
        "OpenDate": "19/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "721",
        "TokenNumber": "H132713",
        "OpenDate": "19/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "722",
        "TokenNumber": "H132717",
        "OpenDate": "19/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "723",
        "TokenNumber": "H132719",
        "OpenDate": "19/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "724",
        "TokenNumber": "H132720",
        "OpenDate": "19/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "725",
        "TokenNumber": "H132722",
        "OpenDate": "19/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "726",
        "TokenNumber": "H132723",
        "OpenDate": "19/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "727",
        "TokenNumber": "H132724",
        "OpenDate": "19/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "728",
        "TokenNumber": "H132725",
        "OpenDate": "19/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "729",
        "TokenNumber": "H132716",
        "OpenDate": "19/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "730",
        "TokenNumber": "H132727",
        "OpenDate": "19/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "22",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "731",
        "TokenNumber": "H132728",
        "OpenDate": "19/01/2020",
        "CloseDate": "20/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "732",
        "TokenNumber": "H132730",
        "OpenDate": "19/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "733",
        "TokenNumber": "H132731",
        "OpenDate": "19/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "734",
        "TokenNumber": "H132732",
        "OpenDate": "19/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "16",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "735",
        "TokenNumber": "H132733",
        "OpenDate": "19/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "736",
        "TokenNumber": "H132734",
        "OpenDate": "19/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "737",
        "TokenNumber": "H132735",
        "OpenDate": "19/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "738",
        "TokenNumber": "H132736",
        "OpenDate": "19/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "739",
        "TokenNumber": "H132737",
        "OpenDate": "19/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "740",
        "TokenNumber": "H132738",
        "OpenDate": "19/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "50",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "741",
        "TokenNumber": "H132740",
        "OpenDate": "20/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "51",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "742",
        "TokenNumber": "H132741",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "743",
        "TokenNumber": "H132742",
        "OpenDate": "20/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "744",
        "TokenNumber": "H132744",
        "OpenDate": "20/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "745",
        "TokenNumber": "H132750",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "746",
        "TokenNumber": "H132751",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "747",
        "TokenNumber": "H132754",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "748",
        "TokenNumber": "H132755",
        "OpenDate": "20/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "749",
        "TokenNumber": "H132756",
        "OpenDate": "20/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "750",
        "TokenNumber": "H132757",
        "OpenDate": "20/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "751",
        "TokenNumber": "H132758",
        "OpenDate": "20/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "752",
        "TokenNumber": "H132759",
        "OpenDate": "20/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "753",
        "TokenNumber": "H132760",
        "OpenDate": "20/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "3",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "754",
        "TokenNumber": "H132762",
        "OpenDate": "20/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "755",
        "TokenNumber": "H132763",
        "OpenDate": "20/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "756",
        "TokenNumber": "H132766",
        "OpenDate": "20/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "757",
        "TokenNumber": "H132767",
        "OpenDate": "20/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "16",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "758",
        "TokenNumber": "H132768",
        "OpenDate": "20/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "759",
        "TokenNumber": "H132770",
        "OpenDate": "20/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "760",
        "TokenNumber": "H132772",
        "OpenDate": "20/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "761",
        "TokenNumber": "H132775",
        "OpenDate": "20/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "762",
        "TokenNumber": "H132777",
        "OpenDate": "20/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "763",
        "TokenNumber": "H132779",
        "OpenDate": "20/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "764",
        "TokenNumber": "H132780",
        "OpenDate": "20/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "765",
        "TokenNumber": "H132776",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "766",
        "TokenNumber": "H132782",
        "OpenDate": "20/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "767",
        "TokenNumber": "H132787",
        "OpenDate": "20/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "768",
        "TokenNumber": "H132789",
        "OpenDate": "20/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "769",
        "TokenNumber": "H132790",
        "OpenDate": "20/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "21",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "770",
        "TokenNumber": "H132792",
        "OpenDate": "20/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "771",
        "TokenNumber": "H132793",
        "OpenDate": "20/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "772",
        "TokenNumber": "H132794",
        "OpenDate": "20/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "773",
        "TokenNumber": "H132795",
        "OpenDate": "20/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "774",
        "TokenNumber": "H132797",
        "OpenDate": "20/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "775",
        "TokenNumber": "H132798",
        "OpenDate": "20/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "776",
        "TokenNumber": "H132799",
        "OpenDate": "20/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "777",
        "TokenNumber": "H132800",
        "OpenDate": "20/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "16",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "778",
        "TokenNumber": "H132801",
        "OpenDate": "20/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "779",
        "TokenNumber": "H132803",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "780",
        "TokenNumber": "H132805",
        "OpenDate": "20/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "781",
        "TokenNumber": "H132804",
        "OpenDate": "20/01/2020",
        "CloseDate": "21/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "782",
        "TokenNumber": "H132806",
        "OpenDate": "20/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "783",
        "TokenNumber": "H132807",
        "OpenDate": "20/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "784",
        "TokenNumber": "H132808",
        "OpenDate": "20/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "785",
        "TokenNumber": "H132809",
        "OpenDate": "20/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "786",
        "TokenNumber": "H132813",
        "OpenDate": "21/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "787",
        "TokenNumber": "H132812",
        "OpenDate": "21/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "788",
        "TokenNumber": "H132814",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "789",
        "TokenNumber": "H132816",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "790",
        "TokenNumber": "H132821",
        "OpenDate": "21/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "14",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "791",
        "TokenNumber": "H132820",
        "OpenDate": "21/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "792",
        "TokenNumber": "H132822",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "793",
        "TokenNumber": "H132823",
        "OpenDate": "21/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "794",
        "TokenNumber": "H132825",
        "OpenDate": "21/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "795",
        "TokenNumber": "H132829",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "796",
        "TokenNumber": "H132830",
        "OpenDate": "21/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "797",
        "TokenNumber": "H132831",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "798",
        "TokenNumber": "H132834",
        "OpenDate": "21/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "799",
        "TokenNumber": "H132835",
        "OpenDate": "21/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "800",
        "TokenNumber": "H132836",
        "OpenDate": "21/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "801",
        "TokenNumber": "H132838",
        "OpenDate": "21/01/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "77",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "802",
        "TokenNumber": "H132841",
        "OpenDate": "21/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "803",
        "TokenNumber": "H132843",
        "OpenDate": "21/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "804",
        "TokenNumber": "H132846",
        "OpenDate": "21/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "805",
        "TokenNumber": "H132849",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "806",
        "TokenNumber": "H132851",
        "OpenDate": "21/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "807",
        "TokenNumber": "H132852",
        "OpenDate": "21/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "16",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "808",
        "TokenNumber": "H132853",
        "OpenDate": "21/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "809",
        "TokenNumber": "H132854",
        "OpenDate": "21/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "810",
        "TokenNumber": "H132855",
        "OpenDate": "21/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "811",
        "TokenNumber": "H132857",
        "OpenDate": "21/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "14",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "812",
        "TokenNumber": "H132858",
        "OpenDate": "21/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "813",
        "TokenNumber": "H132859",
        "OpenDate": "21/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "814",
        "TokenNumber": "H132862",
        "OpenDate": "21/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "10",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "815",
        "TokenNumber": "H132864",
        "OpenDate": "21/01/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "57",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "816",
        "TokenNumber": "H132866",
        "OpenDate": "21/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "817",
        "TokenNumber": "H132868",
        "OpenDate": "21/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "818",
        "TokenNumber": "H132870",
        "OpenDate": "21/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "819",
        "TokenNumber": "H132877",
        "OpenDate": "22/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "820",
        "TokenNumber": "H132878",
        "OpenDate": "22/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "821",
        "TokenNumber": "H132879",
        "OpenDate": "22/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "822",
        "TokenNumber": "H132881",
        "OpenDate": "22/01/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "55",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "823",
        "TokenNumber": "H132880",
        "OpenDate": "22/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "824",
        "TokenNumber": "H132882",
        "OpenDate": "22/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "825",
        "TokenNumber": "H132884",
        "OpenDate": "22/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "826",
        "TokenNumber": "H132886",
        "OpenDate": "22/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "827",
        "TokenNumber": "H132890",
        "OpenDate": "22/01/2020",
        "CloseDate": "22/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "828",
        "TokenNumber": "H132887",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "829",
        "TokenNumber": "H132888",
        "OpenDate": "22/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "830",
        "TokenNumber": "H132891",
        "OpenDate": "22/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "831",
        "TokenNumber": "H132892",
        "OpenDate": "22/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "832",
        "TokenNumber": "H132894",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "833",
        "TokenNumber": "H132895",
        "OpenDate": "22/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "834",
        "TokenNumber": "H132897",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "835",
        "TokenNumber": "H132896",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "836",
        "TokenNumber": "H132899",
        "OpenDate": "22/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "837",
        "TokenNumber": "H132902",
        "OpenDate": "22/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "838",
        "TokenNumber": "H132903",
        "OpenDate": "22/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "839",
        "TokenNumber": "H132905",
        "OpenDate": "22/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "19",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "841",
        "TokenNumber": "H132909",
        "OpenDate": "22/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "843",
        "TokenNumber": "H132912",
        "OpenDate": "22/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "844",
        "TokenNumber": "H132913",
        "OpenDate": "22/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "845",
        "TokenNumber": "H132916",
        "OpenDate": "22/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "846",
        "TokenNumber": "H132918",
        "OpenDate": "22/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "49",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "847",
        "TokenNumber": "H132917",
        "OpenDate": "22/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "848",
        "TokenNumber": "H132920",
        "OpenDate": "22/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "849",
        "TokenNumber": "H132921",
        "OpenDate": "22/01/2020",
        "CloseDate": "25/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "850",
        "TokenNumber": "H132923",
        "OpenDate": "22/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "851",
        "TokenNumber": "H132924",
        "OpenDate": "22/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "852",
        "TokenNumber": "H132926",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "853",
        "TokenNumber": "H132929",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "854",
        "TokenNumber": "H132931",
        "OpenDate": "22/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "855",
        "TokenNumber": "H132932",
        "OpenDate": "22/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "10",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "856",
        "TokenNumber": "H132933",
        "OpenDate": "22/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "857",
        "TokenNumber": "H132937",
        "OpenDate": "22/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "858",
        "TokenNumber": "H132938",
        "OpenDate": "22/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "859",
        "TokenNumber": "H132940",
        "OpenDate": "22/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "19",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "860",
        "TokenNumber": "H132942",
        "OpenDate": "22/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "861",
        "TokenNumber": "H132944",
        "OpenDate": "23/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "862",
        "TokenNumber": "H132945",
        "OpenDate": "23/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "863",
        "TokenNumber": "H132947",
        "OpenDate": "23/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "864",
        "TokenNumber": "H132949",
        "OpenDate": "23/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "865",
        "TokenNumber": "H132950",
        "OpenDate": "23/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "866",
        "TokenNumber": "H132952",
        "OpenDate": "23/01/2020",
        "CloseDate": "23/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "867",
        "TokenNumber": "H132953",
        "OpenDate": "23/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "868",
        "TokenNumber": "H132955",
        "OpenDate": "23/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "869",
        "TokenNumber": "H132956",
        "OpenDate": "23/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "870",
        "TokenNumber": "H132957",
        "OpenDate": "23/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "871",
        "TokenNumber": "H132958",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "872",
        "TokenNumber": "H132960",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "873",
        "TokenNumber": "H132961",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "874",
        "TokenNumber": "H132962",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "875",
        "TokenNumber": "H132963",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "876",
        "TokenNumber": "H132966",
        "OpenDate": "23/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "877",
        "TokenNumber": "H132967",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "878",
        "TokenNumber": "H132968",
        "OpenDate": "23/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "879",
        "TokenNumber": "H132971",
        "OpenDate": "23/01/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "83",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "880",
        "TokenNumber": "H132973",
        "OpenDate": "23/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "881",
        "TokenNumber": "H132975",
        "OpenDate": "23/01/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "83",
        "Subject": "Cleaning of Public Toilets",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "882",
        "TokenNumber": "H132977",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "883",
        "TokenNumber": "H132976",
        "OpenDate": "23/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "884",
        "TokenNumber": "H132978",
        "OpenDate": "23/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "885",
        "TokenNumber": "H132974",
        "OpenDate": "23/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "886",
        "TokenNumber": "H132980",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "887",
        "TokenNumber": "H132982",
        "OpenDate": "23/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "888",
        "TokenNumber": "H132984",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "889",
        "TokenNumber": "H132665",
        "OpenDate": "23/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "890",
        "TokenNumber": "H132988",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "891",
        "TokenNumber": "H132989",
        "OpenDate": "23/01/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "76",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "892",
        "TokenNumber": "H132993",
        "OpenDate": "23/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "18",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "893",
        "TokenNumber": "H132992",
        "OpenDate": "23/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "894",
        "TokenNumber": "H132997",
        "OpenDate": "23/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "895",
        "TokenNumber": "H133000",
        "OpenDate": "23/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "896",
        "TokenNumber": "H133001",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "897",
        "TokenNumber": "H133004",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "898",
        "TokenNumber": "H133005",
        "OpenDate": "23/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "899",
        "TokenNumber": "H133006",
        "OpenDate": "23/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "900",
        "TokenNumber": "H133007",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "901",
        "TokenNumber": "H133008",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "902",
        "TokenNumber": "H133009",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "903",
        "TokenNumber": "H133010",
        "OpenDate": "23/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "904",
        "TokenNumber": "H133011",
        "OpenDate": "23/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "20",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "905",
        "TokenNumber": "H133012",
        "OpenDate": "23/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "906",
        "TokenNumber": "H133013",
        "OpenDate": "24/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "907",
        "TokenNumber": "H133016",
        "OpenDate": "24/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "10",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "908",
        "TokenNumber": "H133015",
        "OpenDate": "24/01/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "21",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "909",
        "TokenNumber": "H133017",
        "OpenDate": "24/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "910",
        "TokenNumber": "H133002",
        "OpenDate": "24/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "911",
        "TokenNumber": "H133019",
        "OpenDate": "24/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "912",
        "TokenNumber": "H133018",
        "OpenDate": "24/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "913",
        "TokenNumber": "H133020",
        "OpenDate": "24/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "914",
        "TokenNumber": "H133022",
        "OpenDate": "24/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "915",
        "TokenNumber": "H133024",
        "OpenDate": "24/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "916",
        "TokenNumber": "H133026",
        "OpenDate": "24/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "917",
        "TokenNumber": "H133027",
        "OpenDate": "24/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "32",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "918",
        "TokenNumber": "H133028",
        "OpenDate": "24/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "6",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "919",
        "TokenNumber": "H133023",
        "OpenDate": "24/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "920",
        "TokenNumber": "H133030",
        "OpenDate": "24/01/2020",
        "CloseDate": "24/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "921",
        "TokenNumber": "H133032",
        "OpenDate": "24/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "922",
        "TokenNumber": "H133034",
        "OpenDate": "24/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "923",
        "TokenNumber": "H133035",
        "OpenDate": "24/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "924",
        "TokenNumber": "H133037",
        "OpenDate": "24/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "925",
        "TokenNumber": "H133041",
        "OpenDate": "24/01/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "926",
        "TokenNumber": "H133043",
        "OpenDate": "24/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "927",
        "TokenNumber": "H133047",
        "OpenDate": "24/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "928",
        "TokenNumber": "H133049",
        "OpenDate": "24/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "929",
        "TokenNumber": "H133050",
        "OpenDate": "24/01/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "930",
        "TokenNumber": "H133051",
        "OpenDate": "24/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "20",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "931",
        "TokenNumber": "H133052",
        "OpenDate": "24/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "932",
        "TokenNumber": "H133055",
        "OpenDate": "24/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "933",
        "TokenNumber": "H133057",
        "OpenDate": "24/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "934",
        "TokenNumber": "H133060",
        "OpenDate": "24/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "18",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "935",
        "TokenNumber": "H133061",
        "OpenDate": "24/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "936",
        "TokenNumber": "H133062",
        "OpenDate": "24/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "937",
        "TokenNumber": "H133063",
        "OpenDate": "24/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "938",
        "TokenNumber": "H133064",
        "OpenDate": "24/01/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "939",
        "TokenNumber": "H133065",
        "OpenDate": "24/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "940",
        "TokenNumber": "H133068",
        "OpenDate": "24/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "19",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "941",
        "TokenNumber": "H133069",
        "OpenDate": "25/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "942",
        "TokenNumber": "H133074",
        "OpenDate": "25/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "943",
        "TokenNumber": "H133073",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "944",
        "TokenNumber": "H133072",
        "OpenDate": "25/01/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "945",
        "TokenNumber": "H133075",
        "OpenDate": "25/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "946",
        "TokenNumber": "H133076",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "947",
        "TokenNumber": "H133079",
        "OpenDate": "25/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "948",
        "TokenNumber": "H133080",
        "OpenDate": "25/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "949",
        "TokenNumber": "H133081",
        "OpenDate": "25/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "31",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "950",
        "TokenNumber": "H133084",
        "OpenDate": "25/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "31",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "951",
        "TokenNumber": "H133083",
        "OpenDate": "25/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "952",
        "TokenNumber": "H133086",
        "OpenDate": "25/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "953",
        "TokenNumber": "H133087",
        "OpenDate": "25/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "954",
        "TokenNumber": "H133088",
        "OpenDate": "25/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "955",
        "TokenNumber": "H133089",
        "OpenDate": "25/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "956",
        "TokenNumber": "H133092",
        "OpenDate": "25/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "957",
        "TokenNumber": "H133091",
        "OpenDate": "25/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "17",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "958",
        "TokenNumber": "H133090",
        "OpenDate": "25/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "959",
        "TokenNumber": "H133094",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "960",
        "TokenNumber": "H133095",
        "OpenDate": "25/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "961",
        "TokenNumber": "H133096",
        "OpenDate": "25/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "962",
        "TokenNumber": "H133097",
        "OpenDate": "25/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "963",
        "TokenNumber": "H133103",
        "OpenDate": "25/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "964",
        "TokenNumber": "H133104",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "965",
        "TokenNumber": "H133105",
        "OpenDate": "25/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "966",
        "TokenNumber": "H133106",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "967",
        "TokenNumber": "H133108",
        "OpenDate": "25/01/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "30",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "968",
        "TokenNumber": "H133109",
        "OpenDate": "25/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "969",
        "TokenNumber": "H133111",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "18",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "970",
        "TokenNumber": "H133113",
        "OpenDate": "25/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "971",
        "TokenNumber": "H133115",
        "OpenDate": "25/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "972",
        "TokenNumber": "H133118",
        "OpenDate": "25/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "973",
        "TokenNumber": "H133119",
        "OpenDate": "25/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "974",
        "TokenNumber": "H133120",
        "OpenDate": "25/01/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "975",
        "TokenNumber": "H133121",
        "OpenDate": "25/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "976",
        "TokenNumber": "H133122",
        "OpenDate": "25/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "977",
        "TokenNumber": "H133123",
        "OpenDate": "25/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "7",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "978",
        "TokenNumber": "H133125",
        "OpenDate": "25/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "979",
        "TokenNumber": "H133126",
        "OpenDate": "25/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "980",
        "TokenNumber": "H133128",
        "OpenDate": "26/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "981",
        "TokenNumber": "H133129",
        "OpenDate": "26/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "982",
        "TokenNumber": "H133130",
        "OpenDate": "26/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "983",
        "TokenNumber": "H133131",
        "OpenDate": "26/01/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "52",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "984",
        "TokenNumber": "H133133",
        "OpenDate": "26/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "985",
        "TokenNumber": "H133132",
        "OpenDate": "26/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "17",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "986",
        "TokenNumber": "H133135",
        "OpenDate": "26/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "987",
        "TokenNumber": "H133134",
        "OpenDate": "26/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "988",
        "TokenNumber": "H133137",
        "OpenDate": "26/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "989",
        "TokenNumber": "H133138",
        "OpenDate": "26/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "990",
        "TokenNumber": "H133141",
        "OpenDate": "26/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "991",
        "TokenNumber": "H133143",
        "OpenDate": "26/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "992",
        "TokenNumber": "H133144",
        "OpenDate": "26/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "43",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "993",
        "TokenNumber": "H133147",
        "OpenDate": "26/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "43",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "994",
        "TokenNumber": "H133151",
        "OpenDate": "26/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "995",
        "TokenNumber": "H133152",
        "OpenDate": "26/01/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "996",
        "TokenNumber": "H133153",
        "OpenDate": "26/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "997",
        "TokenNumber": "H133154",
        "OpenDate": "26/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "998",
        "TokenNumber": "H133158",
        "OpenDate": "26/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "999",
        "TokenNumber": "H133159",
        "OpenDate": "26/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1000",
        "TokenNumber": "H133160",
        "OpenDate": "26/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1001",
        "TokenNumber": "H133161",
        "OpenDate": "26/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "17",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1002",
        "TokenNumber": "H133163",
        "OpenDate": "26/01/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1003",
        "TokenNumber": "H133164",
        "OpenDate": "26/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1004",
        "TokenNumber": "H133166",
        "OpenDate": "27/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "42",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1005",
        "TokenNumber": "H133168",
        "OpenDate": "27/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "0",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1006",
        "TokenNumber": "H133169",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1007",
        "TokenNumber": "H133171",
        "OpenDate": "27/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1008",
        "TokenNumber": "H133172",
        "OpenDate": "27/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "1",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1009",
        "TokenNumber": "H133173",
        "OpenDate": "27/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1010",
        "TokenNumber": "H133175",
        "OpenDate": "27/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1011",
        "TokenNumber": "H133176",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1012",
        "TokenNumber": "H133177",
        "OpenDate": "27/01/2020",
        "CloseDate": "27/01/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1013",
        "TokenNumber": "H133180",
        "OpenDate": "27/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "5",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1014",
        "TokenNumber": "H133182",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1015",
        "TokenNumber": "H133183",
        "OpenDate": "27/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1016",
        "TokenNumber": "H133184",
        "OpenDate": "27/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "15",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1017",
        "TokenNumber": "H133186",
        "OpenDate": "27/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1018",
        "TokenNumber": "H133187",
        "OpenDate": "27/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1019",
        "TokenNumber": "H133188",
        "OpenDate": "27/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1020",
        "TokenNumber": "H133190",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1021",
        "TokenNumber": "H133191",
        "OpenDate": "27/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1022",
        "TokenNumber": "H133193",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1023",
        "TokenNumber": "H133194",
        "OpenDate": "27/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1024",
        "TokenNumber": "H133195",
        "OpenDate": "27/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "22",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1025",
        "TokenNumber": "H133196",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1026",
        "TokenNumber": "H133197",
        "OpenDate": "27/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1027",
        "TokenNumber": "H133198",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1028",
        "TokenNumber": "H133200",
        "OpenDate": "27/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1029",
        "TokenNumber": "H133201",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1030",
        "TokenNumber": "H133202",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1031",
        "TokenNumber": "H133205",
        "OpenDate": "27/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1032",
        "TokenNumber": "H133206",
        "OpenDate": "27/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1033",
        "TokenNumber": "H133208",
        "OpenDate": "27/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1034",
        "TokenNumber": "H133209",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1035",
        "TokenNumber": "H133210",
        "OpenDate": "27/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1036",
        "TokenNumber": "H133211",
        "OpenDate": "27/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "44",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1037",
        "TokenNumber": "H133213",
        "OpenDate": "27/01/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "71",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1038",
        "TokenNumber": "H133214",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1039",
        "TokenNumber": "H133217",
        "OpenDate": "27/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1040",
        "TokenNumber": "H133218",
        "OpenDate": "27/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1041",
        "TokenNumber": "H133219",
        "OpenDate": "27/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1042",
        "TokenNumber": "H133220",
        "OpenDate": "27/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1043",
        "TokenNumber": "H133221",
        "OpenDate": "27/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1044",
        "TokenNumber": "H133222",
        "OpenDate": "27/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1045",
        "TokenNumber": "H133223",
        "OpenDate": "27/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1046",
        "TokenNumber": "H133224",
        "OpenDate": "27/01/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "28",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1047",
        "TokenNumber": "H133225",
        "OpenDate": "27/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1048",
        "TokenNumber": "H133227",
        "OpenDate": "27/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1049",
        "TokenNumber": "H133229",
        "OpenDate": "28/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1050",
        "TokenNumber": "H133230",
        "OpenDate": "28/01/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "70",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1051",
        "TokenNumber": "H133232",
        "OpenDate": "28/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1052",
        "TokenNumber": "H133233",
        "OpenDate": "28/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1053",
        "TokenNumber": "H133234",
        "OpenDate": "28/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1054",
        "TokenNumber": "H133235",
        "OpenDate": "28/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1055",
        "TokenNumber": "H133236",
        "OpenDate": "28/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1056",
        "TokenNumber": "H133237",
        "OpenDate": "28/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1057",
        "TokenNumber": "H133239",
        "OpenDate": "28/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "14",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1058",
        "TokenNumber": "H133240",
        "OpenDate": "28/01/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1059",
        "TokenNumber": "H133241",
        "OpenDate": "28/01/2020",
        "CloseDate": "28/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1060",
        "TokenNumber": "H133244",
        "OpenDate": "28/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1061",
        "TokenNumber": "H133245",
        "OpenDate": "28/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1062",
        "TokenNumber": "H133247",
        "OpenDate": "28/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1063",
        "TokenNumber": "H133248",
        "OpenDate": "28/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1064",
        "TokenNumber": "H133249",
        "OpenDate": "28/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1065",
        "TokenNumber": "H133250",
        "OpenDate": "28/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1066",
        "TokenNumber": "H133251",
        "OpenDate": "28/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1067",
        "TokenNumber": "H133255",
        "OpenDate": "28/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1068",
        "TokenNumber": "H133256",
        "OpenDate": "28/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1069",
        "TokenNumber": "H133258",
        "OpenDate": "28/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1070",
        "TokenNumber": "H133254",
        "OpenDate": "28/01/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1071",
        "TokenNumber": "H133261",
        "OpenDate": "28/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1072",
        "TokenNumber": "H133263",
        "OpenDate": "28/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "41",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1073",
        "TokenNumber": "H133264",
        "OpenDate": "28/01/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "30",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1074",
        "TokenNumber": "H133265",
        "OpenDate": "28/01/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "70",
        "Subject": "Pipeline Leakage",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "1075",
        "TokenNumber": "H133267",
        "OpenDate": "28/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1076",
        "TokenNumber": "H133269",
        "OpenDate": "28/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Stalls & Hawkers.",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1077",
        "TokenNumber": "H133270",
        "OpenDate": "28/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1078",
        "TokenNumber": "H133272",
        "OpenDate": "28/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1079",
        "TokenNumber": "H133274",
        "OpenDate": "28/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1080",
        "TokenNumber": "H133275",
        "OpenDate": "28/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1081",
        "TokenNumber": "H133276",
        "OpenDate": "28/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1082",
        "TokenNumber": "H133278",
        "OpenDate": "28/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "41",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1083",
        "TokenNumber": "H133280",
        "OpenDate": "28/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1084",
        "TokenNumber": "H133279",
        "OpenDate": "28/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1085",
        "TokenNumber": "H133281",
        "OpenDate": "28/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1086",
        "TokenNumber": "H133282",
        "OpenDate": "28/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1087",
        "TokenNumber": "H133283",
        "OpenDate": "28/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1088",
        "TokenNumber": "H133286",
        "OpenDate": "28/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1089",
        "TokenNumber": "H133287",
        "OpenDate": "28/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1090",
        "TokenNumber": "H133288",
        "OpenDate": "28/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1091",
        "TokenNumber": "H133289",
        "OpenDate": "28/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1092",
        "TokenNumber": "H133290",
        "OpenDate": "28/01/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1093",
        "TokenNumber": "H133291",
        "OpenDate": "29/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "0",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1094",
        "TokenNumber": "H133292",
        "OpenDate": "29/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1095",
        "TokenNumber": "H133293",
        "OpenDate": "29/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1096",
        "TokenNumber": "H133294",
        "OpenDate": "29/01/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "49",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1097",
        "TokenNumber": "H133295",
        "OpenDate": "29/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1098",
        "TokenNumber": "H133297",
        "OpenDate": "29/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1099",
        "TokenNumber": "H133298",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1100",
        "TokenNumber": "H133300",
        "OpenDate": "29/01/2020",
        "CloseDate": "29/01/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1101",
        "TokenNumber": "H133301",
        "OpenDate": "29/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1102",
        "TokenNumber": "H133302",
        "OpenDate": "29/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1103",
        "TokenNumber": "H133303",
        "OpenDate": "29/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1104",
        "TokenNumber": "H133309",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1105",
        "TokenNumber": "H133311",
        "OpenDate": "29/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1106",
        "TokenNumber": "H133312",
        "OpenDate": "29/01/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "33",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1107",
        "TokenNumber": "H133314",
        "OpenDate": "29/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1108",
        "TokenNumber": "H133313",
        "OpenDate": "29/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "40",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1109",
        "TokenNumber": "H133316",
        "OpenDate": "29/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1110",
        "TokenNumber": "H133317",
        "OpenDate": "29/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1111",
        "TokenNumber": "H133318",
        "OpenDate": "29/01/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "42",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1112",
        "TokenNumber": "H133320",
        "OpenDate": "29/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1113",
        "TokenNumber": "H133321",
        "OpenDate": "29/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1114",
        "TokenNumber": "H133322",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1115",
        "TokenNumber": "H133323",
        "OpenDate": "29/01/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "35",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1116",
        "TokenNumber": "H133324",
        "OpenDate": "29/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1117",
        "TokenNumber": "H133326",
        "OpenDate": "29/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1118",
        "TokenNumber": "H133327",
        "OpenDate": "29/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1119",
        "TokenNumber": "H133330",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1120",
        "TokenNumber": "H133331",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1121",
        "TokenNumber": "H133332",
        "OpenDate": "29/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1122",
        "TokenNumber": "H133334",
        "OpenDate": "29/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "20",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1123",
        "TokenNumber": "H133333",
        "OpenDate": "29/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1124",
        "TokenNumber": "H133339",
        "OpenDate": "29/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1125",
        "TokenNumber": "H133338",
        "OpenDate": "29/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "9",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1126",
        "TokenNumber": "H133341",
        "OpenDate": "29/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1127",
        "TokenNumber": "H133342",
        "OpenDate": "29/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1128",
        "TokenNumber": "H133340",
        "OpenDate": "29/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1129",
        "TokenNumber": "H133343",
        "OpenDate": "29/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1130",
        "TokenNumber": "H133344",
        "OpenDate": "29/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1131",
        "TokenNumber": "H133345",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1132",
        "TokenNumber": "H133346",
        "OpenDate": "29/01/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1133",
        "TokenNumber": "H133348",
        "OpenDate": "29/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1134",
        "TokenNumber": "H133350",
        "OpenDate": "29/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1135",
        "TokenNumber": "H133352",
        "OpenDate": "29/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1136",
        "TokenNumber": "H133357",
        "OpenDate": "29/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1137",
        "TokenNumber": "H133359",
        "OpenDate": "29/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1138",
        "TokenNumber": "H133361",
        "OpenDate": "29/01/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "22",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1139",
        "TokenNumber": "H133362",
        "OpenDate": "29/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1140",
        "TokenNumber": "H133363",
        "OpenDate": "29/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1141",
        "TokenNumber": "H133366",
        "OpenDate": "29/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "8",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1142",
        "TokenNumber": "H133367",
        "OpenDate": "29/01/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "47",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1143",
        "TokenNumber": "H133368",
        "OpenDate": "30/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "39",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1144",
        "TokenNumber": "H133369",
        "OpenDate": "30/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1145",
        "TokenNumber": "H133370",
        "OpenDate": "30/01/2020",
        "CloseDate": "30/01/2020",
        "CompletionTime": "0",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1146",
        "TokenNumber": "H133374",
        "OpenDate": "30/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1147",
        "TokenNumber": "H133375",
        "OpenDate": "30/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1148",
        "TokenNumber": "H133377",
        "OpenDate": "30/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1149",
        "TokenNumber": "H133378",
        "OpenDate": "30/01/2020",
        "CloseDate": "31/01/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1150",
        "TokenNumber": "H133380",
        "OpenDate": "30/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1151",
        "TokenNumber": "H133379",
        "OpenDate": "30/01/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1152",
        "TokenNumber": "H133382",
        "OpenDate": "30/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1153",
        "TokenNumber": "H133383",
        "OpenDate": "30/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1154",
        "TokenNumber": "H133386",
        "OpenDate": "30/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1155",
        "TokenNumber": "H133390",
        "OpenDate": "30/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1156",
        "TokenNumber": "H133387",
        "OpenDate": "30/01/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "26",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1157",
        "TokenNumber": "H133393",
        "OpenDate": "30/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "39",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1158",
        "TokenNumber": "H133395",
        "OpenDate": "30/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1159",
        "TokenNumber": "H133398",
        "OpenDate": "30/01/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1160",
        "TokenNumber": "H133401",
        "OpenDate": "30/01/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "29",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1161",
        "TokenNumber": "H133403",
        "OpenDate": "30/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1162",
        "TokenNumber": "H133405",
        "OpenDate": "30/01/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1163",
        "TokenNumber": "H133406",
        "OpenDate": "30/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1164",
        "TokenNumber": "H133407",
        "OpenDate": "30/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1165",
        "TokenNumber": "H133410",
        "OpenDate": "30/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1167",
        "TokenNumber": "H133414",
        "OpenDate": "30/01/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1168",
        "TokenNumber": "H133415",
        "OpenDate": "30/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1169",
        "TokenNumber": "H133416",
        "OpenDate": "30/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1170",
        "TokenNumber": "H133417",
        "OpenDate": "30/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1171",
        "TokenNumber": "H133419",
        "OpenDate": "30/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1172",
        "TokenNumber": "H133420",
        "OpenDate": "30/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1173",
        "TokenNumber": "H133422",
        "OpenDate": "30/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1174",
        "TokenNumber": "H133424",
        "OpenDate": "30/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1175",
        "TokenNumber": "H133425",
        "OpenDate": "30/01/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "68",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1176",
        "TokenNumber": "H133426",
        "OpenDate": "30/01/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1177",
        "TokenNumber": "H133427",
        "OpenDate": "30/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1178",
        "TokenNumber": "H133428",
        "OpenDate": "30/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1179",
        "TokenNumber": "H133429",
        "OpenDate": "30/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1180",
        "TokenNumber": "H133431",
        "OpenDate": "30/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1181",
        "TokenNumber": "H133435",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1182",
        "TokenNumber": "H133436",
        "OpenDate": "31/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1183",
        "TokenNumber": "H133437",
        "OpenDate": "31/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1184",
        "TokenNumber": "H133438",
        "OpenDate": "31/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1185",
        "TokenNumber": "H133439",
        "OpenDate": "31/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "18",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1186",
        "TokenNumber": "H133440",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1187",
        "TokenNumber": "H133441",
        "OpenDate": "31/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1188",
        "TokenNumber": "H133443",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1189",
        "TokenNumber": "H133445",
        "OpenDate": "31/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1190",
        "TokenNumber": "H133446",
        "OpenDate": "31/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "11",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1191",
        "TokenNumber": "H133450",
        "OpenDate": "31/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1192",
        "TokenNumber": "H133448",
        "OpenDate": "31/01/2020",
        "CloseDate": "10/03/2020",
        "CompletionTime": "39",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1193",
        "TokenNumber": "H133451",
        "OpenDate": "31/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1194",
        "TokenNumber": "H133453",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1195",
        "TokenNumber": "H133454",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1196",
        "TokenNumber": "H133455",
        "OpenDate": "31/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1197",
        "TokenNumber": "H133456",
        "OpenDate": "31/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1198",
        "TokenNumber": "H133457",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1199",
        "TokenNumber": "H133458",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1200",
        "TokenNumber": "H133460",
        "OpenDate": "31/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1201",
        "TokenNumber": "H133463",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1202",
        "TokenNumber": "H133464",
        "OpenDate": "31/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "7",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1203",
        "TokenNumber": "H133465",
        "OpenDate": "31/01/2020",
        "CloseDate": "01/02/2020",
        "CompletionTime": "1",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1204",
        "TokenNumber": "H133466",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1205",
        "TokenNumber": "H133467",
        "OpenDate": "31/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1206",
        "TokenNumber": "H133468",
        "OpenDate": "31/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1207",
        "TokenNumber": "H133469",
        "OpenDate": "31/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1208",
        "TokenNumber": "H133472",
        "OpenDate": "31/01/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1209",
        "TokenNumber": "H133473",
        "OpenDate": "31/01/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1210",
        "TokenNumber": "H133474",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1211",
        "TokenNumber": "H133476",
        "OpenDate": "31/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1212",
        "TokenNumber": "H133477",
        "OpenDate": "31/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1213",
        "TokenNumber": "H133478",
        "OpenDate": "31/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1214",
        "TokenNumber": "H133479",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1215",
        "TokenNumber": "H133481",
        "OpenDate": "31/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "5",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1216",
        "TokenNumber": "H133483",
        "OpenDate": "31/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1217",
        "TokenNumber": "H133484",
        "OpenDate": "31/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1218",
        "TokenNumber": "H133485",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1219",
        "TokenNumber": "H133486",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1220",
        "TokenNumber": "H133487",
        "OpenDate": "31/01/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1221",
        "TokenNumber": "H133489",
        "OpenDate": "31/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1222",
        "TokenNumber": "H133490",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1223",
        "TokenNumber": "H133491",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1224",
        "TokenNumber": "H133493",
        "OpenDate": "31/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "18",
        "Subject": "Irregular Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1225",
        "TokenNumber": "H133492",
        "OpenDate": "31/01/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1226",
        "TokenNumber": "H133494",
        "OpenDate": "31/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1227",
        "TokenNumber": "H133495",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1228",
        "TokenNumber": "H133497",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1229",
        "TokenNumber": "H133498",
        "OpenDate": "31/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1230",
        "TokenNumber": "H133499",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1231",
        "TokenNumber": "H133500",
        "OpenDate": "31/01/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1232",
        "TokenNumber": "H133501",
        "OpenDate": "31/01/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1233",
        "TokenNumber": "H133502",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1234",
        "TokenNumber": "H133504",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1235",
        "TokenNumber": "H133505",
        "OpenDate": "31/01/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1236",
        "TokenNumber": "H133506",
        "OpenDate": "31/01/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1237",
        "TokenNumber": "H133507",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1238",
        "TokenNumber": "H133508",
        "OpenDate": "31/01/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1239",
        "TokenNumber": "H133510",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1240",
        "TokenNumber": "H133511",
        "OpenDate": "31/01/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1241",
        "TokenNumber": "H133512",
        "OpenDate": "31/01/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1242",
        "TokenNumber": "H133513",
        "OpenDate": "31/01/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1243",
        "TokenNumber": "H133514",
        "OpenDate": "31/01/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1244",
        "TokenNumber": "H133515",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1245",
        "TokenNumber": "H133518",
        "OpenDate": "31/01/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1246",
        "TokenNumber": "H133521",
        "OpenDate": "31/01/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1247",
        "TokenNumber": "H133523",
        "OpenDate": "01/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "37",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1248",
        "TokenNumber": "H133524",
        "OpenDate": "01/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "37",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1249",
        "TokenNumber": "H133525",
        "OpenDate": "01/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1250",
        "TokenNumber": "H133526",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1251",
        "TokenNumber": "H133527",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1252",
        "TokenNumber": "H133529",
        "OpenDate": "01/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1253",
        "TokenNumber": "H133520",
        "OpenDate": "01/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1254",
        "TokenNumber": "H133530",
        "OpenDate": "01/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1255",
        "TokenNumber": "H133509",
        "OpenDate": "01/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1256",
        "TokenNumber": "H133531",
        "OpenDate": "01/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1257",
        "TokenNumber": "H133534",
        "OpenDate": "01/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1258",
        "TokenNumber": "H133535",
        "OpenDate": "01/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1259",
        "TokenNumber": "H133536",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1260",
        "TokenNumber": "H133537",
        "OpenDate": "01/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "39",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1261",
        "TokenNumber": "H133538",
        "OpenDate": "01/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1262",
        "TokenNumber": "H133539",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1263",
        "TokenNumber": "H133540",
        "OpenDate": "01/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1264",
        "TokenNumber": "H133543",
        "OpenDate": "01/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1265",
        "TokenNumber": "H133544",
        "OpenDate": "01/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1266",
        "TokenNumber": "H133546",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1267",
        "TokenNumber": "H133548",
        "OpenDate": "01/02/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "68",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1268",
        "TokenNumber": "H133549",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1269",
        "TokenNumber": "H133550",
        "OpenDate": "01/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1270",
        "TokenNumber": "H133551",
        "OpenDate": "01/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1271",
        "TokenNumber": "H133552",
        "OpenDate": "01/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1272",
        "TokenNumber": "H133555",
        "OpenDate": "01/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1273",
        "TokenNumber": "H133563",
        "OpenDate": "01/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1274",
        "TokenNumber": "H133562",
        "OpenDate": "01/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1275",
        "TokenNumber": "H133560",
        "OpenDate": "01/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1276",
        "TokenNumber": "H133564",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1277",
        "TokenNumber": "H133566",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1278",
        "TokenNumber": "H133567",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1279",
        "TokenNumber": "H133568",
        "OpenDate": "01/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1280",
        "TokenNumber": "H133569",
        "OpenDate": "01/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "27",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1281",
        "TokenNumber": "H133570",
        "OpenDate": "01/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1282",
        "TokenNumber": "H133572",
        "OpenDate": "01/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1283",
        "TokenNumber": "H133573",
        "OpenDate": "01/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "67",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1284",
        "TokenNumber": "H133574",
        "OpenDate": "01/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "16",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1285",
        "TokenNumber": "H133576",
        "OpenDate": "01/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1286",
        "TokenNumber": "H133575",
        "OpenDate": "01/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1287",
        "TokenNumber": "H133577",
        "OpenDate": "01/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1288",
        "TokenNumber": "H133578",
        "OpenDate": "01/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1289",
        "TokenNumber": "H133583",
        "OpenDate": "01/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1290",
        "TokenNumber": "H133585",
        "OpenDate": "01/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1291",
        "TokenNumber": "H133586",
        "OpenDate": "02/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1292",
        "TokenNumber": "H133587",
        "OpenDate": "02/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1293",
        "TokenNumber": "H133588",
        "OpenDate": "02/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1294",
        "TokenNumber": "H133589",
        "OpenDate": "02/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1295",
        "TokenNumber": "H133590",
        "OpenDate": "02/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1296",
        "TokenNumber": "H133591",
        "OpenDate": "02/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1297",
        "TokenNumber": "H133594",
        "OpenDate": "02/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1298",
        "TokenNumber": "H133595",
        "OpenDate": "02/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "36",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1299",
        "TokenNumber": "H133597",
        "OpenDate": "02/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1300",
        "TokenNumber": "H133599",
        "OpenDate": "02/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1301",
        "TokenNumber": "H133600",
        "OpenDate": "02/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1302",
        "TokenNumber": "H133601",
        "OpenDate": "02/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1303",
        "TokenNumber": "H133603",
        "OpenDate": "02/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1304",
        "TokenNumber": "H133605",
        "OpenDate": "02/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "23",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1305",
        "TokenNumber": "H133609",
        "OpenDate": "02/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1306",
        "TokenNumber": "H133611",
        "OpenDate": "02/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1307",
        "TokenNumber": "H133612",
        "OpenDate": "02/02/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "78",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1308",
        "TokenNumber": "H133613",
        "OpenDate": "02/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1309",
        "TokenNumber": "H133614",
        "OpenDate": "02/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1310",
        "TokenNumber": "H133616",
        "OpenDate": "02/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1311",
        "TokenNumber": "H133617",
        "OpenDate": "02/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1312",
        "TokenNumber": "H133618",
        "OpenDate": "02/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1313",
        "TokenNumber": "H133619",
        "OpenDate": "02/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1314",
        "TokenNumber": "H133620",
        "OpenDate": "02/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1315",
        "TokenNumber": "H133621",
        "OpenDate": "02/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1316",
        "TokenNumber": "H133622",
        "OpenDate": "02/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1317",
        "TokenNumber": "H133624",
        "OpenDate": "02/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "43",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1318",
        "TokenNumber": "H133625",
        "OpenDate": "02/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1319",
        "TokenNumber": "H133626",
        "OpenDate": "02/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1320",
        "TokenNumber": "H133627",
        "OpenDate": "02/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1321",
        "TokenNumber": "H133629",
        "OpenDate": "02/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "38",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1322",
        "TokenNumber": "H133630",
        "OpenDate": "03/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1323",
        "TokenNumber": "H133631",
        "OpenDate": "03/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1324",
        "TokenNumber": "H133632",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1325",
        "TokenNumber": "H133633",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1326",
        "TokenNumber": "H133634",
        "OpenDate": "03/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1327",
        "TokenNumber": "H133635",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1328",
        "TokenNumber": "H133637",
        "OpenDate": "03/02/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "0",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1329",
        "TokenNumber": "H133638",
        "OpenDate": "03/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1330",
        "TokenNumber": "H133639",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1331",
        "TokenNumber": "H133640",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1332",
        "TokenNumber": "H133641",
        "OpenDate": "03/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1333",
        "TokenNumber": "H133642",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1334",
        "TokenNumber": "H133645",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1335",
        "TokenNumber": "H133647",
        "OpenDate": "03/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1336",
        "TokenNumber": "H133646",
        "OpenDate": "03/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1337",
        "TokenNumber": "H132991",
        "OpenDate": "03/02/2020",
        "CloseDate": "03/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1338",
        "TokenNumber": "H133648",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1339",
        "TokenNumber": "H133649",
        "OpenDate": "03/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1340",
        "TokenNumber": "H133654",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1341",
        "TokenNumber": "H133655",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1342",
        "TokenNumber": "H133656",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1343",
        "TokenNumber": "H133658",
        "OpenDate": "03/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "70",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1344",
        "TokenNumber": "H133659",
        "OpenDate": "03/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1345",
        "TokenNumber": "H133661",
        "OpenDate": "03/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1346",
        "TokenNumber": "H133662",
        "OpenDate": "03/02/2020",
        "CloseDate": "10/03/2020",
        "CompletionTime": "36",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1347",
        "TokenNumber": "H133663",
        "OpenDate": "03/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1348",
        "TokenNumber": "H133665",
        "OpenDate": "03/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1349",
        "TokenNumber": "H133668",
        "OpenDate": "03/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1350",
        "TokenNumber": "H133671",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1351",
        "TokenNumber": "H133669",
        "OpenDate": "03/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1352",
        "TokenNumber": "H133670",
        "OpenDate": "03/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1353",
        "TokenNumber": "H133672",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1354",
        "TokenNumber": "H133673",
        "OpenDate": "03/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1355",
        "TokenNumber": "H133674",
        "OpenDate": "03/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "14",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1356",
        "TokenNumber": "H133677",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1357",
        "TokenNumber": "H133679",
        "OpenDate": "03/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1358",
        "TokenNumber": "H133683",
        "OpenDate": "03/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1359",
        "TokenNumber": "H133684",
        "OpenDate": "03/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1360",
        "TokenNumber": "H133686",
        "OpenDate": "03/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1361",
        "TokenNumber": "H133688",
        "OpenDate": "03/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1362",
        "TokenNumber": "H133691",
        "OpenDate": "03/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1363",
        "TokenNumber": "H133692",
        "OpenDate": "03/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1364",
        "TokenNumber": "H133695",
        "OpenDate": "03/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1365",
        "TokenNumber": "H133696",
        "OpenDate": "03/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "8",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1366",
        "TokenNumber": "H133697",
        "OpenDate": "03/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1367",
        "TokenNumber": "H133698",
        "OpenDate": "03/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "15",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1368",
        "TokenNumber": "H133699",
        "OpenDate": "03/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1369",
        "TokenNumber": "H133700",
        "OpenDate": "03/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1370",
        "TokenNumber": "H133701",
        "OpenDate": "03/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1371",
        "TokenNumber": "H133707",
        "OpenDate": "04/02/2020",
        "CloseDate": "04/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1372",
        "TokenNumber": "H133708",
        "OpenDate": "04/02/2020",
        "CloseDate": "05/02/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1373",
        "TokenNumber": "H133712",
        "OpenDate": "04/02/2020",
        "CloseDate": "08/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1374",
        "TokenNumber": "H133714",
        "OpenDate": "04/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1375",
        "TokenNumber": "H133715",
        "OpenDate": "04/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "14",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1376",
        "TokenNumber": "H133719",
        "OpenDate": "04/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "31",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1377",
        "TokenNumber": "H133720",
        "OpenDate": "04/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1378",
        "TokenNumber": "H133721",
        "OpenDate": "04/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1379",
        "TokenNumber": "H133724",
        "OpenDate": "04/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1380",
        "TokenNumber": "H133726",
        "OpenDate": "04/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1381",
        "TokenNumber": "H133728",
        "OpenDate": "04/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1382",
        "TokenNumber": "H133730",
        "OpenDate": "04/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1383",
        "TokenNumber": "H133731",
        "OpenDate": "04/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "41",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1384",
        "TokenNumber": "H133732",
        "OpenDate": "04/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1385",
        "TokenNumber": "H133733",
        "OpenDate": "04/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "34",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1386",
        "TokenNumber": "H133735",
        "OpenDate": "04/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1387",
        "TokenNumber": "H133736",
        "OpenDate": "04/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "64",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1388",
        "TokenNumber": "H133737",
        "OpenDate": "04/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1389",
        "TokenNumber": "H133738",
        "OpenDate": "04/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1390",
        "TokenNumber": "H133739",
        "OpenDate": "04/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1391",
        "TokenNumber": "H133740",
        "OpenDate": "04/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1392",
        "TokenNumber": "H133741",
        "OpenDate": "04/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1393",
        "TokenNumber": "H133742",
        "OpenDate": "04/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1394",
        "TokenNumber": "H133743",
        "OpenDate": "04/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1395",
        "TokenNumber": "H133744",
        "OpenDate": "04/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1396",
        "TokenNumber": "H133745",
        "OpenDate": "04/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1397",
        "TokenNumber": "H133746",
        "OpenDate": "04/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1398",
        "TokenNumber": "H133748",
        "OpenDate": "04/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "14",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1399",
        "TokenNumber": "H133747",
        "OpenDate": "04/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1400",
        "TokenNumber": "H133749",
        "OpenDate": "04/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1401",
        "TokenNumber": "H133753",
        "OpenDate": "04/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1402",
        "TokenNumber": "H133756",
        "OpenDate": "04/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1403",
        "TokenNumber": "H133760",
        "OpenDate": "04/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1404",
        "TokenNumber": "H133761",
        "OpenDate": "04/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1405",
        "TokenNumber": "H133762",
        "OpenDate": "04/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "10",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1406",
        "TokenNumber": "H133764",
        "OpenDate": "04/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1407",
        "TokenNumber": "H133765",
        "OpenDate": "04/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1408",
        "TokenNumber": "H133768",
        "OpenDate": "05/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1409",
        "TokenNumber": "H133770",
        "OpenDate": "05/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1410",
        "TokenNumber": "H133773",
        "OpenDate": "05/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1411",
        "TokenNumber": "H133776",
        "OpenDate": "05/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1412",
        "TokenNumber": "H133777",
        "OpenDate": "05/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1413",
        "TokenNumber": "H133779",
        "OpenDate": "05/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1414",
        "TokenNumber": "H133780",
        "OpenDate": "05/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1415",
        "TokenNumber": "H133781",
        "OpenDate": "05/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1416",
        "TokenNumber": "H133787",
        "OpenDate": "05/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1417",
        "TokenNumber": "H133790",
        "OpenDate": "05/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1418",
        "TokenNumber": "H133791",
        "OpenDate": "05/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1419",
        "TokenNumber": "H133792",
        "OpenDate": "05/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "8",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1420",
        "TokenNumber": "H133793",
        "OpenDate": "05/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1421",
        "TokenNumber": "H133799",
        "OpenDate": "05/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1422",
        "TokenNumber": "H133803",
        "OpenDate": "05/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1423",
        "TokenNumber": "H133805",
        "OpenDate": "05/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1424",
        "TokenNumber": "H133806",
        "OpenDate": "05/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1425",
        "TokenNumber": "H133809",
        "OpenDate": "05/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1426",
        "TokenNumber": "H133810",
        "OpenDate": "05/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1427",
        "TokenNumber": "H133813",
        "OpenDate": "05/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1428",
        "TokenNumber": "H133818",
        "OpenDate": "05/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1429",
        "TokenNumber": "H133820",
        "OpenDate": "05/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1430",
        "TokenNumber": "H133819",
        "OpenDate": "05/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1431",
        "TokenNumber": "H133822",
        "OpenDate": "05/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1432",
        "TokenNumber": "H133823",
        "OpenDate": "05/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1433",
        "TokenNumber": "H133825",
        "OpenDate": "05/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1434",
        "TokenNumber": "H133827",
        "OpenDate": "05/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1435",
        "TokenNumber": "H133829",
        "OpenDate": "05/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1436",
        "TokenNumber": "H133828",
        "OpenDate": "05/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1437",
        "TokenNumber": "H133830",
        "OpenDate": "05/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1438",
        "TokenNumber": "H133831",
        "OpenDate": "05/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1439",
        "TokenNumber": "H133832",
        "OpenDate": "05/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1440",
        "TokenNumber": "H133833",
        "OpenDate": "05/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "21",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1441",
        "TokenNumber": "H133834",
        "OpenDate": "05/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1442",
        "TokenNumber": "H133836",
        "OpenDate": "06/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1443",
        "TokenNumber": "H133837",
        "OpenDate": "06/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1444",
        "TokenNumber": "H133839",
        "OpenDate": "06/02/2020",
        "CloseDate": "06/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1445",
        "TokenNumber": "H133838",
        "OpenDate": "06/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1446",
        "TokenNumber": "H133840",
        "OpenDate": "06/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "32",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1447",
        "TokenNumber": "H133841",
        "OpenDate": "06/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1448",
        "TokenNumber": "H133842",
        "OpenDate": "06/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1449",
        "TokenNumber": "H133843",
        "OpenDate": "06/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "14",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1450",
        "TokenNumber": "H133845",
        "OpenDate": "06/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1451",
        "TokenNumber": "H133848",
        "OpenDate": "06/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1452",
        "TokenNumber": "H133849",
        "OpenDate": "06/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1453",
        "TokenNumber": "H133851",
        "OpenDate": "06/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1454",
        "TokenNumber": "H133852",
        "OpenDate": "06/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1455",
        "TokenNumber": "H133853",
        "OpenDate": "06/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "6",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1456",
        "TokenNumber": "H133854",
        "OpenDate": "06/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1457",
        "TokenNumber": "H133857",
        "OpenDate": "06/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1458",
        "TokenNumber": "H133860",
        "OpenDate": "06/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1459",
        "TokenNumber": "H133861",
        "OpenDate": "06/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1460",
        "TokenNumber": "H133862",
        "OpenDate": "06/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1461",
        "TokenNumber": "H133863",
        "OpenDate": "06/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1462",
        "TokenNumber": "H133865",
        "OpenDate": "06/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1463",
        "TokenNumber": "H133867",
        "OpenDate": "06/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "34",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1464",
        "TokenNumber": "H133868",
        "OpenDate": "06/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1465",
        "TokenNumber": "H133871",
        "OpenDate": "06/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1467",
        "TokenNumber": "H133873",
        "OpenDate": "06/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1468",
        "TokenNumber": "H133875",
        "OpenDate": "06/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "43",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1469",
        "TokenNumber": "H133874",
        "OpenDate": "06/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1470",
        "TokenNumber": "H133876",
        "OpenDate": "06/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "32",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1471",
        "TokenNumber": "H133877",
        "OpenDate": "06/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1472",
        "TokenNumber": "H133882",
        "OpenDate": "06/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "11",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1473",
        "TokenNumber": "H133883",
        "OpenDate": "06/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1474",
        "TokenNumber": "H133884",
        "OpenDate": "06/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1475",
        "TokenNumber": "H133885",
        "OpenDate": "06/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1476",
        "TokenNumber": "H133886",
        "OpenDate": "06/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1477",
        "TokenNumber": "H133887",
        "OpenDate": "06/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1478",
        "TokenNumber": "H133890",
        "OpenDate": "06/02/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "57",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1479",
        "TokenNumber": "H133893",
        "OpenDate": "06/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1480",
        "TokenNumber": "H133895",
        "OpenDate": "06/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1481",
        "TokenNumber": "H133896",
        "OpenDate": "06/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1482",
        "TokenNumber": "H133897",
        "OpenDate": "06/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1483",
        "TokenNumber": "H133898",
        "OpenDate": "06/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1484",
        "TokenNumber": "H133899",
        "OpenDate": "06/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1485",
        "TokenNumber": "H133900",
        "OpenDate": "06/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1486",
        "TokenNumber": "H133901",
        "OpenDate": "06/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1487",
        "TokenNumber": "H133902",
        "OpenDate": "06/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1488",
        "TokenNumber": "H133903",
        "OpenDate": "06/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1489",
        "TokenNumber": "H133904",
        "OpenDate": "06/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1490",
        "TokenNumber": "H133906",
        "OpenDate": "07/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1491",
        "TokenNumber": "H133907",
        "OpenDate": "07/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1492",
        "TokenNumber": "H133910",
        "OpenDate": "07/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1493",
        "TokenNumber": "H133913",
        "OpenDate": "07/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1494",
        "TokenNumber": "H133914",
        "OpenDate": "07/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1495",
        "TokenNumber": "H133892",
        "OpenDate": "07/02/2020",
        "CloseDate": "25/04/2020",
        "CompletionTime": "78",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1496",
        "TokenNumber": "H133918",
        "OpenDate": "07/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1497",
        "TokenNumber": "H133919",
        "OpenDate": "07/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1498",
        "TokenNumber": "H133920",
        "OpenDate": "07/02/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1499",
        "TokenNumber": "H133922",
        "OpenDate": "07/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1500",
        "TokenNumber": "H133921",
        "OpenDate": "07/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1501",
        "TokenNumber": "H133923",
        "OpenDate": "07/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1502",
        "TokenNumber": "H133925",
        "OpenDate": "07/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1503",
        "TokenNumber": "H133926",
        "OpenDate": "07/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1504",
        "TokenNumber": "H133928",
        "OpenDate": "07/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1505",
        "TokenNumber": "H133924",
        "OpenDate": "07/02/2020",
        "CloseDate": "07/02/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1506",
        "TokenNumber": "H133930",
        "OpenDate": "07/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1507",
        "TokenNumber": "H133931",
        "OpenDate": "07/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "17",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1508",
        "TokenNumber": "H133932",
        "OpenDate": "07/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1509",
        "TokenNumber": "H133938",
        "OpenDate": "07/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1510",
        "TokenNumber": "H133939",
        "OpenDate": "07/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "35",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1511",
        "TokenNumber": "H133941",
        "OpenDate": "07/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1512",
        "TokenNumber": "H133943",
        "OpenDate": "07/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1513",
        "TokenNumber": "H133944",
        "OpenDate": "07/02/2020",
        "CloseDate": "23/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1514",
        "TokenNumber": "H133945",
        "OpenDate": "07/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1515",
        "TokenNumber": "H133947",
        "OpenDate": "07/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "31",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1516",
        "TokenNumber": "H133950",
        "OpenDate": "07/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1517",
        "TokenNumber": "H133951",
        "OpenDate": "07/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1518",
        "TokenNumber": "H133952",
        "OpenDate": "07/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1519",
        "TokenNumber": "H133954",
        "OpenDate": "07/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1520",
        "TokenNumber": "H133960",
        "OpenDate": "07/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1521",
        "TokenNumber": "H133961",
        "OpenDate": "07/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1522",
        "TokenNumber": "H133963",
        "OpenDate": "07/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1523",
        "TokenNumber": "H133965",
        "OpenDate": "07/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1524",
        "TokenNumber": "H133966",
        "OpenDate": "07/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1525",
        "TokenNumber": "H133968",
        "OpenDate": "07/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1526",
        "TokenNumber": "H133969",
        "OpenDate": "07/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1527",
        "TokenNumber": "H133970",
        "OpenDate": "07/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1528",
        "TokenNumber": "H133971",
        "OpenDate": "08/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1529",
        "TokenNumber": "H133973",
        "OpenDate": "08/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1530",
        "TokenNumber": "H133974",
        "OpenDate": "08/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1531",
        "TokenNumber": "H133975",
        "OpenDate": "08/02/2020",
        "CloseDate": "23/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1532",
        "TokenNumber": "H133976",
        "OpenDate": "08/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1533",
        "TokenNumber": "H133979",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1534",
        "TokenNumber": "H133981",
        "OpenDate": "08/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1535",
        "TokenNumber": "H133984",
        "OpenDate": "08/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1536",
        "TokenNumber": "H133983",
        "OpenDate": "08/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1537",
        "TokenNumber": "H133985",
        "OpenDate": "08/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1538",
        "TokenNumber": "H133987",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1539",
        "TokenNumber": "H133988",
        "OpenDate": "08/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1540",
        "TokenNumber": "H133991",
        "OpenDate": "08/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1541",
        "TokenNumber": "H133997",
        "OpenDate": "08/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1543",
        "TokenNumber": "H134002",
        "OpenDate": "08/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1544",
        "TokenNumber": "H134004",
        "OpenDate": "08/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1545",
        "TokenNumber": "H134003",
        "OpenDate": "08/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1546",
        "TokenNumber": "H134006",
        "OpenDate": "08/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1547",
        "TokenNumber": "H134009",
        "OpenDate": "08/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1548",
        "TokenNumber": "H134008",
        "OpenDate": "08/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1549",
        "TokenNumber": "H134011",
        "OpenDate": "08/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1550",
        "TokenNumber": "H134015",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1551",
        "TokenNumber": "H134016",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1552",
        "TokenNumber": "H134017",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1553",
        "TokenNumber": "H134018",
        "OpenDate": "08/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1554",
        "TokenNumber": "H134019",
        "OpenDate": "08/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1555",
        "TokenNumber": "H134021",
        "OpenDate": "08/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1556",
        "TokenNumber": "H134022",
        "OpenDate": "08/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1557",
        "TokenNumber": "H134024",
        "OpenDate": "08/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1558",
        "TokenNumber": "H134025",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1560",
        "TokenNumber": "H134027",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1561",
        "TokenNumber": "H134028",
        "OpenDate": "08/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1563",
        "TokenNumber": "H134030",
        "OpenDate": "08/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1564",
        "TokenNumber": "H134033",
        "OpenDate": "08/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1565",
        "TokenNumber": "H134032",
        "OpenDate": "08/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1566",
        "TokenNumber": "H134034",
        "OpenDate": "08/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1567",
        "TokenNumber": "H134039",
        "OpenDate": "08/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1568",
        "TokenNumber": "H134040",
        "OpenDate": "09/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1569",
        "TokenNumber": "H134041",
        "OpenDate": "09/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1570",
        "TokenNumber": "H134042",
        "OpenDate": "09/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1571",
        "TokenNumber": "H134043",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1572",
        "TokenNumber": "H134044",
        "OpenDate": "09/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1573",
        "TokenNumber": "H134045",
        "OpenDate": "09/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1574",
        "TokenNumber": "H134046",
        "OpenDate": "09/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "29",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1575",
        "TokenNumber": "H134048",
        "OpenDate": "09/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1576",
        "TokenNumber": "H134049",
        "OpenDate": "09/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1577",
        "TokenNumber": "H134052",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1578",
        "TokenNumber": "H134054",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "31",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1579",
        "TokenNumber": "H134059",
        "OpenDate": "09/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1580",
        "TokenNumber": "H134060",
        "OpenDate": "09/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1581",
        "TokenNumber": "H134061",
        "OpenDate": "09/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1582",
        "TokenNumber": "H134062",
        "OpenDate": "09/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1583",
        "TokenNumber": "H134063",
        "OpenDate": "09/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1584",
        "TokenNumber": "H134065",
        "OpenDate": "09/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1585",
        "TokenNumber": "H134067",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1586",
        "TokenNumber": "H134066",
        "OpenDate": "09/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1587",
        "TokenNumber": "H134070",
        "OpenDate": "09/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1588",
        "TokenNumber": "H134071",
        "OpenDate": "09/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1589",
        "TokenNumber": "H134074",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1590",
        "TokenNumber": "H134075",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1591",
        "TokenNumber": "H134076",
        "OpenDate": "09/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1592",
        "TokenNumber": "H134077",
        "OpenDate": "09/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1593",
        "TokenNumber": "H134078",
        "OpenDate": "09/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1594",
        "TokenNumber": "H134079",
        "OpenDate": "09/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1595",
        "TokenNumber": "H134080",
        "OpenDate": "09/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1596",
        "TokenNumber": "H134081",
        "OpenDate": "09/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1597",
        "TokenNumber": "H134082",
        "OpenDate": "09/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1598",
        "TokenNumber": "H134083",
        "OpenDate": "09/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1599",
        "TokenNumber": "H134084",
        "OpenDate": "10/02/2020",
        "CloseDate": "10/02/2020",
        "CompletionTime": "0",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1600",
        "TokenNumber": "H134085",
        "OpenDate": "10/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "18",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1601",
        "TokenNumber": "H134086",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1602",
        "TokenNumber": "H134090",
        "OpenDate": "10/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1603",
        "TokenNumber": "H134093",
        "OpenDate": "10/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1604",
        "TokenNumber": "H134094",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1605",
        "TokenNumber": "H134097",
        "OpenDate": "10/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1606",
        "TokenNumber": "H134099",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1607",
        "TokenNumber": "H134100",
        "OpenDate": "10/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1608",
        "TokenNumber": "H134102",
        "OpenDate": "10/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1609",
        "TokenNumber": "H134103",
        "OpenDate": "10/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1610",
        "TokenNumber": "H134104",
        "OpenDate": "10/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1611",
        "TokenNumber": "H134107",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1612",
        "TokenNumber": "H134108",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1613",
        "TokenNumber": "H134109",
        "OpenDate": "10/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1614",
        "TokenNumber": "H134114",
        "OpenDate": "10/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1615",
        "TokenNumber": "H134115",
        "OpenDate": "10/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1616",
        "TokenNumber": "H134117",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1617",
        "TokenNumber": "H134118",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1618",
        "TokenNumber": "H134119",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1619",
        "TokenNumber": "H134120",
        "OpenDate": "10/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1620",
        "TokenNumber": "H134121",
        "OpenDate": "10/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1621",
        "TokenNumber": "H134123",
        "OpenDate": "10/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1622",
        "TokenNumber": "H134127",
        "OpenDate": "10/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1623",
        "TokenNumber": "H134128",
        "OpenDate": "10/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1624",
        "TokenNumber": "H134129",
        "OpenDate": "10/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1625",
        "TokenNumber": "H134131",
        "OpenDate": "10/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1626",
        "TokenNumber": "H134132",
        "OpenDate": "10/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1627",
        "TokenNumber": "H134133",
        "OpenDate": "10/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1628",
        "TokenNumber": "H134135",
        "OpenDate": "10/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "23",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1629",
        "TokenNumber": "H134137",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1630",
        "TokenNumber": "H134138",
        "OpenDate": "10/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1631",
        "TokenNumber": "H134139",
        "OpenDate": "10/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "30",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1632",
        "TokenNumber": "H134140",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1633",
        "TokenNumber": "H134141",
        "OpenDate": "10/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1634",
        "TokenNumber": "H134142",
        "OpenDate": "10/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1635",
        "TokenNumber": "H134144",
        "OpenDate": "10/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1636",
        "TokenNumber": "H134146",
        "OpenDate": "10/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1637",
        "TokenNumber": "H134147",
        "OpenDate": "10/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1638",
        "TokenNumber": "H134148",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1639",
        "TokenNumber": "H134150",
        "OpenDate": "10/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1640",
        "TokenNumber": "H134151",
        "OpenDate": "10/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1641",
        "TokenNumber": "H134152",
        "OpenDate": "10/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1642",
        "TokenNumber": "H134153",
        "OpenDate": "10/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1643",
        "TokenNumber": "H134154",
        "OpenDate": "10/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1644",
        "TokenNumber": "H134155",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1645",
        "TokenNumber": "H134157",
        "OpenDate": "10/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1646",
        "TokenNumber": "H134160",
        "OpenDate": "10/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1647",
        "TokenNumber": "H134161",
        "OpenDate": "10/02/2020",
        "CloseDate": "23/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1648",
        "TokenNumber": "H134162",
        "OpenDate": "10/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1650",
        "TokenNumber": "H134164",
        "OpenDate": "10/02/2020",
        "CloseDate": "10/03/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1651",
        "TokenNumber": "H134165",
        "OpenDate": "10/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1652",
        "TokenNumber": "H134166",
        "OpenDate": "10/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1653",
        "TokenNumber": "H134168",
        "OpenDate": "10/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1654",
        "TokenNumber": "H134170",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1655",
        "TokenNumber": "H134171",
        "OpenDate": "10/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1656",
        "TokenNumber": "H134173",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1657",
        "TokenNumber": "H134174",
        "OpenDate": "11/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1658",
        "TokenNumber": "H134176",
        "OpenDate": "11/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1659",
        "TokenNumber": "H134175",
        "OpenDate": "11/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1660",
        "TokenNumber": "H134177",
        "OpenDate": "11/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "23",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1661",
        "TokenNumber": "H134178",
        "OpenDate": "11/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1662",
        "TokenNumber": "H134180",
        "OpenDate": "11/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1663",
        "TokenNumber": "H134179",
        "OpenDate": "11/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1664",
        "TokenNumber": "H134181",
        "OpenDate": "11/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1665",
        "TokenNumber": "H134182",
        "OpenDate": "11/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1666",
        "TokenNumber": "H134183",
        "OpenDate": "11/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1667",
        "TokenNumber": "H134185",
        "OpenDate": "11/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "34",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1668",
        "TokenNumber": "H134186",
        "OpenDate": "11/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1669",
        "TokenNumber": "H134187",
        "OpenDate": "11/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1670",
        "TokenNumber": "H134188",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1671",
        "TokenNumber": "H134189",
        "OpenDate": "11/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1672",
        "TokenNumber": "H134193",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1673",
        "TokenNumber": "H134194",
        "OpenDate": "11/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1674",
        "TokenNumber": "H134196",
        "OpenDate": "11/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1675",
        "TokenNumber": "H134195",
        "OpenDate": "11/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1676",
        "TokenNumber": "H134199",
        "OpenDate": "11/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1677",
        "TokenNumber": "H134203",
        "OpenDate": "11/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "38",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1678",
        "TokenNumber": "H134204",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1679",
        "TokenNumber": "H134209",
        "OpenDate": "11/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1680",
        "TokenNumber": "H134210",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1681",
        "TokenNumber": "H134211",
        "OpenDate": "11/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1682",
        "TokenNumber": "H134213",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1683",
        "TokenNumber": "H134215",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1684",
        "TokenNumber": "H134216",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "36",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1685",
        "TokenNumber": "H134217",
        "OpenDate": "11/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1686",
        "TokenNumber": "H134219",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1687",
        "TokenNumber": "H134218",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1688",
        "TokenNumber": "H134221",
        "OpenDate": "11/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1689",
        "TokenNumber": "H134222",
        "OpenDate": "11/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1690",
        "TokenNumber": "H134223",
        "OpenDate": "11/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1691",
        "TokenNumber": "H134225",
        "OpenDate": "11/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1692",
        "TokenNumber": "H134228",
        "OpenDate": "11/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1693",
        "TokenNumber": "H134232",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1694",
        "TokenNumber": "H134233",
        "OpenDate": "11/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1695",
        "TokenNumber": "H134236",
        "OpenDate": "11/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1696",
        "TokenNumber": "H134237",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1697",
        "TokenNumber": "H134238",
        "OpenDate": "11/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1698",
        "TokenNumber": "H134240",
        "OpenDate": "11/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1699",
        "TokenNumber": "H134241",
        "OpenDate": "11/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1700",
        "TokenNumber": "H134242",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1701",
        "TokenNumber": "H134243",
        "OpenDate": "11/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "57",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1702",
        "TokenNumber": "H134244",
        "OpenDate": "11/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1703",
        "TokenNumber": "H134245",
        "OpenDate": "11/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1704",
        "TokenNumber": "H134246",
        "OpenDate": "11/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1705",
        "TokenNumber": "H134247",
        "OpenDate": "11/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1706",
        "TokenNumber": "H134250",
        "OpenDate": "12/02/2020",
        "CloseDate": "12/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1707",
        "TokenNumber": "H134252",
        "OpenDate": "12/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1708",
        "TokenNumber": "H134253",
        "OpenDate": "12/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1709",
        "TokenNumber": "H134255",
        "OpenDate": "12/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1710",
        "TokenNumber": "H134257",
        "OpenDate": "12/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "56",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1711",
        "TokenNumber": "H133771",
        "OpenDate": "12/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "19",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1712",
        "TokenNumber": "H134259",
        "OpenDate": "12/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "2",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1713",
        "TokenNumber": "H134260",
        "OpenDate": "12/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1714",
        "TokenNumber": "H134261",
        "OpenDate": "12/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1715",
        "TokenNumber": "H134262",
        "OpenDate": "12/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1716",
        "TokenNumber": "H134264",
        "OpenDate": "12/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1717",
        "TokenNumber": "H134266",
        "OpenDate": "12/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1718",
        "TokenNumber": "H134269",
        "OpenDate": "12/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1719",
        "TokenNumber": "H134270",
        "OpenDate": "12/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1720",
        "TokenNumber": "H134272",
        "OpenDate": "12/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1721",
        "TokenNumber": "H134275",
        "OpenDate": "12/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1722",
        "TokenNumber": "H134274",
        "OpenDate": "12/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1723",
        "TokenNumber": "H134280",
        "OpenDate": "12/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1724",
        "TokenNumber": "H134281",
        "OpenDate": "12/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "14",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1725",
        "TokenNumber": "H134282",
        "OpenDate": "12/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1726",
        "TokenNumber": "H134284",
        "OpenDate": "12/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1727",
        "TokenNumber": "H134285",
        "OpenDate": "12/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1728",
        "TokenNumber": "H134286",
        "OpenDate": "12/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "30",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1729",
        "TokenNumber": "H134289",
        "OpenDate": "12/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1730",
        "TokenNumber": "H134292",
        "OpenDate": "12/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1731",
        "TokenNumber": "H134293",
        "OpenDate": "12/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1732",
        "TokenNumber": "H134295",
        "OpenDate": "12/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1733",
        "TokenNumber": "H134299",
        "OpenDate": "12/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1734",
        "TokenNumber": "H134300",
        "OpenDate": "12/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1735",
        "TokenNumber": "H134302",
        "OpenDate": "12/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1736",
        "TokenNumber": "H134306",
        "OpenDate": "12/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1737",
        "TokenNumber": "H134308",
        "OpenDate": "12/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1739",
        "TokenNumber": "H134311",
        "OpenDate": "12/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1740",
        "TokenNumber": "H134313",
        "OpenDate": "12/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1741",
        "TokenNumber": "H134314",
        "OpenDate": "12/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1742",
        "TokenNumber": "H134316",
        "OpenDate": "12/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1743",
        "TokenNumber": "H134317",
        "OpenDate": "12/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1744",
        "TokenNumber": "H134318",
        "OpenDate": "12/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1745",
        "TokenNumber": "H134319",
        "OpenDate": "12/02/2020",
        "CloseDate": "13/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1746",
        "TokenNumber": "H134321",
        "OpenDate": "12/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "14",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1747",
        "TokenNumber": "H134323",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1748",
        "TokenNumber": "H134327",
        "OpenDate": "13/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1749",
        "TokenNumber": "H134328",
        "OpenDate": "13/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1750",
        "TokenNumber": "H134329",
        "OpenDate": "13/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "1",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1751",
        "TokenNumber": "H134330",
        "OpenDate": "13/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1752",
        "TokenNumber": "H134331",
        "OpenDate": "13/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1753",
        "TokenNumber": "H134332",
        "OpenDate": "13/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "13",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1754",
        "TokenNumber": "H134333",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1755",
        "TokenNumber": "H134335",
        "OpenDate": "13/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1756",
        "TokenNumber": "H134336",
        "OpenDate": "13/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "20",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1757",
        "TokenNumber": "H134337",
        "OpenDate": "13/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1758",
        "TokenNumber": "H134339",
        "OpenDate": "13/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "36",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1759",
        "TokenNumber": "H134341",
        "OpenDate": "13/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1760",
        "TokenNumber": "H134345",
        "OpenDate": "13/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1761",
        "TokenNumber": "H134346",
        "OpenDate": "13/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1762",
        "TokenNumber": "H134351",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1763",
        "TokenNumber": "H134352",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1764",
        "TokenNumber": "H134353",
        "OpenDate": "13/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "12",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1765",
        "TokenNumber": "H134354",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1766",
        "TokenNumber": "H134355",
        "OpenDate": "13/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1767",
        "TokenNumber": "H134357",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1768",
        "TokenNumber": "H134360",
        "OpenDate": "13/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1769",
        "TokenNumber": "H134362",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1770",
        "TokenNumber": "H134363",
        "OpenDate": "13/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "12",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1771",
        "TokenNumber": "H134361",
        "OpenDate": "13/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1772",
        "TokenNumber": "H134365",
        "OpenDate": "13/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1773",
        "TokenNumber": "H134366",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1774",
        "TokenNumber": "H134368",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1775",
        "TokenNumber": "H134369",
        "OpenDate": "13/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1776",
        "TokenNumber": "H134370",
        "OpenDate": "13/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1777",
        "TokenNumber": "H134371",
        "OpenDate": "13/02/2020",
        "CloseDate": "23/02/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1778",
        "TokenNumber": "H134372",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1779",
        "TokenNumber": "H134375",
        "OpenDate": "13/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1780",
        "TokenNumber": "H134377",
        "OpenDate": "13/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1781",
        "TokenNumber": "H134379",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1782",
        "TokenNumber": "H134380",
        "OpenDate": "13/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1783",
        "TokenNumber": "H134383",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1784",
        "TokenNumber": "H134385",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1785",
        "TokenNumber": "H134386",
        "OpenDate": "13/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "20",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1786",
        "TokenNumber": "H134387",
        "OpenDate": "13/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1787",
        "TokenNumber": "H134388",
        "OpenDate": "13/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1788",
        "TokenNumber": "H134389",
        "OpenDate": "13/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1789",
        "TokenNumber": "H134391",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1790",
        "TokenNumber": "H134392",
        "OpenDate": "13/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "32",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1791",
        "TokenNumber": "H134393",
        "OpenDate": "13/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1792",
        "TokenNumber": "H134394",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1793",
        "TokenNumber": "H134384",
        "OpenDate": "13/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1794",
        "TokenNumber": "H134397",
        "OpenDate": "14/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1795",
        "TokenNumber": "H134401",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1796",
        "TokenNumber": "H134402",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1797",
        "TokenNumber": "H134403",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1798",
        "TokenNumber": "H134404",
        "OpenDate": "14/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1799",
        "TokenNumber": "H134406",
        "OpenDate": "14/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "0",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1800",
        "TokenNumber": "H134408",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1801",
        "TokenNumber": "H134409",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1802",
        "TokenNumber": "H134410",
        "OpenDate": "14/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1803",
        "TokenNumber": "H134405",
        "OpenDate": "14/02/2020",
        "CloseDate": "14/02/2020",
        "CompletionTime": "0",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1804",
        "TokenNumber": "H134411",
        "OpenDate": "14/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1805",
        "TokenNumber": "H134415",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "33",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1806",
        "TokenNumber": "H134413",
        "OpenDate": "14/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1807",
        "TokenNumber": "H134416",
        "OpenDate": "14/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1808",
        "TokenNumber": "H134418",
        "OpenDate": "14/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1809",
        "TokenNumber": "H134420",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1810",
        "TokenNumber": "H134422",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1811",
        "TokenNumber": "H134425",
        "OpenDate": "14/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1812",
        "TokenNumber": "H134396",
        "OpenDate": "14/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "18",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1813",
        "TokenNumber": "H134426",
        "OpenDate": "14/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "12",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1814",
        "TokenNumber": "H134430",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1815",
        "TokenNumber": "H134431",
        "OpenDate": "14/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "54",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1816",
        "TokenNumber": "H134432",
        "OpenDate": "14/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "54",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1817",
        "TokenNumber": "H134434",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1818",
        "TokenNumber": "H134435",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1819",
        "TokenNumber": "H134436",
        "OpenDate": "14/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1820",
        "TokenNumber": "H134437",
        "OpenDate": "14/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1821",
        "TokenNumber": "H134439",
        "OpenDate": "14/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1822",
        "TokenNumber": "H134440",
        "OpenDate": "14/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1823",
        "TokenNumber": "H134442",
        "OpenDate": "14/02/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "61",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1824",
        "TokenNumber": "H134443",
        "OpenDate": "14/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1825",
        "TokenNumber": "H134444",
        "OpenDate": "14/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "11",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1826",
        "TokenNumber": "H134445",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1827",
        "TokenNumber": "H134446",
        "OpenDate": "14/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1828",
        "TokenNumber": "H134447",
        "OpenDate": "14/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1829",
        "TokenNumber": "H134448",
        "OpenDate": "14/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1830",
        "TokenNumber": "H134452",
        "OpenDate": "14/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1831",
        "TokenNumber": "H134453",
        "OpenDate": "14/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1832",
        "TokenNumber": "H134456",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1833",
        "TokenNumber": "H134457",
        "OpenDate": "14/02/2020",
        "CloseDate": "15/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1834",
        "TokenNumber": "H134458",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1835",
        "TokenNumber": "H134459",
        "OpenDate": "14/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1836",
        "TokenNumber": "H134460",
        "OpenDate": "14/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1837",
        "TokenNumber": "H134461",
        "OpenDate": "14/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1838",
        "TokenNumber": "H134462",
        "OpenDate": "14/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "11",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1839",
        "TokenNumber": "H134464",
        "OpenDate": "14/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1840",
        "TokenNumber": "H134466",
        "OpenDate": "14/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "33",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1841",
        "TokenNumber": "H134467",
        "OpenDate": "14/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1842",
        "TokenNumber": "H134469",
        "OpenDate": "14/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "26",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1843",
        "TokenNumber": "H134470",
        "OpenDate": "15/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1844",
        "TokenNumber": "H134471",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1845",
        "TokenNumber": "H134473",
        "OpenDate": "15/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "44",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1846",
        "TokenNumber": "H134475",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1847",
        "TokenNumber": "H134476",
        "OpenDate": "15/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "2",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1848",
        "TokenNumber": "H134478",
        "OpenDate": "15/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1849",
        "TokenNumber": "H134477",
        "OpenDate": "15/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1850",
        "TokenNumber": "H134479",
        "OpenDate": "15/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1851",
        "TokenNumber": "H134480",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1852",
        "TokenNumber": "H134472",
        "OpenDate": "15/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1853",
        "TokenNumber": "H134481",
        "OpenDate": "15/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1854",
        "TokenNumber": "H134486",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "32",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1855",
        "TokenNumber": "H134487",
        "OpenDate": "15/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "31",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1856",
        "TokenNumber": "H134485",
        "OpenDate": "15/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1857",
        "TokenNumber": "H134488",
        "OpenDate": "15/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1858",
        "TokenNumber": "H134489",
        "OpenDate": "15/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1859",
        "TokenNumber": "H134490",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "3",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1860",
        "TokenNumber": "H134493",
        "OpenDate": "15/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1861",
        "TokenNumber": "H134498",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1862",
        "TokenNumber": "H134502",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "32",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1863",
        "TokenNumber": "H134503",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1864",
        "TokenNumber": "H134506",
        "OpenDate": "15/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1865",
        "TokenNumber": "H134507",
        "OpenDate": "15/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "11",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1866",
        "TokenNumber": "H134513",
        "OpenDate": "15/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "53",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1867",
        "TokenNumber": "H134514",
        "OpenDate": "15/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "25",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1868",
        "TokenNumber": "H134515",
        "OpenDate": "15/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1869",
        "TokenNumber": "H134517",
        "OpenDate": "15/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1870",
        "TokenNumber": "H134519",
        "OpenDate": "15/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1871",
        "TokenNumber": "H134520",
        "OpenDate": "15/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1872",
        "TokenNumber": "H134521",
        "OpenDate": "15/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1873",
        "TokenNumber": "H134522",
        "OpenDate": "16/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1874",
        "TokenNumber": "H134510",
        "OpenDate": "16/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1875",
        "TokenNumber": "H134524",
        "OpenDate": "16/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1876",
        "TokenNumber": "H134525",
        "OpenDate": "16/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1877",
        "TokenNumber": "H134526",
        "OpenDate": "16/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1878",
        "TokenNumber": "H134528",
        "OpenDate": "16/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1879",
        "TokenNumber": "H134530",
        "OpenDate": "16/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1880",
        "TokenNumber": "H134531",
        "OpenDate": "16/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1881",
        "TokenNumber": "H134533",
        "OpenDate": "16/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1882",
        "TokenNumber": "H134535",
        "OpenDate": "16/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1883",
        "TokenNumber": "H134536",
        "OpenDate": "16/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "9",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1884",
        "TokenNumber": "H134538",
        "OpenDate": "16/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1885",
        "TokenNumber": "H134544",
        "OpenDate": "16/02/2020",
        "CloseDate": "23/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1886",
        "TokenNumber": "H134547",
        "OpenDate": "16/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1887",
        "TokenNumber": "H134550",
        "OpenDate": "16/02/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "39",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1888",
        "TokenNumber": "H134552",
        "OpenDate": "16/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1889",
        "TokenNumber": "H134553",
        "OpenDate": "16/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1890",
        "TokenNumber": "H134501",
        "OpenDate": "16/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1891",
        "TokenNumber": "H134554",
        "OpenDate": "16/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1892",
        "TokenNumber": "H134555",
        "OpenDate": "16/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1893",
        "TokenNumber": "H134556",
        "OpenDate": "16/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1894",
        "TokenNumber": "H134558",
        "OpenDate": "16/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1895",
        "TokenNumber": "H134562",
        "OpenDate": "16/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1896",
        "TokenNumber": "H134565",
        "OpenDate": "16/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1897",
        "TokenNumber": "H134568",
        "OpenDate": "16/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1898",
        "TokenNumber": "H134569",
        "OpenDate": "16/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1899",
        "TokenNumber": "H134570",
        "OpenDate": "16/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1900",
        "TokenNumber": "H134571",
        "OpenDate": "16/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "52",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1901",
        "TokenNumber": "H134572",
        "OpenDate": "16/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1902",
        "TokenNumber": "H134576",
        "OpenDate": "16/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1903",
        "TokenNumber": "H134577",
        "OpenDate": "16/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1904",
        "TokenNumber": "H134578",
        "OpenDate": "16/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1905",
        "TokenNumber": "H133070",
        "OpenDate": "16/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "52",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1906",
        "TokenNumber": "H134579",
        "OpenDate": "16/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1907",
        "TokenNumber": "H134582",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1908",
        "TokenNumber": "H134583",
        "OpenDate": "17/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1909",
        "TokenNumber": "H134584",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1910",
        "TokenNumber": "H134585",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1911",
        "TokenNumber": "H134589",
        "OpenDate": "17/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1912",
        "TokenNumber": "H134588",
        "OpenDate": "17/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "0",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1913",
        "TokenNumber": "H134590",
        "OpenDate": "17/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1914",
        "TokenNumber": "H134592",
        "OpenDate": "17/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1915",
        "TokenNumber": "H134593",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1916",
        "TokenNumber": "H134594",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1917",
        "TokenNumber": "H134596",
        "OpenDate": "17/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1918",
        "TokenNumber": "H134595",
        "OpenDate": "17/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1919",
        "TokenNumber": "H134597",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1920",
        "TokenNumber": "H134599",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1921",
        "TokenNumber": "H134600",
        "OpenDate": "17/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1922",
        "TokenNumber": "H134602",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1923",
        "TokenNumber": "H134601",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1924",
        "TokenNumber": "H134603",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1925",
        "TokenNumber": "H134605",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1926",
        "TokenNumber": "H134607",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1927",
        "TokenNumber": "H134608",
        "OpenDate": "17/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1928",
        "TokenNumber": "H134609",
        "OpenDate": "17/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1929",
        "TokenNumber": "H134610",
        "OpenDate": "17/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "16",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1930",
        "TokenNumber": "H134611",
        "OpenDate": "17/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1931",
        "TokenNumber": "H134613",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1932",
        "TokenNumber": "H134612",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1933",
        "TokenNumber": "H134614",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1934",
        "TokenNumber": "H134615",
        "OpenDate": "17/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1935",
        "TokenNumber": "H134617",
        "OpenDate": "17/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1936",
        "TokenNumber": "H134622",
        "OpenDate": "17/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "50",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1937",
        "TokenNumber": "H134625",
        "OpenDate": "17/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1938",
        "TokenNumber": "H134628",
        "OpenDate": "17/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1939",
        "TokenNumber": "H134630",
        "OpenDate": "17/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1940",
        "TokenNumber": "H134631",
        "OpenDate": "17/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1941",
        "TokenNumber": "H134632",
        "OpenDate": "17/02/2020",
        "CloseDate": "17/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1942",
        "TokenNumber": "H134635",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1943",
        "TokenNumber": "H134637",
        "OpenDate": "17/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1944",
        "TokenNumber": "H134638",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1945",
        "TokenNumber": "H134640",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1946",
        "TokenNumber": "H134641",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1947",
        "TokenNumber": "H134642",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1948",
        "TokenNumber": "H134643",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1949",
        "TokenNumber": "H134645",
        "OpenDate": "17/02/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "58",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1950",
        "TokenNumber": "H134646",
        "OpenDate": "17/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1951",
        "TokenNumber": "H134647",
        "OpenDate": "17/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1952",
        "TokenNumber": "H134650",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1953",
        "TokenNumber": "H134652",
        "OpenDate": "17/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1955",
        "TokenNumber": "H134654",
        "OpenDate": "17/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1956",
        "TokenNumber": "H134655",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1957",
        "TokenNumber": "H134656",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1958",
        "TokenNumber": "H134657",
        "OpenDate": "17/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1959",
        "TokenNumber": "H134658",
        "OpenDate": "17/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1960",
        "TokenNumber": "H134659",
        "OpenDate": "17/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1961",
        "TokenNumber": "H134660",
        "OpenDate": "17/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "51",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1962",
        "TokenNumber": "H134662",
        "OpenDate": "17/02/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1963",
        "TokenNumber": "H134663",
        "OpenDate": "17/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "11",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1964",
        "TokenNumber": "H134665",
        "OpenDate": "17/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1965",
        "TokenNumber": "H134667",
        "OpenDate": "18/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1966",
        "TokenNumber": "H134668",
        "OpenDate": "18/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1967",
        "TokenNumber": "H134666",
        "OpenDate": "18/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "27",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1968",
        "TokenNumber": "H134670",
        "OpenDate": "18/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1969",
        "TokenNumber": "H134671",
        "OpenDate": "18/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1970",
        "TokenNumber": "H134673",
        "OpenDate": "18/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1971",
        "TokenNumber": "H134679",
        "OpenDate": "18/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1972",
        "TokenNumber": "H134680",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1973",
        "TokenNumber": "H134683",
        "OpenDate": "18/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "13",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1974",
        "TokenNumber": "H134684",
        "OpenDate": "18/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1975",
        "TokenNumber": "H134687",
        "OpenDate": "18/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "50",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1976",
        "TokenNumber": "H134686",
        "OpenDate": "18/02/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "57",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1977",
        "TokenNumber": "H134690",
        "OpenDate": "18/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "55",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1978",
        "TokenNumber": "H134691",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1979",
        "TokenNumber": "H134692",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1981",
        "TokenNumber": "H134695",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1983",
        "TokenNumber": "H134698",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1984",
        "TokenNumber": "H134699",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1985",
        "TokenNumber": "H134703",
        "OpenDate": "18/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1987",
        "TokenNumber": "H134704",
        "OpenDate": "18/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1988",
        "TokenNumber": "H134705",
        "OpenDate": "18/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1989",
        "TokenNumber": "H134702",
        "OpenDate": "18/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1990",
        "TokenNumber": "H134706",
        "OpenDate": "18/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1991",
        "TokenNumber": "H134707",
        "OpenDate": "18/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1992",
        "TokenNumber": "H134708",
        "OpenDate": "18/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1993",
        "TokenNumber": "H134709",
        "OpenDate": "18/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1994",
        "TokenNumber": "H134712",
        "OpenDate": "18/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "50",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1995",
        "TokenNumber": "H134714",
        "OpenDate": "18/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1996",
        "TokenNumber": "H134717",
        "OpenDate": "18/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1997",
        "TokenNumber": "H134719",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1998",
        "TokenNumber": "H134720",
        "OpenDate": "18/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "1999",
        "TokenNumber": "H134722",
        "OpenDate": "18/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2000",
        "TokenNumber": "H134724",
        "OpenDate": "18/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2001",
        "TokenNumber": "H134725",
        "OpenDate": "18/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2002",
        "TokenNumber": "H134726",
        "OpenDate": "18/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2003",
        "TokenNumber": "H134727",
        "OpenDate": "18/02/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "64",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2004",
        "TokenNumber": "H134728",
        "OpenDate": "18/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2005",
        "TokenNumber": "H134730",
        "OpenDate": "18/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "41",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2006",
        "TokenNumber": "H134731",
        "OpenDate": "18/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2007",
        "TokenNumber": "H134732",
        "OpenDate": "18/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2008",
        "TokenNumber": "H134733",
        "OpenDate": "18/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "30",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2009",
        "TokenNumber": "H134734",
        "OpenDate": "18/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2010",
        "TokenNumber": "H134737",
        "OpenDate": "19/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2011",
        "TokenNumber": "H134740",
        "OpenDate": "19/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2012",
        "TokenNumber": "H134738",
        "OpenDate": "19/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2013",
        "TokenNumber": "H134741",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2014",
        "TokenNumber": "H134711",
        "OpenDate": "19/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "21",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2015",
        "TokenNumber": "H134743",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2016",
        "TokenNumber": "H134744",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2017",
        "TokenNumber": "H134745",
        "OpenDate": "19/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2018",
        "TokenNumber": "H134747",
        "OpenDate": "19/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2019",
        "TokenNumber": "H134750",
        "OpenDate": "19/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "26",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2020",
        "TokenNumber": "H134752",
        "OpenDate": "19/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2021",
        "TokenNumber": "H134753",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2022",
        "TokenNumber": "H134757",
        "OpenDate": "19/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2023",
        "TokenNumber": "H134755",
        "OpenDate": "19/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2024",
        "TokenNumber": "H134756",
        "OpenDate": "19/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2025",
        "TokenNumber": "H134766",
        "OpenDate": "19/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2026",
        "TokenNumber": "H134767",
        "OpenDate": "19/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2027",
        "TokenNumber": "H134768",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2028",
        "TokenNumber": "H134769",
        "OpenDate": "19/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2029",
        "TokenNumber": "H134771",
        "OpenDate": "19/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2030",
        "TokenNumber": "H134773",
        "OpenDate": "19/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2032",
        "TokenNumber": "H134781",
        "OpenDate": "19/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "28",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2033",
        "TokenNumber": "H134783",
        "OpenDate": "19/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2034",
        "TokenNumber": "H134784",
        "OpenDate": "19/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2035",
        "TokenNumber": "H134787",
        "OpenDate": "19/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "21",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2036",
        "TokenNumber": "H134788",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2037",
        "TokenNumber": "H134789",
        "OpenDate": "19/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2038",
        "TokenNumber": "H134790",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2039",
        "TokenNumber": "H134791",
        "OpenDate": "19/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "28",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2040",
        "TokenNumber": "H134793",
        "OpenDate": "19/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2041",
        "TokenNumber": "H134794",
        "OpenDate": "19/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2042",
        "TokenNumber": "H134796",
        "OpenDate": "20/02/2020",
        "CloseDate": "20/02/2020",
        "CompletionTime": "0",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2043",
        "TokenNumber": "H134797",
        "OpenDate": "20/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "6",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2044",
        "TokenNumber": "H134798",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2045",
        "TokenNumber": "H134799",
        "OpenDate": "20/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "8",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2046",
        "TokenNumber": "H134802",
        "OpenDate": "20/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2047",
        "TokenNumber": "H134803",
        "OpenDate": "20/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2048",
        "TokenNumber": "H134804",
        "OpenDate": "20/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2049",
        "TokenNumber": "H134805",
        "OpenDate": "20/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2050",
        "TokenNumber": "H134807",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2051",
        "TokenNumber": "H134809",
        "OpenDate": "20/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2052",
        "TokenNumber": "H134810",
        "OpenDate": "20/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2053",
        "TokenNumber": "H134813",
        "OpenDate": "20/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2054",
        "TokenNumber": "H134801",
        "OpenDate": "20/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2055",
        "TokenNumber": "H134792",
        "OpenDate": "20/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "6",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2056",
        "TokenNumber": "H134818",
        "OpenDate": "20/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "48",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2057",
        "TokenNumber": "H134817",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2058",
        "TokenNumber": "H134820",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2059",
        "TokenNumber": "H134821",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2060",
        "TokenNumber": "H134823",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2061",
        "TokenNumber": "H134824",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2062",
        "TokenNumber": "H134826",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2063",
        "TokenNumber": "H134829",
        "OpenDate": "20/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "13",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2064",
        "TokenNumber": "H134830",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2065",
        "TokenNumber": "H134832",
        "OpenDate": "20/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2066",
        "TokenNumber": "H134834",
        "OpenDate": "20/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2067",
        "TokenNumber": "H134835",
        "OpenDate": "20/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2068",
        "TokenNumber": "H134836",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2069",
        "TokenNumber": "H134837",
        "OpenDate": "20/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2070",
        "TokenNumber": "H134838",
        "OpenDate": "20/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2071",
        "TokenNumber": "H134839",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2072",
        "TokenNumber": "H134841",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2073",
        "TokenNumber": "H134842",
        "OpenDate": "20/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2074",
        "TokenNumber": "H134843",
        "OpenDate": "20/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2075",
        "TokenNumber": "H134844",
        "OpenDate": "20/02/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "21",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2076",
        "TokenNumber": "H134845",
        "OpenDate": "20/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2077",
        "TokenNumber": "H134846",
        "OpenDate": "20/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2078",
        "TokenNumber": "H134847",
        "OpenDate": "20/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "53",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2079",
        "TokenNumber": "H134851",
        "OpenDate": "20/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2080",
        "TokenNumber": "H134850",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2081",
        "TokenNumber": "H134853",
        "OpenDate": "20/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "27",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2082",
        "TokenNumber": "H134855",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2083",
        "TokenNumber": "H134857",
        "OpenDate": "20/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2084",
        "TokenNumber": "H134856",
        "OpenDate": "20/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2085",
        "TokenNumber": "H134859",
        "OpenDate": "20/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2086",
        "TokenNumber": "H134860",
        "OpenDate": "20/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2087",
        "TokenNumber": "H134861",
        "OpenDate": "20/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2088",
        "TokenNumber": "H134862",
        "OpenDate": "20/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2089",
        "TokenNumber": "H134863",
        "OpenDate": "20/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "47",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2090",
        "TokenNumber": "H134307",
        "OpenDate": "20/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "14",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2091",
        "TokenNumber": "H134864",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2092",
        "TokenNumber": "H134865",
        "OpenDate": "20/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2093",
        "TokenNumber": "H134868",
        "OpenDate": "21/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2094",
        "TokenNumber": "H134869",
        "OpenDate": "21/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "3",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2095",
        "TokenNumber": "H134873",
        "OpenDate": "21/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2096",
        "TokenNumber": "H134874",
        "OpenDate": "21/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2097",
        "TokenNumber": "H134875",
        "OpenDate": "21/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "10",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2098",
        "TokenNumber": "H134876",
        "OpenDate": "21/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "19",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2099",
        "TokenNumber": "H134877",
        "OpenDate": "21/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "38",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2100",
        "TokenNumber": "H134878",
        "OpenDate": "21/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "5",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2101",
        "TokenNumber": "H134879",
        "OpenDate": "21/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2102",
        "TokenNumber": "H134880",
        "OpenDate": "21/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2103",
        "TokenNumber": "H134881",
        "OpenDate": "21/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2104",
        "TokenNumber": "H134882",
        "OpenDate": "21/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2105",
        "TokenNumber": "H134883",
        "OpenDate": "21/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2106",
        "TokenNumber": "H134884",
        "OpenDate": "21/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2107",
        "TokenNumber": "H134887",
        "OpenDate": "21/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2108",
        "TokenNumber": "H134889",
        "OpenDate": "21/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2109",
        "TokenNumber": "H134888",
        "OpenDate": "21/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2110",
        "TokenNumber": "H134890",
        "OpenDate": "21/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2111",
        "TokenNumber": "H134891",
        "OpenDate": "21/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2112",
        "TokenNumber": "H134893",
        "OpenDate": "21/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2113",
        "TokenNumber": "H134895",
        "OpenDate": "21/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2114",
        "TokenNumber": "H134896",
        "OpenDate": "21/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2115",
        "TokenNumber": "H134900",
        "OpenDate": "21/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2116",
        "TokenNumber": "H134899",
        "OpenDate": "21/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2117",
        "TokenNumber": "H134902",
        "OpenDate": "21/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2118",
        "TokenNumber": "H134903",
        "OpenDate": "21/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "47",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2120",
        "TokenNumber": "H134905",
        "OpenDate": "21/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2121",
        "TokenNumber": "H134906",
        "OpenDate": "21/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2122",
        "TokenNumber": "H134907",
        "OpenDate": "21/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2123",
        "TokenNumber": "H134908",
        "OpenDate": "21/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2124",
        "TokenNumber": "H134912",
        "OpenDate": "21/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2125",
        "TokenNumber": "H134916",
        "OpenDate": "21/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2126",
        "TokenNumber": "H134917",
        "OpenDate": "21/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2127",
        "TokenNumber": "H134919",
        "OpenDate": "21/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2128",
        "TokenNumber": "H134920",
        "OpenDate": "21/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2129",
        "TokenNumber": "H134923",
        "OpenDate": "21/02/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "54",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2130",
        "TokenNumber": "H134925",
        "OpenDate": "22/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2131",
        "TokenNumber": "H134926",
        "OpenDate": "22/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2132",
        "TokenNumber": "H134927",
        "OpenDate": "22/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2133",
        "TokenNumber": "H134932",
        "OpenDate": "22/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2134",
        "TokenNumber": "H134933",
        "OpenDate": "22/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "18",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2135",
        "TokenNumber": "H134935",
        "OpenDate": "22/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2136",
        "TokenNumber": "H134936",
        "OpenDate": "22/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "45",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2137",
        "TokenNumber": "H134937",
        "OpenDate": "22/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2139",
        "TokenNumber": "H134943",
        "OpenDate": "22/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2140",
        "TokenNumber": "H134946",
        "OpenDate": "22/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "10",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2141",
        "TokenNumber": "H134945",
        "OpenDate": "22/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2142",
        "TokenNumber": "H134947",
        "OpenDate": "22/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "46",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2143",
        "TokenNumber": "H134949",
        "OpenDate": "22/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2144",
        "TokenNumber": "H134951",
        "OpenDate": "22/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2146",
        "TokenNumber": "H134954",
        "OpenDate": "22/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2147",
        "TokenNumber": "H134957",
        "OpenDate": "22/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2148",
        "TokenNumber": "H134959",
        "OpenDate": "22/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2149",
        "TokenNumber": "H134960",
        "OpenDate": "22/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2150",
        "TokenNumber": "H134961",
        "OpenDate": "22/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2151",
        "TokenNumber": "H134963",
        "OpenDate": "22/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2152",
        "TokenNumber": "H134956",
        "OpenDate": "22/02/2020",
        "CloseDate": "14/04/2020",
        "CompletionTime": "52",
        "Subject": "Peving Block",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "2153",
        "TokenNumber": "H134965",
        "OpenDate": "22/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2154",
        "TokenNumber": "H134967",
        "OpenDate": "22/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "46",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2155",
        "TokenNumber": "H134971",
        "OpenDate": "22/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2156",
        "TokenNumber": "H134973",
        "OpenDate": "22/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2157",
        "TokenNumber": "H134974",
        "OpenDate": "22/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2158",
        "TokenNumber": "H134975",
        "OpenDate": "22/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2159",
        "TokenNumber": "H134976",
        "OpenDate": "22/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "26",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2160",
        "TokenNumber": "H134977",
        "OpenDate": "22/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2161",
        "TokenNumber": "H134978",
        "OpenDate": "22/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2162",
        "TokenNumber": "H134980",
        "OpenDate": "22/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "6",
        "Subject": "Unauthorised Construction",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "2163",
        "TokenNumber": "H134979",
        "OpenDate": "22/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2164",
        "TokenNumber": "H134983",
        "OpenDate": "22/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2165",
        "TokenNumber": "H134982",
        "OpenDate": "22/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2166",
        "TokenNumber": "H134985",
        "OpenDate": "22/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2167",
        "TokenNumber": "H134988",
        "OpenDate": "22/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2168",
        "TokenNumber": "H134989",
        "OpenDate": "22/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2169",
        "TokenNumber": "H134991",
        "OpenDate": "22/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2170",
        "TokenNumber": "H134992",
        "OpenDate": "22/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2171",
        "TokenNumber": "H134993",
        "OpenDate": "22/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2172",
        "TokenNumber": "H134994",
        "OpenDate": "22/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "6",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2173",
        "TokenNumber": "H134995",
        "OpenDate": "22/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2174",
        "TokenNumber": "H134996",
        "OpenDate": "22/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2175",
        "TokenNumber": "H134997",
        "OpenDate": "22/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2176",
        "TokenNumber": "H134998",
        "OpenDate": "22/02/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "59",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2177",
        "TokenNumber": "H134999",
        "OpenDate": "22/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "18",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2178",
        "TokenNumber": "H135000",
        "OpenDate": "22/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2179",
        "TokenNumber": "H135002",
        "OpenDate": "22/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2180",
        "TokenNumber": "H135004",
        "OpenDate": "22/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2181",
        "TokenNumber": "H135005",
        "OpenDate": "22/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2182",
        "TokenNumber": "H135006",
        "OpenDate": "23/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "44",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2183",
        "TokenNumber": "H135007",
        "OpenDate": "23/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2184",
        "TokenNumber": "H135008",
        "OpenDate": "23/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2185",
        "TokenNumber": "H135009",
        "OpenDate": "23/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2186",
        "TokenNumber": "H135017",
        "OpenDate": "23/02/2020",
        "CloseDate": "23/02/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2187",
        "TokenNumber": "H135021",
        "OpenDate": "23/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2188",
        "TokenNumber": "H135024",
        "OpenDate": "23/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "8",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2189",
        "TokenNumber": "H135025",
        "OpenDate": "23/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2190",
        "TokenNumber": "H135026",
        "OpenDate": "23/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2191",
        "TokenNumber": "H135019",
        "OpenDate": "23/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2192",
        "TokenNumber": "H135029",
        "OpenDate": "23/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2195",
        "TokenNumber": "H135032",
        "OpenDate": "23/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2196",
        "TokenNumber": "H135033",
        "OpenDate": "23/02/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2197",
        "TokenNumber": "H135035",
        "OpenDate": "23/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2198",
        "TokenNumber": "H135036",
        "OpenDate": "23/02/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2200",
        "TokenNumber": "H135039",
        "OpenDate": "23/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "11",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2201",
        "TokenNumber": "H135040",
        "OpenDate": "23/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2202",
        "TokenNumber": "H135043",
        "OpenDate": "23/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "22",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2203",
        "TokenNumber": "H135044",
        "OpenDate": "23/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2204",
        "TokenNumber": "H135045",
        "OpenDate": "23/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2205",
        "TokenNumber": "H135046",
        "OpenDate": "23/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2206",
        "TokenNumber": "H135048",
        "OpenDate": "23/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2207",
        "TokenNumber": "H135049",
        "OpenDate": "23/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2208",
        "TokenNumber": "H135051",
        "OpenDate": "23/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2209",
        "TokenNumber": "H135053",
        "OpenDate": "23/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "45",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2210",
        "TokenNumber": "H135052",
        "OpenDate": "23/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2211",
        "TokenNumber": "H135055",
        "OpenDate": "23/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "17",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2212",
        "TokenNumber": "H135056",
        "OpenDate": "23/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2213",
        "TokenNumber": "H135057",
        "OpenDate": "23/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "44",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2214",
        "TokenNumber": "H135062",
        "OpenDate": "24/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2215",
        "TokenNumber": "H135061",
        "OpenDate": "24/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2216",
        "TokenNumber": "H135060",
        "OpenDate": "24/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2217",
        "TokenNumber": "H135066",
        "OpenDate": "24/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "44",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2218",
        "TokenNumber": "H135064",
        "OpenDate": "24/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2219",
        "TokenNumber": "H135065",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2220",
        "TokenNumber": "H135068",
        "OpenDate": "24/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2221",
        "TokenNumber": "H135070",
        "OpenDate": "24/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "2",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2222",
        "TokenNumber": "H135071",
        "OpenDate": "24/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2223",
        "TokenNumber": "H135072",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2224",
        "TokenNumber": "H135073",
        "OpenDate": "24/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2225",
        "TokenNumber": "H135074",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2226",
        "TokenNumber": "H135075",
        "OpenDate": "24/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2227",
        "TokenNumber": "H135076",
        "OpenDate": "24/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "49",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2229",
        "TokenNumber": "H135077",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2230",
        "TokenNumber": "H135079",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2231",
        "TokenNumber": "H135080",
        "OpenDate": "24/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2232",
        "TokenNumber": "H135081",
        "OpenDate": "24/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2233",
        "TokenNumber": "H135082",
        "OpenDate": "24/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2234",
        "TokenNumber": "H135084",
        "OpenDate": "24/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2235",
        "TokenNumber": "H135083",
        "OpenDate": "24/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2236",
        "TokenNumber": "H135086",
        "OpenDate": "24/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2237",
        "TokenNumber": "H135087",
        "OpenDate": "24/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2238",
        "TokenNumber": "H135091",
        "OpenDate": "24/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2240",
        "TokenNumber": "H135093",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2241",
        "TokenNumber": "H135094",
        "OpenDate": "24/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "44",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2242",
        "TokenNumber": "H135095",
        "OpenDate": "24/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2243",
        "TokenNumber": "H135096",
        "OpenDate": "24/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "43",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2244",
        "TokenNumber": "H135097",
        "OpenDate": "24/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2245",
        "TokenNumber": "H135098",
        "OpenDate": "24/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "23",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2246",
        "TokenNumber": "H135099",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2247",
        "TokenNumber": "H135100",
        "OpenDate": "24/02/2020",
        "CloseDate": "24/02/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2248",
        "TokenNumber": "H135104",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2249",
        "TokenNumber": "H135102",
        "OpenDate": "24/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "43",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2250",
        "TokenNumber": "H135103",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2251",
        "TokenNumber": "H135107",
        "OpenDate": "24/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "49",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2252",
        "TokenNumber": "H135108",
        "OpenDate": "24/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2253",
        "TokenNumber": "H135109",
        "OpenDate": "24/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2254",
        "TokenNumber": "H135110",
        "OpenDate": "24/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "49",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2255",
        "TokenNumber": "H135112",
        "OpenDate": "24/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "14",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2256",
        "TokenNumber": "H135113",
        "OpenDate": "24/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2257",
        "TokenNumber": "H135114",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2258",
        "TokenNumber": "H135115",
        "OpenDate": "24/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2259",
        "TokenNumber": "H135116",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2260",
        "TokenNumber": "H135117",
        "OpenDate": "24/02/2020",
        "CloseDate": "25/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2261",
        "TokenNumber": "H135120",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2262",
        "TokenNumber": "H135121",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2263",
        "TokenNumber": "H135122",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2264",
        "TokenNumber": "H135125",
        "OpenDate": "24/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "43",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2265",
        "TokenNumber": "H135128",
        "OpenDate": "24/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2266",
        "TokenNumber": "H135131",
        "OpenDate": "24/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2267",
        "TokenNumber": "H135133",
        "OpenDate": "24/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2268",
        "TokenNumber": "H135134",
        "OpenDate": "25/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2269",
        "TokenNumber": "H135135",
        "OpenDate": "25/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2270",
        "TokenNumber": "H135137",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2271",
        "TokenNumber": "H135140",
        "OpenDate": "25/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2272",
        "TokenNumber": "H135139",
        "OpenDate": "25/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2273",
        "TokenNumber": "H135142",
        "OpenDate": "25/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2274",
        "TokenNumber": "H135143",
        "OpenDate": "25/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2275",
        "TokenNumber": "H135144",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2276",
        "TokenNumber": "H135148",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2278",
        "TokenNumber": "H135153",
        "OpenDate": "25/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2279",
        "TokenNumber": "H135152",
        "OpenDate": "25/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2280",
        "TokenNumber": "H135151",
        "OpenDate": "25/02/2020",
        "CloseDate": "26/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2281",
        "TokenNumber": "H135154",
        "OpenDate": "25/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "21",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2282",
        "TokenNumber": "H135155",
        "OpenDate": "25/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2283",
        "TokenNumber": "H135158",
        "OpenDate": "25/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2284",
        "TokenNumber": "H135160",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2285",
        "TokenNumber": "H135163",
        "OpenDate": "25/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2286",
        "TokenNumber": "H135162",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2287",
        "TokenNumber": "H135165",
        "OpenDate": "25/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2288",
        "TokenNumber": "H135164",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2289",
        "TokenNumber": "H135166",
        "OpenDate": "25/02/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "28",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2290",
        "TokenNumber": "H135167",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2291",
        "TokenNumber": "H135169",
        "OpenDate": "25/02/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "38",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2292",
        "TokenNumber": "H135171",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2293",
        "TokenNumber": "H135172",
        "OpenDate": "25/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "2",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2294",
        "TokenNumber": "H135173",
        "OpenDate": "25/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2295",
        "TokenNumber": "H135177",
        "OpenDate": "25/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2296",
        "TokenNumber": "H135179",
        "OpenDate": "25/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "43",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2297",
        "TokenNumber": "H135176",
        "OpenDate": "25/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2298",
        "TokenNumber": "H135181",
        "OpenDate": "25/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "21",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2299",
        "TokenNumber": "H135182",
        "OpenDate": "25/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2300",
        "TokenNumber": "H135184",
        "OpenDate": "25/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2301",
        "TokenNumber": "H135185",
        "OpenDate": "25/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2302",
        "TokenNumber": "H135186",
        "OpenDate": "25/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2303",
        "TokenNumber": "H135189",
        "OpenDate": "25/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "43",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2305",
        "TokenNumber": "H135192",
        "OpenDate": "25/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2306",
        "TokenNumber": "H135195",
        "OpenDate": "25/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "48",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2307",
        "TokenNumber": "H135194",
        "OpenDate": "25/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2308",
        "TokenNumber": "H135196",
        "OpenDate": "25/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2309",
        "TokenNumber": "H135200",
        "OpenDate": "25/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2310",
        "TokenNumber": "H135201",
        "OpenDate": "25/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2311",
        "TokenNumber": "H135203",
        "OpenDate": "25/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2312",
        "TokenNumber": "H135204",
        "OpenDate": "25/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2313",
        "TokenNumber": "H135205",
        "OpenDate": "25/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2314",
        "TokenNumber": "H135206",
        "OpenDate": "25/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2315",
        "TokenNumber": "H135207",
        "OpenDate": "25/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2316",
        "TokenNumber": "H135208",
        "OpenDate": "25/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "17",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2317",
        "TokenNumber": "H135211",
        "OpenDate": "25/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2318",
        "TokenNumber": "H135212",
        "OpenDate": "25/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2319",
        "TokenNumber": "H135209",
        "OpenDate": "26/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2320",
        "TokenNumber": "H135214",
        "OpenDate": "26/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2321",
        "TokenNumber": "H135215",
        "OpenDate": "26/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2322",
        "TokenNumber": "H135216",
        "OpenDate": "26/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2323",
        "TokenNumber": "H135217",
        "OpenDate": "26/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2324",
        "TokenNumber": "H135219",
        "OpenDate": "26/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "21",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2325",
        "TokenNumber": "H135218",
        "OpenDate": "26/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2326",
        "TokenNumber": "H135220",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2327",
        "TokenNumber": "H135221",
        "OpenDate": "26/02/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "43",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2328",
        "TokenNumber": "H135228",
        "OpenDate": "26/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "42",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2329",
        "TokenNumber": "H135224",
        "OpenDate": "26/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2330",
        "TokenNumber": "H135225",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2331",
        "TokenNumber": "H135226",
        "OpenDate": "26/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2332",
        "TokenNumber": "H135229",
        "OpenDate": "26/02/2020",
        "CloseDate": "01/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2333",
        "TokenNumber": "H135230",
        "OpenDate": "26/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2334",
        "TokenNumber": "H135233",
        "OpenDate": "26/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2335",
        "TokenNumber": "H135234",
        "OpenDate": "26/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2336",
        "TokenNumber": "H135236",
        "OpenDate": "26/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2337",
        "TokenNumber": "H135237",
        "OpenDate": "26/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2338",
        "TokenNumber": "H135238",
        "OpenDate": "26/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2339",
        "TokenNumber": "H135239",
        "OpenDate": "26/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "41",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2340",
        "TokenNumber": "H135240",
        "OpenDate": "26/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2341",
        "TokenNumber": "H135242",
        "OpenDate": "26/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2343",
        "TokenNumber": "H135244",
        "OpenDate": "26/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2344",
        "TokenNumber": "H135245",
        "OpenDate": "26/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2345",
        "TokenNumber": "H135247",
        "OpenDate": "26/02/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "43",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2346",
        "TokenNumber": "H135248",
        "OpenDate": "26/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2347",
        "TokenNumber": "H135251",
        "OpenDate": "26/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2348",
        "TokenNumber": "H135254",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2349",
        "TokenNumber": "H135257",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2350",
        "TokenNumber": "H135259",
        "OpenDate": "26/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2351",
        "TokenNumber": "H135258",
        "OpenDate": "26/02/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "49",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2352",
        "TokenNumber": "H135260",
        "OpenDate": "26/02/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2353",
        "TokenNumber": "H135261",
        "OpenDate": "26/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2354",
        "TokenNumber": "H135263",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2355",
        "TokenNumber": "H135264",
        "OpenDate": "26/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2356",
        "TokenNumber": "H135265",
        "OpenDate": "26/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2357",
        "TokenNumber": "H135266",
        "OpenDate": "26/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2358",
        "TokenNumber": "H135267",
        "OpenDate": "26/02/2020",
        "CloseDate": "27/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2359",
        "TokenNumber": "H135268",
        "OpenDate": "26/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2360",
        "TokenNumber": "H135269",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2361",
        "TokenNumber": "H135271",
        "OpenDate": "26/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "21",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2362",
        "TokenNumber": "H135273",
        "OpenDate": "26/02/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "58",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2363",
        "TokenNumber": "H135274",
        "OpenDate": "26/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2364",
        "TokenNumber": "H135278",
        "OpenDate": "26/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2365",
        "TokenNumber": "H135279",
        "OpenDate": "26/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2366",
        "TokenNumber": "H135280",
        "OpenDate": "26/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "22",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2367",
        "TokenNumber": "H135281",
        "OpenDate": "26/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2368",
        "TokenNumber": "H135282",
        "OpenDate": "26/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "42",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2369",
        "TokenNumber": "H135285",
        "OpenDate": "26/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "22",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2370",
        "TokenNumber": "H135287",
        "OpenDate": "26/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2371",
        "TokenNumber": "H135288",
        "OpenDate": "26/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2372",
        "TokenNumber": "H135289",
        "OpenDate": "26/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2373",
        "TokenNumber": "H135291",
        "OpenDate": "26/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "6",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2374",
        "TokenNumber": "H135296",
        "OpenDate": "26/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2375",
        "TokenNumber": "H135297",
        "OpenDate": "26/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2376",
        "TokenNumber": "H135303",
        "OpenDate": "27/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "11",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2377",
        "TokenNumber": "H135304",
        "OpenDate": "27/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2378",
        "TokenNumber": "H135305",
        "OpenDate": "27/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2379",
        "TokenNumber": "H135306",
        "OpenDate": "27/02/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "32",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2380",
        "TokenNumber": "H135307",
        "OpenDate": "27/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "40",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2381",
        "TokenNumber": "H135309",
        "OpenDate": "27/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "13",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2382",
        "TokenNumber": "H135311",
        "OpenDate": "27/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2383",
        "TokenNumber": "H135312",
        "OpenDate": "27/02/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "53",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2384",
        "TokenNumber": "H135313",
        "OpenDate": "27/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2385",
        "TokenNumber": "H135314",
        "OpenDate": "27/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2386",
        "TokenNumber": "H135317",
        "OpenDate": "27/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2387",
        "TokenNumber": "H135316",
        "OpenDate": "27/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2388",
        "TokenNumber": "H135320",
        "OpenDate": "27/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2389",
        "TokenNumber": "H135321",
        "OpenDate": "27/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2390",
        "TokenNumber": "H135319",
        "OpenDate": "27/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2391",
        "TokenNumber": "H135323",
        "OpenDate": "27/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "40",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2392",
        "TokenNumber": "H135325",
        "OpenDate": "27/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2393",
        "TokenNumber": "H135326",
        "OpenDate": "27/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2395",
        "TokenNumber": "H135329",
        "OpenDate": "27/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2396",
        "TokenNumber": "H135331",
        "OpenDate": "27/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2397",
        "TokenNumber": "H135332",
        "OpenDate": "27/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "40",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2398",
        "TokenNumber": "H135333",
        "OpenDate": "27/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2399",
        "TokenNumber": "H135334",
        "OpenDate": "27/02/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2400",
        "TokenNumber": "H135336",
        "OpenDate": "27/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2401",
        "TokenNumber": "H135335",
        "OpenDate": "27/02/2020",
        "CloseDate": "21/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2402",
        "TokenNumber": "H135337",
        "OpenDate": "27/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2403",
        "TokenNumber": "H135338",
        "OpenDate": "27/02/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "43",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2404",
        "TokenNumber": "H135339",
        "OpenDate": "27/02/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "39",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2405",
        "TokenNumber": "H135340",
        "OpenDate": "27/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2406",
        "TokenNumber": "H135341",
        "OpenDate": "27/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2407",
        "TokenNumber": "H135342",
        "OpenDate": "27/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "40",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2408",
        "TokenNumber": "H135343",
        "OpenDate": "27/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2409",
        "TokenNumber": "H135344",
        "OpenDate": "27/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2410",
        "TokenNumber": "H135346",
        "OpenDate": "27/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2411",
        "TokenNumber": "H135345",
        "OpenDate": "27/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2412",
        "TokenNumber": "H135349",
        "OpenDate": "27/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2413",
        "TokenNumber": "H135350",
        "OpenDate": "27/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2414",
        "TokenNumber": "H135352",
        "OpenDate": "27/02/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "14",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2415",
        "TokenNumber": "H135353",
        "OpenDate": "27/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2416",
        "TokenNumber": "H135355",
        "OpenDate": "27/02/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "36",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2417",
        "TokenNumber": "H135356",
        "OpenDate": "27/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2418",
        "TokenNumber": "H135357",
        "OpenDate": "27/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2419",
        "TokenNumber": "H135358",
        "OpenDate": "27/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2420",
        "TokenNumber": "H135359",
        "OpenDate": "27/02/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2421",
        "TokenNumber": "H135361",
        "OpenDate": "27/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2422",
        "TokenNumber": "H135360",
        "OpenDate": "27/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2423",
        "TokenNumber": "H135362",
        "OpenDate": "27/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2424",
        "TokenNumber": "H135363",
        "OpenDate": "27/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2425",
        "TokenNumber": "H135365",
        "OpenDate": "27/02/2020",
        "CloseDate": "28/02/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2426",
        "TokenNumber": "H135366",
        "OpenDate": "27/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "18",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2427",
        "TokenNumber": "H135368",
        "OpenDate": "28/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "39",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2428",
        "TokenNumber": "H135370",
        "OpenDate": "28/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2429",
        "TokenNumber": "H135372",
        "OpenDate": "28/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "17",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2430",
        "TokenNumber": "H135373",
        "OpenDate": "28/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "40",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2431",
        "TokenNumber": "H135371",
        "OpenDate": "28/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "12",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2432",
        "TokenNumber": "H135374",
        "OpenDate": "28/02/2020",
        "CloseDate": "01/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2433",
        "TokenNumber": "H135375",
        "OpenDate": "28/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2434",
        "TokenNumber": "H135376",
        "OpenDate": "28/02/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2435",
        "TokenNumber": "H135377",
        "OpenDate": "28/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2436",
        "TokenNumber": "H135378",
        "OpenDate": "28/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2437",
        "TokenNumber": "H135379",
        "OpenDate": "28/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2438",
        "TokenNumber": "H135380",
        "OpenDate": "28/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2439",
        "TokenNumber": "H135382",
        "OpenDate": "28/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "12",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2440",
        "TokenNumber": "H135383",
        "OpenDate": "28/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2441",
        "TokenNumber": "H135387",
        "OpenDate": "28/02/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "24",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2442",
        "TokenNumber": "H135388",
        "OpenDate": "28/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2443",
        "TokenNumber": "H135389",
        "OpenDate": "28/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "10",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2444",
        "TokenNumber": "H135391",
        "OpenDate": "28/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2445",
        "TokenNumber": "H135392",
        "OpenDate": "28/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2446",
        "TokenNumber": "H135394",
        "OpenDate": "28/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "45",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2448",
        "TokenNumber": "H135397",
        "OpenDate": "28/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2449",
        "TokenNumber": "H135399",
        "OpenDate": "28/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2450",
        "TokenNumber": "H135402",
        "OpenDate": "28/02/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "45",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2451",
        "TokenNumber": "H135405",
        "OpenDate": "28/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2453",
        "TokenNumber": "H135408",
        "OpenDate": "28/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2454",
        "TokenNumber": "H135409",
        "OpenDate": "28/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2455",
        "TokenNumber": "H135413",
        "OpenDate": "28/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2456",
        "TokenNumber": "H135414",
        "OpenDate": "28/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "18",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2457",
        "TokenNumber": "H135415",
        "OpenDate": "28/02/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2458",
        "TokenNumber": "H135416",
        "OpenDate": "28/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2459",
        "TokenNumber": "H135418",
        "OpenDate": "28/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2460",
        "TokenNumber": "H135419",
        "OpenDate": "28/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "39",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2461",
        "TokenNumber": "H135420",
        "OpenDate": "28/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2462",
        "TokenNumber": "H135421",
        "OpenDate": "28/02/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2463",
        "TokenNumber": "H135422",
        "OpenDate": "28/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2464",
        "TokenNumber": "H135423",
        "OpenDate": "28/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2465",
        "TokenNumber": "H135424",
        "OpenDate": "28/02/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2466",
        "TokenNumber": "H135425",
        "OpenDate": "28/02/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2467",
        "TokenNumber": "H135426",
        "OpenDate": "28/02/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2468",
        "TokenNumber": "H135429",
        "OpenDate": "29/02/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "46",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2469",
        "TokenNumber": "H135430",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2470",
        "TokenNumber": "H135433",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "33",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2471",
        "TokenNumber": "H135434",
        "OpenDate": "29/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2472",
        "TokenNumber": "H135435",
        "OpenDate": "29/02/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "23",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2473",
        "TokenNumber": "H135436",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2474",
        "TokenNumber": "H135438",
        "OpenDate": "29/02/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "51",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2475",
        "TokenNumber": "H135441",
        "OpenDate": "29/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2476",
        "TokenNumber": "H135446",
        "OpenDate": "29/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2477",
        "TokenNumber": "H135448",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2478",
        "TokenNumber": "H135449",
        "OpenDate": "29/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2479",
        "TokenNumber": "H135452",
        "OpenDate": "29/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2480",
        "TokenNumber": "H135457",
        "OpenDate": "29/02/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2481",
        "TokenNumber": "H135456",
        "OpenDate": "29/02/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "39",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2482",
        "TokenNumber": "H135458",
        "OpenDate": "29/02/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2483",
        "TokenNumber": "H135460",
        "OpenDate": "29/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2485",
        "TokenNumber": "H135466",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2486",
        "TokenNumber": "H135468",
        "OpenDate": "29/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2487",
        "TokenNumber": "H135469",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2488",
        "TokenNumber": "H135471",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2489",
        "TokenNumber": "H135475",
        "OpenDate": "29/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2490",
        "TokenNumber": "H135476",
        "OpenDate": "29/02/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2491",
        "TokenNumber": "H135477",
        "OpenDate": "29/02/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2492",
        "TokenNumber": "H135479",
        "OpenDate": "29/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2493",
        "TokenNumber": "H135478",
        "OpenDate": "29/02/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2494",
        "TokenNumber": "H135480",
        "OpenDate": "29/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2495",
        "TokenNumber": "H135481",
        "OpenDate": "29/02/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "18",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2496",
        "TokenNumber": "H135483",
        "OpenDate": "29/02/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2497",
        "TokenNumber": "H135485",
        "OpenDate": "29/02/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2498",
        "TokenNumber": "H135486",
        "OpenDate": "29/02/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2499",
        "TokenNumber": "H135487",
        "OpenDate": "29/02/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2501",
        "TokenNumber": "H135491",
        "OpenDate": "29/02/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2502",
        "TokenNumber": "H135492",
        "OpenDate": "29/02/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2503",
        "TokenNumber": "H135493",
        "OpenDate": "29/02/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "37",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2504",
        "TokenNumber": "H135494",
        "OpenDate": "01/03/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2505",
        "TokenNumber": "H135495",
        "OpenDate": "01/03/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2506",
        "TokenNumber": "H135496",
        "OpenDate": "01/03/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2507",
        "TokenNumber": "H135497",
        "OpenDate": "01/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2508",
        "TokenNumber": "H135501",
        "OpenDate": "01/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "16",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2509",
        "TokenNumber": "H135502",
        "OpenDate": "01/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2510",
        "TokenNumber": "H135503",
        "OpenDate": "01/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2511",
        "TokenNumber": "H135505",
        "OpenDate": "01/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2512",
        "TokenNumber": "H135506",
        "OpenDate": "01/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "5",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2513",
        "TokenNumber": "H135507",
        "OpenDate": "01/03/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2514",
        "TokenNumber": "H135508",
        "OpenDate": "01/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2515",
        "TokenNumber": "H135511",
        "OpenDate": "01/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2516",
        "TokenNumber": "H135512",
        "OpenDate": "01/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2517",
        "TokenNumber": "H135516",
        "OpenDate": "01/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "15",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2518",
        "TokenNumber": "H135518",
        "OpenDate": "01/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2519",
        "TokenNumber": "H135522",
        "OpenDate": "01/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2520",
        "TokenNumber": "H135523",
        "OpenDate": "01/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2521",
        "TokenNumber": "H135526",
        "OpenDate": "01/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2522",
        "TokenNumber": "H135527",
        "OpenDate": "01/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "37",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2523",
        "TokenNumber": "H135528",
        "OpenDate": "01/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2524",
        "TokenNumber": "H135529",
        "OpenDate": "01/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2525",
        "TokenNumber": "H135530",
        "OpenDate": "01/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "29",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2526",
        "TokenNumber": "H135531",
        "OpenDate": "02/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "36",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2527",
        "TokenNumber": "H135535",
        "OpenDate": "02/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "36",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2528",
        "TokenNumber": "H135534",
        "OpenDate": "02/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2529",
        "TokenNumber": "H135541",
        "OpenDate": "02/03/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2530",
        "TokenNumber": "H135544",
        "OpenDate": "02/03/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2531",
        "TokenNumber": "H135545",
        "OpenDate": "02/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "51",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2532",
        "TokenNumber": "H135542",
        "OpenDate": "02/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2533",
        "TokenNumber": "H135546",
        "OpenDate": "02/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2534",
        "TokenNumber": "H135549",
        "OpenDate": "02/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "36",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2535",
        "TokenNumber": "H135550",
        "OpenDate": "02/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2536",
        "TokenNumber": "H135552",
        "OpenDate": "02/03/2020",
        "CloseDate": "02/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2537",
        "TokenNumber": "H135555",
        "OpenDate": "02/03/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2538",
        "TokenNumber": "H135554",
        "OpenDate": "02/03/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2539",
        "TokenNumber": "H135556",
        "OpenDate": "02/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "7",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2540",
        "TokenNumber": "H135557",
        "OpenDate": "02/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2542",
        "TokenNumber": "H135560",
        "OpenDate": "02/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2543",
        "TokenNumber": "H135559",
        "OpenDate": "02/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2544",
        "TokenNumber": "H135564",
        "OpenDate": "02/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "18",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2545",
        "TokenNumber": "H135566",
        "OpenDate": "02/03/2020",
        "CloseDate": "03/03/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2546",
        "TokenNumber": "H135565",
        "OpenDate": "02/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2547",
        "TokenNumber": "H135568",
        "OpenDate": "02/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2548",
        "TokenNumber": "H135570",
        "OpenDate": "02/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2549",
        "TokenNumber": "H135572",
        "OpenDate": "02/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2550",
        "TokenNumber": "H135573",
        "OpenDate": "02/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2551",
        "TokenNumber": "H135574",
        "OpenDate": "02/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2552",
        "TokenNumber": "H135575",
        "OpenDate": "02/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2553",
        "TokenNumber": "H135576",
        "OpenDate": "02/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "11",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2554",
        "TokenNumber": "H135578",
        "OpenDate": "02/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2555",
        "TokenNumber": "H135580",
        "OpenDate": "02/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2556",
        "TokenNumber": "H135581",
        "OpenDate": "02/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2557",
        "TokenNumber": "H135582",
        "OpenDate": "02/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "44",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2558",
        "TokenNumber": "H135584",
        "OpenDate": "03/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2559",
        "TokenNumber": "H135585",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2560",
        "TokenNumber": "H135587",
        "OpenDate": "03/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "17",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2561",
        "TokenNumber": "H135588",
        "OpenDate": "03/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2562",
        "TokenNumber": "H135589",
        "OpenDate": "03/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2564",
        "TokenNumber": "H135590",
        "OpenDate": "03/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2565",
        "TokenNumber": "H135592",
        "OpenDate": "03/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2566",
        "TokenNumber": "H135594",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2568",
        "TokenNumber": "H135604",
        "OpenDate": "03/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2569",
        "TokenNumber": "H135603",
        "OpenDate": "03/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2570",
        "TokenNumber": "H135605",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2571",
        "TokenNumber": "H135609",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2572",
        "TokenNumber": "H135610",
        "OpenDate": "03/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "23",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2576",
        "TokenNumber": "H135616",
        "OpenDate": "03/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2577",
        "TokenNumber": "H135618",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2578",
        "TokenNumber": "H135621",
        "OpenDate": "03/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2579",
        "TokenNumber": "H135623",
        "OpenDate": "03/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2580",
        "TokenNumber": "H135624",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2582",
        "TokenNumber": "H135629",
        "OpenDate": "03/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2583",
        "TokenNumber": "H135630",
        "OpenDate": "03/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2585",
        "TokenNumber": "H135636",
        "OpenDate": "03/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2586",
        "TokenNumber": "H135639",
        "OpenDate": "03/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2587",
        "TokenNumber": "H135640",
        "OpenDate": "03/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2588",
        "TokenNumber": "H135643",
        "OpenDate": "03/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2589",
        "TokenNumber": "H135644",
        "OpenDate": "03/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2590",
        "TokenNumber": "H135645",
        "OpenDate": "03/03/2020",
        "CloseDate": "04/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2591",
        "TokenNumber": "H135646",
        "OpenDate": "03/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2592",
        "TokenNumber": "H135647",
        "OpenDate": "03/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2593",
        "TokenNumber": "H135648",
        "OpenDate": "03/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2594",
        "TokenNumber": "H135649",
        "OpenDate": "03/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2595",
        "TokenNumber": "H135650",
        "OpenDate": "03/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2596",
        "TokenNumber": "H135651",
        "OpenDate": "03/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2597",
        "TokenNumber": "H135652",
        "OpenDate": "03/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2598",
        "TokenNumber": "H135653",
        "OpenDate": "03/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2602",
        "TokenNumber": "H135657",
        "OpenDate": "03/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2603",
        "TokenNumber": "H135658",
        "OpenDate": "03/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2604",
        "TokenNumber": "H135659",
        "OpenDate": "03/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2605",
        "TokenNumber": "H135661",
        "OpenDate": "03/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "28",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2606",
        "TokenNumber": "H135663",
        "OpenDate": "03/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "36",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2607",
        "TokenNumber": "H135664",
        "OpenDate": "04/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2608",
        "TokenNumber": "H135665",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2609",
        "TokenNumber": "H135667",
        "OpenDate": "04/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "40",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2610",
        "TokenNumber": "H135668",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2611",
        "TokenNumber": "H135669",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2612",
        "TokenNumber": "H135672",
        "OpenDate": "04/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2613",
        "TokenNumber": "H135673",
        "OpenDate": "04/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2614",
        "TokenNumber": "H135675",
        "OpenDate": "04/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2615",
        "TokenNumber": "H135676",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2616",
        "TokenNumber": "H135678",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2617",
        "TokenNumber": "H135679",
        "OpenDate": "04/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2618",
        "TokenNumber": "H135680",
        "OpenDate": "04/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2620",
        "TokenNumber": "H135687",
        "OpenDate": "04/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2621",
        "TokenNumber": "H135689",
        "OpenDate": "04/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2623",
        "TokenNumber": "H135693",
        "OpenDate": "04/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2624",
        "TokenNumber": "H135694",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2625",
        "TokenNumber": "H135696",
        "OpenDate": "04/03/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2627",
        "TokenNumber": "H135699",
        "OpenDate": "04/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2628",
        "TokenNumber": "H135702",
        "OpenDate": "04/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "7",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2629",
        "TokenNumber": "H135704",
        "OpenDate": "04/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2630",
        "TokenNumber": "H135705",
        "OpenDate": "04/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2631",
        "TokenNumber": "H135708",
        "OpenDate": "04/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "34",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2632",
        "TokenNumber": "H135710",
        "OpenDate": "04/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2633",
        "TokenNumber": "H135711",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2634",
        "TokenNumber": "H135713",
        "OpenDate": "04/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2635",
        "TokenNumber": "H135715",
        "OpenDate": "04/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2637",
        "TokenNumber": "H135716",
        "OpenDate": "04/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2638",
        "TokenNumber": "H135718",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2639",
        "TokenNumber": "H135719",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2640",
        "TokenNumber": "H135720",
        "OpenDate": "04/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2641",
        "TokenNumber": "H135721",
        "OpenDate": "04/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2642",
        "TokenNumber": "H135723",
        "OpenDate": "04/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2643",
        "TokenNumber": "H135724",
        "OpenDate": "04/03/2020",
        "CloseDate": "05/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2644",
        "TokenNumber": "H135725",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "33",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2647",
        "TokenNumber": "H135732",
        "OpenDate": "04/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "19",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2649",
        "TokenNumber": "H135735",
        "OpenDate": "04/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2650",
        "TokenNumber": "H135736",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2651",
        "TokenNumber": "H135737",
        "OpenDate": "04/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "16",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2652",
        "TokenNumber": "H135738",
        "OpenDate": "04/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2653",
        "TokenNumber": "H135739",
        "OpenDate": "04/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2654",
        "TokenNumber": "H135741",
        "OpenDate": "04/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2655",
        "TokenNumber": "H135742",
        "OpenDate": "04/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2656",
        "TokenNumber": "H135743",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2657",
        "TokenNumber": "H135744",
        "OpenDate": "04/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "5",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2658",
        "TokenNumber": "H135747",
        "OpenDate": "04/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2659",
        "TokenNumber": "H135748",
        "OpenDate": "04/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2660",
        "TokenNumber": "H135750",
        "OpenDate": "04/03/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2661",
        "TokenNumber": "H135751",
        "OpenDate": "04/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2662",
        "TokenNumber": "H135752",
        "OpenDate": "04/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2663",
        "TokenNumber": "H135753",
        "OpenDate": "04/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2664",
        "TokenNumber": "H135754",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2665",
        "TokenNumber": "H135755",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2666",
        "TokenNumber": "H135757",
        "OpenDate": "05/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2667",
        "TokenNumber": "H135758",
        "OpenDate": "05/03/2020",
        "CloseDate": "10/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2669",
        "TokenNumber": "H135762",
        "OpenDate": "05/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2670",
        "TokenNumber": "H135763",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2671",
        "TokenNumber": "H135764",
        "OpenDate": "05/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2672",
        "TokenNumber": "H135766",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2673",
        "TokenNumber": "H135768",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2674",
        "TokenNumber": "H135770",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2675",
        "TokenNumber": "H135769",
        "OpenDate": "05/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2676",
        "TokenNumber": "H135771",
        "OpenDate": "05/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "6",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2677",
        "TokenNumber": "H135765",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2678",
        "TokenNumber": "H135772",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "35",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2679",
        "TokenNumber": "H135773",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2680",
        "TokenNumber": "H135775",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "4",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2681",
        "TokenNumber": "H135777",
        "OpenDate": "05/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2682",
        "TokenNumber": "H135780",
        "OpenDate": "05/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2683",
        "TokenNumber": "H135781",
        "OpenDate": "05/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2684",
        "TokenNumber": "H135782",
        "OpenDate": "05/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2685",
        "TokenNumber": "H135784",
        "OpenDate": "05/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2686",
        "TokenNumber": "H135785",
        "OpenDate": "05/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2687",
        "TokenNumber": "H135789",
        "OpenDate": "05/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "1",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2688",
        "TokenNumber": "H135790",
        "OpenDate": "05/03/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2689",
        "TokenNumber": "H135791",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2690",
        "TokenNumber": "H135792",
        "OpenDate": "05/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2691",
        "TokenNumber": "H135794",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2692",
        "TokenNumber": "H135795",
        "OpenDate": "05/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "48",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2693",
        "TokenNumber": "H135797",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2694",
        "TokenNumber": "H135800",
        "OpenDate": "05/03/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2695",
        "TokenNumber": "H135801",
        "OpenDate": "05/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2696",
        "TokenNumber": "H135804",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2697",
        "TokenNumber": "H135808",
        "OpenDate": "05/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "25",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2698",
        "TokenNumber": "H135810",
        "OpenDate": "05/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "48",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2700",
        "TokenNumber": "H135815",
        "OpenDate": "05/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2701",
        "TokenNumber": "H135816",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2702",
        "TokenNumber": "H135817",
        "OpenDate": "05/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2703",
        "TokenNumber": "H135819",
        "OpenDate": "05/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2704",
        "TokenNumber": "H135818",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2705",
        "TokenNumber": "H135820",
        "OpenDate": "05/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2706",
        "TokenNumber": "H135822",
        "OpenDate": "05/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2707",
        "TokenNumber": "H135821",
        "OpenDate": "05/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "33",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2708",
        "TokenNumber": "H135823",
        "OpenDate": "05/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2709",
        "TokenNumber": "H135824",
        "OpenDate": "05/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2710",
        "TokenNumber": "H135825",
        "OpenDate": "05/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2711",
        "TokenNumber": "H135827",
        "OpenDate": "05/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "12",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2712",
        "TokenNumber": "H135829",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2713",
        "TokenNumber": "H135830",
        "OpenDate": "06/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2714",
        "TokenNumber": "H135833",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2715",
        "TokenNumber": "H135835",
        "OpenDate": "06/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "0",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2716",
        "TokenNumber": "H135837",
        "OpenDate": "06/03/2020",
        "CloseDate": "21/03/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2717",
        "TokenNumber": "H135841",
        "OpenDate": "06/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "10",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2718",
        "TokenNumber": "H135842",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2719",
        "TokenNumber": "H135843",
        "OpenDate": "06/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "0",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2720",
        "TokenNumber": "H135844",
        "OpenDate": "06/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2721",
        "TokenNumber": "H135845",
        "OpenDate": "06/03/2020",
        "CloseDate": "06/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2722",
        "TokenNumber": "H135847",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2723",
        "TokenNumber": "H135849",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2724",
        "TokenNumber": "H135850",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "34",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2725",
        "TokenNumber": "H135851",
        "OpenDate": "06/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2726",
        "TokenNumber": "H135852",
        "OpenDate": "06/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "28",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2727",
        "TokenNumber": "H135853",
        "OpenDate": "06/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2728",
        "TokenNumber": "H135856",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2729",
        "TokenNumber": "H135857",
        "OpenDate": "06/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "33",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2730",
        "TokenNumber": "H135858",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2731",
        "TokenNumber": "H135862",
        "OpenDate": "06/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "10",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2732",
        "TokenNumber": "H135863",
        "OpenDate": "06/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "13",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2733",
        "TokenNumber": "H135865",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "34",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2734",
        "TokenNumber": "H135868",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2736",
        "TokenNumber": "H135872",
        "OpenDate": "06/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2737",
        "TokenNumber": "H135873",
        "OpenDate": "06/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2738",
        "TokenNumber": "H135874",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2739",
        "TokenNumber": "H135875",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2740",
        "TokenNumber": "H135876",
        "OpenDate": "06/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2741",
        "TokenNumber": "H135877",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2742",
        "TokenNumber": "H135880",
        "OpenDate": "06/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2743",
        "TokenNumber": "H135879",
        "OpenDate": "06/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2744",
        "TokenNumber": "H135881",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2746",
        "TokenNumber": "H135884",
        "OpenDate": "06/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2747",
        "TokenNumber": "H135885",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2748",
        "TokenNumber": "H135886",
        "OpenDate": "06/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2749",
        "TokenNumber": "H135888",
        "OpenDate": "06/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2750",
        "TokenNumber": "H135889",
        "OpenDate": "06/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2751",
        "TokenNumber": "H135890",
        "OpenDate": "06/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "32",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2752",
        "TokenNumber": "H135891",
        "OpenDate": "06/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "5",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2753",
        "TokenNumber": "H135893",
        "OpenDate": "07/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2754",
        "TokenNumber": "H135894",
        "OpenDate": "07/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2755",
        "TokenNumber": "H135895",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2757",
        "TokenNumber": "H135899",
        "OpenDate": "07/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2758",
        "TokenNumber": "H135900",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2759",
        "TokenNumber": "H135902",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2760",
        "TokenNumber": "H135903",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2761",
        "TokenNumber": "H135904",
        "OpenDate": "07/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "32",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2762",
        "TokenNumber": "H135906",
        "OpenDate": "07/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2763",
        "TokenNumber": "H135907",
        "OpenDate": "07/03/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "30",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2764",
        "TokenNumber": "H135908",
        "OpenDate": "07/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2765",
        "TokenNumber": "H135909",
        "OpenDate": "07/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2766",
        "TokenNumber": "H135911",
        "OpenDate": "07/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2767",
        "TokenNumber": "H135912",
        "OpenDate": "07/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2768",
        "TokenNumber": "H135913",
        "OpenDate": "07/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2769",
        "TokenNumber": "H135914",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2770",
        "TokenNumber": "H135915",
        "OpenDate": "07/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2771",
        "TokenNumber": "H135920",
        "OpenDate": "07/03/2020",
        "CloseDate": "09/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2772",
        "TokenNumber": "H135921",
        "OpenDate": "07/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2773",
        "TokenNumber": "H135922",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2774",
        "TokenNumber": "H135925",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2775",
        "TokenNumber": "H135929",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "37",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2776",
        "TokenNumber": "H135928",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2777",
        "TokenNumber": "H135930",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2778",
        "TokenNumber": "H135931",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2779",
        "TokenNumber": "H135933",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2780",
        "TokenNumber": "H135934",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2782",
        "TokenNumber": "H135938",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2783",
        "TokenNumber": "H135939",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "37",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2784",
        "TokenNumber": "H135940",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2785",
        "TokenNumber": "H135941",
        "OpenDate": "07/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2786",
        "TokenNumber": "H135942",
        "OpenDate": "07/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2787",
        "TokenNumber": "H135943",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2788",
        "TokenNumber": "H135944",
        "OpenDate": "07/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2789",
        "TokenNumber": "H135947",
        "OpenDate": "07/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2791",
        "TokenNumber": "H135949",
        "OpenDate": "07/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2792",
        "TokenNumber": "H135950",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2793",
        "TokenNumber": "H135951",
        "OpenDate": "07/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2794",
        "TokenNumber": "H135954",
        "OpenDate": "07/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "47",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2795",
        "TokenNumber": "H135959",
        "OpenDate": "07/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2796",
        "TokenNumber": "H135963",
        "OpenDate": "08/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2797",
        "TokenNumber": "H135964",
        "OpenDate": "08/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2799",
        "TokenNumber": "H135970",
        "OpenDate": "08/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2800",
        "TokenNumber": "H135974",
        "OpenDate": "08/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2801",
        "TokenNumber": "H135976",
        "OpenDate": "08/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2802",
        "TokenNumber": "H135979",
        "OpenDate": "08/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2803",
        "TokenNumber": "H135980",
        "OpenDate": "08/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "11",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2804",
        "TokenNumber": "H135981",
        "OpenDate": "08/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2805",
        "TokenNumber": "H135984",
        "OpenDate": "08/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2806",
        "TokenNumber": "H135985",
        "OpenDate": "08/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "11",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2807",
        "TokenNumber": "H135986",
        "OpenDate": "08/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2808",
        "TokenNumber": "H135987",
        "OpenDate": "08/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2809",
        "TokenNumber": "H135988",
        "OpenDate": "08/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2810",
        "TokenNumber": "H135989",
        "OpenDate": "08/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2811",
        "TokenNumber": "H135990",
        "OpenDate": "08/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2812",
        "TokenNumber": "H135993",
        "OpenDate": "08/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2813",
        "TokenNumber": "H135994",
        "OpenDate": "08/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2814",
        "TokenNumber": "H135996",
        "OpenDate": "08/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2816",
        "TokenNumber": "H135999",
        "OpenDate": "08/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2817",
        "TokenNumber": "H136000",
        "OpenDate": "09/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "31",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2818",
        "TokenNumber": "H136001",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2819",
        "TokenNumber": "H136002",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2820",
        "TokenNumber": "H136003",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2821",
        "TokenNumber": "H136004",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2822",
        "TokenNumber": "H136006",
        "OpenDate": "09/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2823",
        "TokenNumber": "H136008",
        "OpenDate": "09/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2824",
        "TokenNumber": "H136010",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2825",
        "TokenNumber": "H136009",
        "OpenDate": "09/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2826",
        "TokenNumber": "H136011",
        "OpenDate": "09/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2828",
        "TokenNumber": "H136013",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2829",
        "TokenNumber": "H136014",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2830",
        "TokenNumber": "H136015",
        "OpenDate": "09/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2831",
        "TokenNumber": "H136017",
        "OpenDate": "09/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2832",
        "TokenNumber": "H136018",
        "OpenDate": "09/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2833",
        "TokenNumber": "H136021",
        "OpenDate": "09/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2834",
        "TokenNumber": "H136022",
        "OpenDate": "09/03/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "32",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2835",
        "TokenNumber": "H136025",
        "OpenDate": "09/03/2020",
        "CloseDate": "12/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2836",
        "TokenNumber": "H136024",
        "OpenDate": "09/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2837",
        "TokenNumber": "H136027",
        "OpenDate": "09/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2838",
        "TokenNumber": "H136032",
        "OpenDate": "09/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "31",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2839",
        "TokenNumber": "H136034",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2840",
        "TokenNumber": "H136037",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2841",
        "TokenNumber": "H136040",
        "OpenDate": "09/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "9",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2843",
        "TokenNumber": "H136042",
        "OpenDate": "09/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2844",
        "TokenNumber": "H136043",
        "OpenDate": "09/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2845",
        "TokenNumber": "H136044",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2846",
        "TokenNumber": "H136045",
        "OpenDate": "09/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2847",
        "TokenNumber": "H136050",
        "OpenDate": "09/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "10",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2848",
        "TokenNumber": "H136052",
        "OpenDate": "09/03/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2849",
        "TokenNumber": "H136053",
        "OpenDate": "09/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2850",
        "TokenNumber": "H136054",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2851",
        "TokenNumber": "H136055",
        "OpenDate": "09/03/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2852",
        "TokenNumber": "H136056",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2853",
        "TokenNumber": "H136060",
        "OpenDate": "09/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2854",
        "TokenNumber": "H136061",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2855",
        "TokenNumber": "H136062",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2856",
        "TokenNumber": "H136063",
        "OpenDate": "09/03/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "42",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2857",
        "TokenNumber": "H136065",
        "OpenDate": "09/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2858",
        "TokenNumber": "H136066",
        "OpenDate": "09/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2859",
        "TokenNumber": "H136067",
        "OpenDate": "09/03/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2860",
        "TokenNumber": "H136069",
        "OpenDate": "10/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2861",
        "TokenNumber": "H136071",
        "OpenDate": "10/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "24",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2862",
        "TokenNumber": "H136070",
        "OpenDate": "10/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2863",
        "TokenNumber": "H136073",
        "OpenDate": "10/03/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "56",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2864",
        "TokenNumber": "H136075",
        "OpenDate": "10/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2865",
        "TokenNumber": "H136076",
        "OpenDate": "10/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "29",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2867",
        "TokenNumber": "H136078",
        "OpenDate": "10/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2868",
        "TokenNumber": "H136079",
        "OpenDate": "10/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2869",
        "TokenNumber": "H136081",
        "OpenDate": "10/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2870",
        "TokenNumber": "H136082",
        "OpenDate": "10/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2871",
        "TokenNumber": "H136084",
        "OpenDate": "10/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2872",
        "TokenNumber": "H136085",
        "OpenDate": "10/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "22",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2873",
        "TokenNumber": "H136086",
        "OpenDate": "10/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2874",
        "TokenNumber": "H136087",
        "OpenDate": "10/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "13",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2875",
        "TokenNumber": "H136088",
        "OpenDate": "10/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2876",
        "TokenNumber": "H136089",
        "OpenDate": "10/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2877",
        "TokenNumber": "H136090",
        "OpenDate": "10/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2879",
        "TokenNumber": "H136099",
        "OpenDate": "10/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2880",
        "TokenNumber": "H136102",
        "OpenDate": "10/03/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2881",
        "TokenNumber": "H136103",
        "OpenDate": "10/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2882",
        "TokenNumber": "H136105",
        "OpenDate": "10/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2883",
        "TokenNumber": "H136106",
        "OpenDate": "10/03/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2884",
        "TokenNumber": "H136109",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2885",
        "TokenNumber": "H136110",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2886",
        "TokenNumber": "H136114",
        "OpenDate": "11/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2887",
        "TokenNumber": "H136115",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2888",
        "TokenNumber": "H136116",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2889",
        "TokenNumber": "H136117",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2890",
        "TokenNumber": "H136118",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2891",
        "TokenNumber": "H136119",
        "OpenDate": "11/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2892",
        "TokenNumber": "H136121",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2893",
        "TokenNumber": "H136122",
        "OpenDate": "11/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2894",
        "TokenNumber": "H136123",
        "OpenDate": "11/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2895",
        "TokenNumber": "H136125",
        "OpenDate": "11/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2896",
        "TokenNumber": "H136124",
        "OpenDate": "11/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2898",
        "TokenNumber": "H136128",
        "OpenDate": "11/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2899",
        "TokenNumber": "H136129",
        "OpenDate": "11/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2900",
        "TokenNumber": "H136131",
        "OpenDate": "11/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2901",
        "TokenNumber": "H136132",
        "OpenDate": "11/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "8",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2902",
        "TokenNumber": "H136133",
        "OpenDate": "11/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2903",
        "TokenNumber": "H136135",
        "OpenDate": "11/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2904",
        "TokenNumber": "H136138",
        "OpenDate": "11/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2905",
        "TokenNumber": "H136136",
        "OpenDate": "11/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2906",
        "TokenNumber": "H136140",
        "OpenDate": "11/03/2020",
        "CloseDate": "11/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2907",
        "TokenNumber": "H136141",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2908",
        "TokenNumber": "H136142",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2911",
        "TokenNumber": "H136146",
        "OpenDate": "11/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2912",
        "TokenNumber": "H136148",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2913",
        "TokenNumber": "H136149",
        "OpenDate": "11/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2914",
        "TokenNumber": "H136150",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2915",
        "TokenNumber": "H136151",
        "OpenDate": "11/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2916",
        "TokenNumber": "H136153",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "33",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2917",
        "TokenNumber": "H136155",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2918",
        "TokenNumber": "H136157",
        "OpenDate": "11/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2919",
        "TokenNumber": "H136160",
        "OpenDate": "11/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "23",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2920",
        "TokenNumber": "H136167",
        "OpenDate": "11/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2921",
        "TokenNumber": "H136170",
        "OpenDate": "11/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2922",
        "TokenNumber": "H136171",
        "OpenDate": "11/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2923",
        "TokenNumber": "H136173",
        "OpenDate": "11/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "5",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2924",
        "TokenNumber": "H136174",
        "OpenDate": "11/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2925",
        "TokenNumber": "H136175",
        "OpenDate": "11/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2926",
        "TokenNumber": "H136176",
        "OpenDate": "11/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2927",
        "TokenNumber": "H136180",
        "OpenDate": "11/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "16",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2928",
        "TokenNumber": "H136181",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2929",
        "TokenNumber": "H136182",
        "OpenDate": "11/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "23",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2930",
        "TokenNumber": "H136184",
        "OpenDate": "11/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2931",
        "TokenNumber": "H136185",
        "OpenDate": "11/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2933",
        "TokenNumber": "H136187",
        "OpenDate": "11/03/2020",
        "CloseDate": "13/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2934",
        "TokenNumber": "H136188",
        "OpenDate": "11/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2935",
        "TokenNumber": "H136191",
        "OpenDate": "11/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2936",
        "TokenNumber": "H136192",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2937",
        "TokenNumber": "H136193",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2938",
        "TokenNumber": "H136194",
        "OpenDate": "12/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "2939",
        "TokenNumber": "H136195",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2940",
        "TokenNumber": "H136196",
        "OpenDate": "12/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2941",
        "TokenNumber": "H136201",
        "OpenDate": "12/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2942",
        "TokenNumber": "H136202",
        "OpenDate": "12/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2943",
        "TokenNumber": "H136203",
        "OpenDate": "12/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2944",
        "TokenNumber": "H136204",
        "OpenDate": "12/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2945",
        "TokenNumber": "H136207",
        "OpenDate": "12/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2946",
        "TokenNumber": "H136208",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2948",
        "TokenNumber": "H136210",
        "OpenDate": "12/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2949",
        "TokenNumber": "H136212",
        "OpenDate": "12/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2950",
        "TokenNumber": "H136213",
        "OpenDate": "12/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2951",
        "TokenNumber": "H136214",
        "OpenDate": "12/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2952",
        "TokenNumber": "H136215",
        "OpenDate": "12/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "28",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2953",
        "TokenNumber": "H136216",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2954",
        "TokenNumber": "H136218",
        "OpenDate": "12/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "27",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2955",
        "TokenNumber": "H136220",
        "OpenDate": "12/03/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "54",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2956",
        "TokenNumber": "H136222",
        "OpenDate": "12/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2957",
        "TokenNumber": "H136224",
        "OpenDate": "12/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2958",
        "TokenNumber": "H136226",
        "OpenDate": "12/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2959",
        "TokenNumber": "H136227",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2960",
        "TokenNumber": "H136230",
        "OpenDate": "12/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2961",
        "TokenNumber": "H136229",
        "OpenDate": "12/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2962",
        "TokenNumber": "H136232",
        "OpenDate": "12/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2963",
        "TokenNumber": "H136233",
        "OpenDate": "12/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2964",
        "TokenNumber": "H136234",
        "OpenDate": "12/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2965",
        "TokenNumber": "H136237",
        "OpenDate": "12/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "28",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2966",
        "TokenNumber": "H136238",
        "OpenDate": "12/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2967",
        "TokenNumber": "H136239",
        "OpenDate": "12/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2968",
        "TokenNumber": "H136240",
        "OpenDate": "12/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2970",
        "TokenNumber": "H136242",
        "OpenDate": "12/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "42",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2971",
        "TokenNumber": "H136243",
        "OpenDate": "12/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2972",
        "TokenNumber": "H136249",
        "OpenDate": "13/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2973",
        "TokenNumber": "H136248",
        "OpenDate": "13/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2974",
        "TokenNumber": "H136250",
        "OpenDate": "13/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2975",
        "TokenNumber": "H136251",
        "OpenDate": "13/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2976",
        "TokenNumber": "H136254",
        "OpenDate": "13/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2977",
        "TokenNumber": "H136252",
        "OpenDate": "13/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "21",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2978",
        "TokenNumber": "H136253",
        "OpenDate": "13/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2979",
        "TokenNumber": "H136257",
        "OpenDate": "13/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2980",
        "TokenNumber": "H136260",
        "OpenDate": "13/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2981",
        "TokenNumber": "H136261",
        "OpenDate": "13/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2982",
        "TokenNumber": "H136262",
        "OpenDate": "13/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2983",
        "TokenNumber": "H136266",
        "OpenDate": "13/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "27",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2984",
        "TokenNumber": "H136270",
        "OpenDate": "13/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2985",
        "TokenNumber": "H136268",
        "OpenDate": "13/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2986",
        "TokenNumber": "H136269",
        "OpenDate": "13/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2987",
        "TokenNumber": "H136273",
        "OpenDate": "13/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2988",
        "TokenNumber": "H136274",
        "OpenDate": "13/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2989",
        "TokenNumber": "H136276",
        "OpenDate": "13/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2990",
        "TokenNumber": "H136278",
        "OpenDate": "13/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2991",
        "TokenNumber": "H136280",
        "OpenDate": "13/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2993",
        "TokenNumber": "H136286",
        "OpenDate": "13/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2994",
        "TokenNumber": "H136284",
        "OpenDate": "13/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2995",
        "TokenNumber": "H136287",
        "OpenDate": "13/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2998",
        "TokenNumber": "H136294",
        "OpenDate": "13/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "2999",
        "TokenNumber": "H136298",
        "OpenDate": "13/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3000",
        "TokenNumber": "H136300",
        "OpenDate": "13/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3003",
        "TokenNumber": "H136303",
        "OpenDate": "13/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3004",
        "TokenNumber": "H136307",
        "OpenDate": "13/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3006",
        "TokenNumber": "H136311",
        "OpenDate": "13/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3007",
        "TokenNumber": "H136313",
        "OpenDate": "13/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3008",
        "TokenNumber": "H136314",
        "OpenDate": "13/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3009",
        "TokenNumber": "H136316",
        "OpenDate": "13/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3010",
        "TokenNumber": "H136319",
        "OpenDate": "13/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "19",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3012",
        "TokenNumber": "H136321",
        "OpenDate": "13/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3013",
        "TokenNumber": "H136322",
        "OpenDate": "13/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "18",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3014",
        "TokenNumber": "H136324",
        "OpenDate": "13/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "5",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3016",
        "TokenNumber": "H136326",
        "OpenDate": "13/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3017",
        "TokenNumber": "H136329",
        "OpenDate": "14/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3018",
        "TokenNumber": "H136330",
        "OpenDate": "14/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3019",
        "TokenNumber": "H136331",
        "OpenDate": "14/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3020",
        "TokenNumber": "H136334",
        "OpenDate": "14/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "30",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3021",
        "TokenNumber": "H136338",
        "OpenDate": "14/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3022",
        "TokenNumber": "H136336",
        "OpenDate": "14/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3023",
        "TokenNumber": "H136342",
        "OpenDate": "14/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3024",
        "TokenNumber": "H136340",
        "OpenDate": "14/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "40",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3027",
        "TokenNumber": "H136349",
        "OpenDate": "14/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3028",
        "TokenNumber": "H136351",
        "OpenDate": "14/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3029",
        "TokenNumber": "H136352",
        "OpenDate": "14/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3030",
        "TokenNumber": "H136354",
        "OpenDate": "14/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3031",
        "TokenNumber": "H136357",
        "OpenDate": "14/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3032",
        "TokenNumber": "H136358",
        "OpenDate": "14/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3033",
        "TokenNumber": "H136362",
        "OpenDate": "14/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3034",
        "TokenNumber": "H136361",
        "OpenDate": "14/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3035",
        "TokenNumber": "H136360",
        "OpenDate": "14/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3036",
        "TokenNumber": "H136363",
        "OpenDate": "14/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3037",
        "TokenNumber": "H136364",
        "OpenDate": "14/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3039",
        "TokenNumber": "H136367",
        "OpenDate": "14/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3040",
        "TokenNumber": "H136370",
        "OpenDate": "14/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3042",
        "TokenNumber": "H136372",
        "OpenDate": "14/03/2020",
        "CloseDate": "14/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3043",
        "TokenNumber": "H136375",
        "OpenDate": "14/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3044",
        "TokenNumber": "H136371",
        "OpenDate": "14/03/2020",
        "CloseDate": "14/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3045",
        "TokenNumber": "H136376",
        "OpenDate": "14/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3046",
        "TokenNumber": "H136378",
        "OpenDate": "14/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "39",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3047",
        "TokenNumber": "H136379",
        "OpenDate": "14/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3049",
        "TokenNumber": "H136381",
        "OpenDate": "14/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3050",
        "TokenNumber": "H136383",
        "OpenDate": "14/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3051",
        "TokenNumber": "H136387",
        "OpenDate": "14/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3052",
        "TokenNumber": "H136386",
        "OpenDate": "14/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3053",
        "TokenNumber": "H136388",
        "OpenDate": "14/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3054",
        "TokenNumber": "H136390",
        "OpenDate": "14/03/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "41",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3056",
        "TokenNumber": "H136392",
        "OpenDate": "15/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3057",
        "TokenNumber": "H136393",
        "OpenDate": "15/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3058",
        "TokenNumber": "H136394",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3059",
        "TokenNumber": "H136396",
        "OpenDate": "15/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3060",
        "TokenNumber": "H136397",
        "OpenDate": "15/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3061",
        "TokenNumber": "H136400",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3062",
        "TokenNumber": "H136399",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3063",
        "TokenNumber": "H136401",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3064",
        "TokenNumber": "H136402",
        "OpenDate": "15/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3065",
        "TokenNumber": "H136404",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3066",
        "TokenNumber": "H136407",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3067",
        "TokenNumber": "H136411",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3068",
        "TokenNumber": "H136412",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3069",
        "TokenNumber": "H136414",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3070",
        "TokenNumber": "H136415",
        "OpenDate": "15/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3071",
        "TokenNumber": "H136418",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3072",
        "TokenNumber": "H136419",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3073",
        "TokenNumber": "H136421",
        "OpenDate": "15/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3074",
        "TokenNumber": "H136422",
        "OpenDate": "15/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3075",
        "TokenNumber": "H136426",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3076",
        "TokenNumber": "H136427",
        "OpenDate": "15/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "31",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3077",
        "TokenNumber": "H136428",
        "OpenDate": "15/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3078",
        "TokenNumber": "H136430",
        "OpenDate": "15/03/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3079",
        "TokenNumber": "H136433",
        "OpenDate": "15/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3080",
        "TokenNumber": "H136434",
        "OpenDate": "15/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3081",
        "TokenNumber": "H136435",
        "OpenDate": "15/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3082",
        "TokenNumber": "H136438",
        "OpenDate": "15/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3083",
        "TokenNumber": "H136437",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3084",
        "TokenNumber": "H136440",
        "OpenDate": "15/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "29",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3085",
        "TokenNumber": "H136441",
        "OpenDate": "15/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "23",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3086",
        "TokenNumber": "H136442",
        "OpenDate": "15/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3087",
        "TokenNumber": "H136443",
        "OpenDate": "15/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3088",
        "TokenNumber": "H136446",
        "OpenDate": "15/03/2020",
        "CloseDate": "16/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3089",
        "TokenNumber": "H136447",
        "OpenDate": "15/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3090",
        "TokenNumber": "H136449",
        "OpenDate": "15/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3091",
        "TokenNumber": "H136450",
        "OpenDate": "15/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3092",
        "TokenNumber": "H136451",
        "OpenDate": "15/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3093",
        "TokenNumber": "H136452",
        "OpenDate": "15/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "32",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3094",
        "TokenNumber": "H136453",
        "OpenDate": "15/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "38",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3095",
        "TokenNumber": "H136454",
        "OpenDate": "15/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3097",
        "TokenNumber": "H136456",
        "OpenDate": "15/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3098",
        "TokenNumber": "H136458",
        "OpenDate": "16/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3099",
        "TokenNumber": "H136459",
        "OpenDate": "16/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3101",
        "TokenNumber": "H136461",
        "OpenDate": "16/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3102",
        "TokenNumber": "H136462",
        "OpenDate": "16/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3103",
        "TokenNumber": "H136463",
        "OpenDate": "16/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3104",
        "TokenNumber": "H136465",
        "OpenDate": "16/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3105",
        "TokenNumber": "H136464",
        "OpenDate": "16/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3106",
        "TokenNumber": "H136467",
        "OpenDate": "16/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3107",
        "TokenNumber": "H136468",
        "OpenDate": "16/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "1",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3108",
        "TokenNumber": "H136469",
        "OpenDate": "16/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3109",
        "TokenNumber": "H136471",
        "OpenDate": "16/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3111",
        "TokenNumber": "H136475",
        "OpenDate": "16/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "24",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3112",
        "TokenNumber": "H136482",
        "OpenDate": "16/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3114",
        "TokenNumber": "H136489",
        "OpenDate": "16/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3115",
        "TokenNumber": "H136490",
        "OpenDate": "16/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3116",
        "TokenNumber": "H136492",
        "OpenDate": "16/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3117",
        "TokenNumber": "H136493",
        "OpenDate": "16/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "31",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3118",
        "TokenNumber": "H136494",
        "OpenDate": "16/03/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "39",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3119",
        "TokenNumber": "H136495",
        "OpenDate": "16/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3120",
        "TokenNumber": "H136497",
        "OpenDate": "16/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3121",
        "TokenNumber": "H136501",
        "OpenDate": "16/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "18",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3122",
        "TokenNumber": "H136502",
        "OpenDate": "16/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3123",
        "TokenNumber": "H136504",
        "OpenDate": "16/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3124",
        "TokenNumber": "H136503",
        "OpenDate": "16/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3125",
        "TokenNumber": "H136506",
        "OpenDate": "16/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3126",
        "TokenNumber": "H136505",
        "OpenDate": "16/03/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "39",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3127",
        "TokenNumber": "H136508",
        "OpenDate": "16/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3128",
        "TokenNumber": "H136509",
        "OpenDate": "16/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3129",
        "TokenNumber": "H136514",
        "OpenDate": "16/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3130",
        "TokenNumber": "H136515",
        "OpenDate": "16/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3131",
        "TokenNumber": "H136517",
        "OpenDate": "16/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "16",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3133",
        "TokenNumber": "H136519",
        "OpenDate": "16/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3134",
        "TokenNumber": "H136520",
        "OpenDate": "16/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3135",
        "TokenNumber": "H136521",
        "OpenDate": "16/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3136",
        "TokenNumber": "H136523",
        "OpenDate": "16/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3137",
        "TokenNumber": "H136525",
        "OpenDate": "16/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "24",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3138",
        "TokenNumber": "H136526",
        "OpenDate": "16/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3139",
        "TokenNumber": "H136527",
        "OpenDate": "16/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3140",
        "TokenNumber": "H136528",
        "OpenDate": "16/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3141",
        "TokenNumber": "H136531",
        "OpenDate": "16/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "23",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3142",
        "TokenNumber": "H136532",
        "OpenDate": "16/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3143",
        "TokenNumber": "H136533",
        "OpenDate": "16/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3144",
        "TokenNumber": "H136534",
        "OpenDate": "17/03/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "35",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3145",
        "TokenNumber": "H136535",
        "OpenDate": "17/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3146",
        "TokenNumber": "H136538",
        "OpenDate": "17/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3147",
        "TokenNumber": "H136540",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3148",
        "TokenNumber": "H136541",
        "OpenDate": "17/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3149",
        "TokenNumber": "H136542",
        "OpenDate": "17/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3150",
        "TokenNumber": "H136543",
        "OpenDate": "17/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3151",
        "TokenNumber": "H136544",
        "OpenDate": "17/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3152",
        "TokenNumber": "H136545",
        "OpenDate": "17/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3153",
        "TokenNumber": "H136546",
        "OpenDate": "17/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3154",
        "TokenNumber": "H136547",
        "OpenDate": "17/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3155",
        "TokenNumber": "H136549",
        "OpenDate": "17/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3156",
        "TokenNumber": "H136550",
        "OpenDate": "17/03/2020",
        "CloseDate": "17/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3157",
        "TokenNumber": "H136551",
        "OpenDate": "17/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "29",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3158",
        "TokenNumber": "H136552",
        "OpenDate": "17/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3159",
        "TokenNumber": "H136553",
        "OpenDate": "17/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3160",
        "TokenNumber": "H136555",
        "OpenDate": "17/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "29",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3161",
        "TokenNumber": "H136554",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3162",
        "TokenNumber": "H136556",
        "OpenDate": "17/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "29",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3163",
        "TokenNumber": "H136559",
        "OpenDate": "17/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3164",
        "TokenNumber": "H136560",
        "OpenDate": "17/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3165",
        "TokenNumber": "H136557",
        "OpenDate": "17/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3166",
        "TokenNumber": "H136564",
        "OpenDate": "17/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3167",
        "TokenNumber": "H136566",
        "OpenDate": "17/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3168",
        "TokenNumber": "H136565",
        "OpenDate": "17/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3169",
        "TokenNumber": "H136567",
        "OpenDate": "17/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3172",
        "TokenNumber": "H136572",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3173",
        "TokenNumber": "H136574",
        "OpenDate": "17/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3174",
        "TokenNumber": "H136573",
        "OpenDate": "17/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3175",
        "TokenNumber": "H136575",
        "OpenDate": "17/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3176",
        "TokenNumber": "H136576",
        "OpenDate": "17/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "10",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3177",
        "TokenNumber": "H136582",
        "OpenDate": "17/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3178",
        "TokenNumber": "H136583",
        "OpenDate": "17/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "13",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3179",
        "TokenNumber": "H136577",
        "OpenDate": "17/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3180",
        "TokenNumber": "H136584",
        "OpenDate": "17/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3181",
        "TokenNumber": "H136587",
        "OpenDate": "17/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3182",
        "TokenNumber": "H136578",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3183",
        "TokenNumber": "H136589",
        "OpenDate": "17/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3184",
        "TokenNumber": "H136597",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3185",
        "TokenNumber": "H136599",
        "OpenDate": "17/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3186",
        "TokenNumber": "H136601",
        "OpenDate": "17/03/2020",
        "CloseDate": "21/03/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3187",
        "TokenNumber": "H136602",
        "OpenDate": "17/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3188",
        "TokenNumber": "H136603",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3189",
        "TokenNumber": "H136606",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3190",
        "TokenNumber": "H136607",
        "OpenDate": "17/03/2020",
        "CloseDate": "18/03/2020",
        "CompletionTime": "1",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3191",
        "TokenNumber": "H136609",
        "OpenDate": "17/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3192",
        "TokenNumber": "H136615",
        "OpenDate": "18/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3193",
        "TokenNumber": "H136617",
        "OpenDate": "18/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "16",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3194",
        "TokenNumber": "H136618",
        "OpenDate": "18/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3195",
        "TokenNumber": "H136620",
        "OpenDate": "18/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "21",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3196",
        "TokenNumber": "H136622",
        "OpenDate": "18/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "26",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3197",
        "TokenNumber": "H136623",
        "OpenDate": "18/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3198",
        "TokenNumber": "H136624",
        "OpenDate": "18/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "21",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3199",
        "TokenNumber": "H136625",
        "OpenDate": "18/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "22",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3200",
        "TokenNumber": "H136628",
        "OpenDate": "18/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3201",
        "TokenNumber": "H136634",
        "OpenDate": "18/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3202",
        "TokenNumber": "H136636",
        "OpenDate": "18/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3203",
        "TokenNumber": "H136637",
        "OpenDate": "18/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3204",
        "TokenNumber": "H136638",
        "OpenDate": "18/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "21",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3205",
        "TokenNumber": "H136639",
        "OpenDate": "18/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3206",
        "TokenNumber": "H136640",
        "OpenDate": "18/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3207",
        "TokenNumber": "H136641",
        "OpenDate": "18/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "28",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3208",
        "TokenNumber": "H136644",
        "OpenDate": "18/03/2020",
        "CloseDate": "20/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3211",
        "TokenNumber": "H136648",
        "OpenDate": "18/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3212",
        "TokenNumber": "H136651",
        "OpenDate": "18/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3219",
        "TokenNumber": "H136664",
        "OpenDate": "18/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3220",
        "TokenNumber": "H136665",
        "OpenDate": "18/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3221",
        "TokenNumber": "H136666",
        "OpenDate": "18/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3224",
        "TokenNumber": "H136670",
        "OpenDate": "18/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3225",
        "TokenNumber": "H136672",
        "OpenDate": "18/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3227",
        "TokenNumber": "H136677",
        "OpenDate": "18/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3228",
        "TokenNumber": "H136680",
        "OpenDate": "18/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3229",
        "TokenNumber": "H136681",
        "OpenDate": "18/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3230",
        "TokenNumber": "H136684",
        "OpenDate": "18/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3231",
        "TokenNumber": "H136683",
        "OpenDate": "18/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3232",
        "TokenNumber": "H136685",
        "OpenDate": "18/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3233",
        "TokenNumber": "H136686",
        "OpenDate": "18/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3234",
        "TokenNumber": "H136687",
        "OpenDate": "18/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3235",
        "TokenNumber": "H136688",
        "OpenDate": "18/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "28",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3236",
        "TokenNumber": "H136689",
        "OpenDate": "18/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3237",
        "TokenNumber": "H136690",
        "OpenDate": "18/03/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3238",
        "TokenNumber": "H136692",
        "OpenDate": "18/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "28",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3239",
        "TokenNumber": "H136693",
        "OpenDate": "18/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3241",
        "TokenNumber": "H136695",
        "OpenDate": "18/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3244",
        "TokenNumber": "H136671",
        "OpenDate": "19/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "34",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3245",
        "TokenNumber": "H136697",
        "OpenDate": "19/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3246",
        "TokenNumber": "H136698",
        "OpenDate": "19/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3247",
        "TokenNumber": "H136701",
        "OpenDate": "19/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3249",
        "TokenNumber": "H136705",
        "OpenDate": "19/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3250",
        "TokenNumber": "H136709",
        "OpenDate": "19/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3251",
        "TokenNumber": "H136713",
        "OpenDate": "19/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3253",
        "TokenNumber": "H136715",
        "OpenDate": "19/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3254",
        "TokenNumber": "H136717",
        "OpenDate": "19/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3255",
        "TokenNumber": "H136719",
        "OpenDate": "19/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3256",
        "TokenNumber": "H136721",
        "OpenDate": "19/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3257",
        "TokenNumber": "H136724",
        "OpenDate": "19/03/2020",
        "CloseDate": "19/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3259",
        "TokenNumber": "H136727",
        "OpenDate": "19/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3260",
        "TokenNumber": "H136730",
        "OpenDate": "19/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3261",
        "TokenNumber": "H136731",
        "OpenDate": "19/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3262",
        "TokenNumber": "H136732",
        "OpenDate": "19/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3263",
        "TokenNumber": "H136735",
        "OpenDate": "19/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "20",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3264",
        "TokenNumber": "H136737",
        "OpenDate": "19/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3265",
        "TokenNumber": "H136740",
        "OpenDate": "19/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3266",
        "TokenNumber": "H136742",
        "OpenDate": "19/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3267",
        "TokenNumber": "H136745",
        "OpenDate": "19/03/2020",
        "CloseDate": "23/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3268",
        "TokenNumber": "H136746",
        "OpenDate": "19/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3269",
        "TokenNumber": "H136747",
        "OpenDate": "19/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3270",
        "TokenNumber": "H136748",
        "OpenDate": "19/03/2020",
        "CloseDate": "21/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3271",
        "TokenNumber": "H136749",
        "OpenDate": "19/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3272",
        "TokenNumber": "H136750",
        "OpenDate": "19/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3273",
        "TokenNumber": "H136752",
        "OpenDate": "19/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3274",
        "TokenNumber": "H136753",
        "OpenDate": "19/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "25",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3275",
        "TokenNumber": "H136756",
        "OpenDate": "19/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3276",
        "TokenNumber": "H136757",
        "OpenDate": "19/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3277",
        "TokenNumber": "H136758",
        "OpenDate": "19/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3278",
        "TokenNumber": "H136760",
        "OpenDate": "19/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3279",
        "TokenNumber": "H136761",
        "OpenDate": "20/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3280",
        "TokenNumber": "H136762",
        "OpenDate": "20/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "15",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3281",
        "TokenNumber": "H136328",
        "OpenDate": "20/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3282",
        "TokenNumber": "H136764",
        "OpenDate": "20/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3283",
        "TokenNumber": "H136766",
        "OpenDate": "20/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "14",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3284",
        "TokenNumber": "H136767",
        "OpenDate": "20/03/2020",
        "CloseDate": "21/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3285",
        "TokenNumber": "H136772",
        "OpenDate": "20/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3286",
        "TokenNumber": "H136769",
        "OpenDate": "20/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3287",
        "TokenNumber": "H136771",
        "OpenDate": "20/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3288",
        "TokenNumber": "H136770",
        "OpenDate": "20/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3289",
        "TokenNumber": "H136773",
        "OpenDate": "20/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3290",
        "TokenNumber": "H136775",
        "OpenDate": "20/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3291",
        "TokenNumber": "H136776",
        "OpenDate": "20/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3292",
        "TokenNumber": "H136778",
        "OpenDate": "20/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3293",
        "TokenNumber": "H136779",
        "OpenDate": "20/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3295",
        "TokenNumber": "H136781",
        "OpenDate": "20/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3296",
        "TokenNumber": "H136784",
        "OpenDate": "20/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3297",
        "TokenNumber": "H136788",
        "OpenDate": "20/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3298",
        "TokenNumber": "H136789",
        "OpenDate": "20/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3299",
        "TokenNumber": "H136790",
        "OpenDate": "20/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3300",
        "TokenNumber": "H136791",
        "OpenDate": "20/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "19",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3301",
        "TokenNumber": "H136792",
        "OpenDate": "20/03/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3302",
        "TokenNumber": "H136793",
        "OpenDate": "20/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3303",
        "TokenNumber": "H136794",
        "OpenDate": "20/03/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "46",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3304",
        "TokenNumber": "H136795",
        "OpenDate": "20/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3305",
        "TokenNumber": "H136796",
        "OpenDate": "20/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "18",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3306",
        "TokenNumber": "H136798",
        "OpenDate": "20/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3307",
        "TokenNumber": "H136801",
        "OpenDate": "20/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "10",
        "Subject": "Low Water Pressure",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3308",
        "TokenNumber": "H136802",
        "OpenDate": "20/03/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3309",
        "TokenNumber": "H136803",
        "OpenDate": "20/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3310",
        "TokenNumber": "H136804",
        "OpenDate": "20/03/2020",
        "CloseDate": "17/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3311",
        "TokenNumber": "H136805",
        "OpenDate": "20/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3312",
        "TokenNumber": "H136807",
        "OpenDate": "20/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3313",
        "TokenNumber": "H136808",
        "OpenDate": "20/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3315",
        "TokenNumber": "H136813",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3316",
        "TokenNumber": "H136814",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3317",
        "TokenNumber": "H136819",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3318",
        "TokenNumber": "H136821",
        "OpenDate": "21/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "26",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3319",
        "TokenNumber": "H136818",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3320",
        "TokenNumber": "H136822",
        "OpenDate": "21/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3321",
        "TokenNumber": "H136824",
        "OpenDate": "21/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3322",
        "TokenNumber": "H136823",
        "OpenDate": "21/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3323",
        "TokenNumber": "H136825",
        "OpenDate": "21/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3324",
        "TokenNumber": "H136826",
        "OpenDate": "21/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3325",
        "TokenNumber": "H136828",
        "OpenDate": "21/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3326",
        "TokenNumber": "H136829",
        "OpenDate": "21/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3327",
        "TokenNumber": "H136832",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3328",
        "TokenNumber": "H136833",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3329",
        "TokenNumber": "H136837",
        "OpenDate": "21/03/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3330",
        "TokenNumber": "H136838",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3331",
        "TokenNumber": "H136839",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3333",
        "TokenNumber": "H136842",
        "OpenDate": "21/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3334",
        "TokenNumber": "H136843",
        "OpenDate": "21/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3335",
        "TokenNumber": "H136846",
        "OpenDate": "21/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3336",
        "TokenNumber": "H136847",
        "OpenDate": "21/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "33",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3337",
        "TokenNumber": "H136848",
        "OpenDate": "21/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "25",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3338",
        "TokenNumber": "H136850",
        "OpenDate": "21/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3339",
        "TokenNumber": "H136851",
        "OpenDate": "21/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3340",
        "TokenNumber": "H136854",
        "OpenDate": "21/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3341",
        "TokenNumber": "H136855",
        "OpenDate": "21/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3342",
        "TokenNumber": "H136856",
        "OpenDate": "21/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3343",
        "TokenNumber": "H136858",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3344",
        "TokenNumber": "H136861",
        "OpenDate": "21/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "26",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3345",
        "TokenNumber": "H136862",
        "OpenDate": "21/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "13",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3348",
        "TokenNumber": "H136872",
        "OpenDate": "21/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3349",
        "TokenNumber": "H136873",
        "OpenDate": "21/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3350",
        "TokenNumber": "H136875",
        "OpenDate": "21/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3351",
        "TokenNumber": "H136876",
        "OpenDate": "21/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3352",
        "TokenNumber": "H136877",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3353",
        "TokenNumber": "H136878",
        "OpenDate": "21/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3355",
        "TokenNumber": "H136882",
        "OpenDate": "21/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "11",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3356",
        "TokenNumber": "H136883",
        "OpenDate": "21/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "9",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3357",
        "TokenNumber": "H136885",
        "OpenDate": "21/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3358",
        "TokenNumber": "H136886",
        "OpenDate": "22/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "32",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3359",
        "TokenNumber": "H136887",
        "OpenDate": "22/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3360",
        "TokenNumber": "H136889",
        "OpenDate": "22/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "32",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3361",
        "TokenNumber": "H136888",
        "OpenDate": "22/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "32",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3362",
        "TokenNumber": "H136890",
        "OpenDate": "22/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "32",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3363",
        "TokenNumber": "H136892",
        "OpenDate": "22/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3364",
        "TokenNumber": "H136884",
        "OpenDate": "22/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3365",
        "TokenNumber": "H136894",
        "OpenDate": "22/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3366",
        "TokenNumber": "H136895",
        "OpenDate": "22/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3367",
        "TokenNumber": "H136896",
        "OpenDate": "22/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3368",
        "TokenNumber": "H136897",
        "OpenDate": "22/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3369",
        "TokenNumber": "H136899",
        "OpenDate": "22/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3370",
        "TokenNumber": "H136900",
        "OpenDate": "22/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3371",
        "TokenNumber": "H136905",
        "OpenDate": "22/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "17",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3372",
        "TokenNumber": "H136904",
        "OpenDate": "22/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3373",
        "TokenNumber": "H136907",
        "OpenDate": "22/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3374",
        "TokenNumber": "H136908",
        "OpenDate": "22/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3375",
        "TokenNumber": "H136910",
        "OpenDate": "22/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3376",
        "TokenNumber": "H136911",
        "OpenDate": "22/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3377",
        "TokenNumber": "H136912",
        "OpenDate": "22/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3378",
        "TokenNumber": "H136914",
        "OpenDate": "22/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3379",
        "TokenNumber": "H136915",
        "OpenDate": "22/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3380",
        "TokenNumber": "H136917",
        "OpenDate": "22/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "8",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3381",
        "TokenNumber": "H136920",
        "OpenDate": "22/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3383",
        "TokenNumber": "H136925",
        "OpenDate": "23/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3385",
        "TokenNumber": "H136927",
        "OpenDate": "23/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3387",
        "TokenNumber": "H136930",
        "OpenDate": "23/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3389",
        "TokenNumber": "H136934",
        "OpenDate": "23/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3390",
        "TokenNumber": "H136940",
        "OpenDate": "23/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3391",
        "TokenNumber": "H136944",
        "OpenDate": "23/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3392",
        "TokenNumber": "H136943",
        "OpenDate": "23/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3393",
        "TokenNumber": "H136945",
        "OpenDate": "23/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "16",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3394",
        "TokenNumber": "H136946",
        "OpenDate": "23/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3395",
        "TokenNumber": "H136947",
        "OpenDate": "23/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3396",
        "TokenNumber": "H136948",
        "OpenDate": "23/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "10",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3397",
        "TokenNumber": "H136950",
        "OpenDate": "23/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3398",
        "TokenNumber": "H136956",
        "OpenDate": "23/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "23",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3399",
        "TokenNumber": "H136954",
        "OpenDate": "23/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "23",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3402",
        "TokenNumber": "H136970",
        "OpenDate": "23/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "23",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3404",
        "TokenNumber": "H136977",
        "OpenDate": "23/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3405",
        "TokenNumber": "H136979",
        "OpenDate": "23/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3406",
        "TokenNumber": "H136980",
        "OpenDate": "23/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3407",
        "TokenNumber": "H136981",
        "OpenDate": "23/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3408",
        "TokenNumber": "H136983",
        "OpenDate": "23/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "16",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3409",
        "TokenNumber": "H136984",
        "OpenDate": "23/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3410",
        "TokenNumber": "H136986",
        "OpenDate": "23/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3412",
        "TokenNumber": "H136992",
        "OpenDate": "24/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3413",
        "TokenNumber": "H136994",
        "OpenDate": "24/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3415",
        "TokenNumber": "H136998",
        "OpenDate": "24/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3416",
        "TokenNumber": "H137000",
        "OpenDate": "24/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3417",
        "TokenNumber": "H137001",
        "OpenDate": "24/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3418",
        "TokenNumber": "H137003",
        "OpenDate": "24/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3419",
        "TokenNumber": "H137005",
        "OpenDate": "24/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "7",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3420",
        "TokenNumber": "H137004",
        "OpenDate": "24/03/2020",
        "CloseDate": "24/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3421",
        "TokenNumber": "H137006",
        "OpenDate": "24/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3422",
        "TokenNumber": "H137014",
        "OpenDate": "24/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "15",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3424",
        "TokenNumber": "H137024",
        "OpenDate": "24/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "20",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3425",
        "TokenNumber": "H137032",
        "OpenDate": "24/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3426",
        "TokenNumber": "H137035",
        "OpenDate": "24/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "14",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3427",
        "TokenNumber": "H137036",
        "OpenDate": "24/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3428",
        "TokenNumber": "H137037",
        "OpenDate": "24/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3429",
        "TokenNumber": "H137038",
        "OpenDate": "24/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "16",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3430",
        "TokenNumber": "H137039",
        "OpenDate": "24/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3431",
        "TokenNumber": "H137041",
        "OpenDate": "24/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3432",
        "TokenNumber": "H137043",
        "OpenDate": "24/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "15",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3433",
        "TokenNumber": "H137047",
        "OpenDate": "24/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3436",
        "TokenNumber": "H137050",
        "OpenDate": "24/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3438",
        "TokenNumber": "H137054",
        "OpenDate": "24/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3439",
        "TokenNumber": "H137057",
        "OpenDate": "25/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3440",
        "TokenNumber": "H137058",
        "OpenDate": "25/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3441",
        "TokenNumber": "H137060",
        "OpenDate": "25/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3442",
        "TokenNumber": "H137063",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3443",
        "TokenNumber": "H137064",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3444",
        "TokenNumber": "H137066",
        "OpenDate": "25/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3445",
        "TokenNumber": "H137068",
        "OpenDate": "25/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3446",
        "TokenNumber": "H137070",
        "OpenDate": "25/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3447",
        "TokenNumber": "H137074",
        "OpenDate": "25/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3448",
        "TokenNumber": "H137079",
        "OpenDate": "25/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3449",
        "TokenNumber": "H137080",
        "OpenDate": "25/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "9",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3450",
        "TokenNumber": "H137082",
        "OpenDate": "25/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3451",
        "TokenNumber": "H137084",
        "OpenDate": "25/03/2020",
        "CloseDate": "25/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3452",
        "TokenNumber": "H137087",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3453",
        "TokenNumber": "H137090",
        "OpenDate": "25/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "6",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3454",
        "TokenNumber": "H137089",
        "OpenDate": "25/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3455",
        "TokenNumber": "H137091",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3456",
        "TokenNumber": "H137096",
        "OpenDate": "25/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3457",
        "TokenNumber": "H137104",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3458",
        "TokenNumber": "H137106",
        "OpenDate": "25/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "14",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3459",
        "TokenNumber": "H137108",
        "OpenDate": "25/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3460",
        "TokenNumber": "H137110",
        "OpenDate": "25/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3461",
        "TokenNumber": "H137109",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3462",
        "TokenNumber": "H137113",
        "OpenDate": "25/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "5",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3464",
        "TokenNumber": "H137121",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3466",
        "TokenNumber": "H137126",
        "OpenDate": "25/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3467",
        "TokenNumber": "H137132",
        "OpenDate": "25/03/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3468",
        "TokenNumber": "H137133",
        "OpenDate": "25/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3469",
        "TokenNumber": "H137137",
        "OpenDate": "25/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3470",
        "TokenNumber": "H137140",
        "OpenDate": "25/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "19",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3471",
        "TokenNumber": "H137143",
        "OpenDate": "25/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3472",
        "TokenNumber": "H137149",
        "OpenDate": "25/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3473",
        "TokenNumber": "H137150",
        "OpenDate": "25/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "19",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3474",
        "TokenNumber": "H137154",
        "OpenDate": "26/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3475",
        "TokenNumber": "H137157",
        "OpenDate": "26/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3476",
        "TokenNumber": "H137158",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3477",
        "TokenNumber": "H137163",
        "OpenDate": "26/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "6",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3478",
        "TokenNumber": "H137164",
        "OpenDate": "26/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3479",
        "TokenNumber": "H137166",
        "OpenDate": "26/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3480",
        "TokenNumber": "H137169",
        "OpenDate": "26/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3481",
        "TokenNumber": "H137171",
        "OpenDate": "26/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "0",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3482",
        "TokenNumber": "H137173",
        "OpenDate": "26/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3483",
        "TokenNumber": "H137175",
        "OpenDate": "26/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "4",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3484",
        "TokenNumber": "H137176",
        "OpenDate": "26/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3485",
        "TokenNumber": "H137178",
        "OpenDate": "26/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "0",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3486",
        "TokenNumber": "H137179",
        "OpenDate": "26/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "0",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3487",
        "TokenNumber": "H137181",
        "OpenDate": "26/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3488",
        "TokenNumber": "H137186",
        "OpenDate": "26/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3489",
        "TokenNumber": "H137188",
        "OpenDate": "26/03/2020",
        "CloseDate": "26/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3490",
        "TokenNumber": "H137190",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "1",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3492",
        "TokenNumber": "H137196",
        "OpenDate": "26/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3493",
        "TokenNumber": "H137194",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3494",
        "TokenNumber": "H137197",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3495",
        "TokenNumber": "H137198",
        "OpenDate": "26/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3496",
        "TokenNumber": "H137199",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3497",
        "TokenNumber": "H137201",
        "OpenDate": "26/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3498",
        "TokenNumber": "H137210",
        "OpenDate": "26/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3499",
        "TokenNumber": "H137214",
        "OpenDate": "26/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "18",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3500",
        "TokenNumber": "H137218",
        "OpenDate": "26/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3503",
        "TokenNumber": "H137222",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "32",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3504",
        "TokenNumber": "H137226",
        "OpenDate": "26/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3505",
        "TokenNumber": "H137227",
        "OpenDate": "26/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3506",
        "TokenNumber": "H137230",
        "OpenDate": "26/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3507",
        "TokenNumber": "H137247",
        "OpenDate": "26/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3508",
        "TokenNumber": "H137252",
        "OpenDate": "26/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3509",
        "TokenNumber": "H137253",
        "OpenDate": "26/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3510",
        "TokenNumber": "H137254",
        "OpenDate": "26/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "13",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3511",
        "TokenNumber": "H137259",
        "OpenDate": "26/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3512",
        "TokenNumber": "H137263",
        "OpenDate": "26/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3513",
        "TokenNumber": "H137264",
        "OpenDate": "26/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3514",
        "TokenNumber": "H137265",
        "OpenDate": "27/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "13",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3515",
        "TokenNumber": "H137266",
        "OpenDate": "27/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3516",
        "TokenNumber": "H137268",
        "OpenDate": "27/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3517",
        "TokenNumber": "H137271",
        "OpenDate": "27/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3519",
        "TokenNumber": "H137280",
        "OpenDate": "27/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3520",
        "TokenNumber": "H137282",
        "OpenDate": "27/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3521",
        "TokenNumber": "H137283",
        "OpenDate": "27/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3524",
        "TokenNumber": "H137289",
        "OpenDate": "27/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3525",
        "TokenNumber": "H137290",
        "OpenDate": "27/03/2020",
        "CloseDate": "27/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3526",
        "TokenNumber": "H137287",
        "OpenDate": "27/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3527",
        "TokenNumber": "H137292",
        "OpenDate": "27/03/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3528",
        "TokenNumber": "H137291",
        "OpenDate": "27/03/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "31",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3529",
        "TokenNumber": "H137297",
        "OpenDate": "27/03/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3530",
        "TokenNumber": "H137304",
        "OpenDate": "27/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3531",
        "TokenNumber": "H137307",
        "OpenDate": "27/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "11",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3533",
        "TokenNumber": "H137313",
        "OpenDate": "27/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3535",
        "TokenNumber": "H137315",
        "OpenDate": "27/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3536",
        "TokenNumber": "H137317",
        "OpenDate": "27/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3537",
        "TokenNumber": "H137318",
        "OpenDate": "27/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3540",
        "TokenNumber": "H137326",
        "OpenDate": "27/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3541",
        "TokenNumber": "H137328",
        "OpenDate": "27/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3542",
        "TokenNumber": "H137337",
        "OpenDate": "27/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3543",
        "TokenNumber": "H137343",
        "OpenDate": "27/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3544",
        "TokenNumber": "H137348",
        "OpenDate": "27/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3545",
        "TokenNumber": "H137350",
        "OpenDate": "27/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3546",
        "TokenNumber": "H137351",
        "OpenDate": "27/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3547",
        "TokenNumber": "H137353",
        "OpenDate": "27/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3548",
        "TokenNumber": "H137354",
        "OpenDate": "27/03/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "31",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3551",
        "TokenNumber": "H137359",
        "OpenDate": "28/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3552",
        "TokenNumber": "H137364",
        "OpenDate": "28/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3553",
        "TokenNumber": "H137365",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3554",
        "TokenNumber": "H137367",
        "OpenDate": "28/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3555",
        "TokenNumber": "H137369",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3556",
        "TokenNumber": "H137372",
        "OpenDate": "28/03/2020",
        "CloseDate": "28/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3557",
        "TokenNumber": "H137377",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3558",
        "TokenNumber": "H137380",
        "OpenDate": "28/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3559",
        "TokenNumber": "H137381",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3560",
        "TokenNumber": "H137382",
        "OpenDate": "28/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3562",
        "TokenNumber": "H137385",
        "OpenDate": "28/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3563",
        "TokenNumber": "H137387",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3564",
        "TokenNumber": "H137397",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3569",
        "TokenNumber": "H137418",
        "OpenDate": "28/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3570",
        "TokenNumber": "H137419",
        "OpenDate": "28/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3571",
        "TokenNumber": "H137421",
        "OpenDate": "28/03/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "27",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3572",
        "TokenNumber": "H137425",
        "OpenDate": "28/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3573",
        "TokenNumber": "H137427",
        "OpenDate": "28/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "18",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3574",
        "TokenNumber": "H137428",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3575",
        "TokenNumber": "H137429",
        "OpenDate": "28/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3576",
        "TokenNumber": "H137430",
        "OpenDate": "28/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3577",
        "TokenNumber": "H137431",
        "OpenDate": "28/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3578",
        "TokenNumber": "H137434",
        "OpenDate": "28/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3579",
        "TokenNumber": "H137436",
        "OpenDate": "28/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3583",
        "TokenNumber": "H137450",
        "OpenDate": "28/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3584",
        "TokenNumber": "H137451",
        "OpenDate": "28/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3585",
        "TokenNumber": "H137452",
        "OpenDate": "28/03/2020",
        "CloseDate": "06/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3586",
        "TokenNumber": "H137453",
        "OpenDate": "28/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3588",
        "TokenNumber": "H137458",
        "OpenDate": "28/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3589",
        "TokenNumber": "H137465",
        "OpenDate": "29/03/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3590",
        "TokenNumber": "H137466",
        "OpenDate": "29/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3592",
        "TokenNumber": "H137471",
        "OpenDate": "29/03/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3593",
        "TokenNumber": "H137472",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3594",
        "TokenNumber": "H137473",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3595",
        "TokenNumber": "H137476",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3596",
        "TokenNumber": "H137477",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3597",
        "TokenNumber": "H137479",
        "OpenDate": "29/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3599",
        "TokenNumber": "H137481",
        "OpenDate": "29/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3600",
        "TokenNumber": "H137485",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3601",
        "TokenNumber": "H137488",
        "OpenDate": "29/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3602",
        "TokenNumber": "H137499",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3603",
        "TokenNumber": "H137506",
        "OpenDate": "29/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "11",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3604",
        "TokenNumber": "H137507",
        "OpenDate": "29/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3605",
        "TokenNumber": "H137510",
        "OpenDate": "29/03/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3606",
        "TokenNumber": "H137511",
        "OpenDate": "29/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "25",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3607",
        "TokenNumber": "H137512",
        "OpenDate": "29/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "9",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3608",
        "TokenNumber": "H137513",
        "OpenDate": "29/03/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3609",
        "TokenNumber": "H137518",
        "OpenDate": "29/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "4",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3610",
        "TokenNumber": "H137520",
        "OpenDate": "30/03/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "28",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3611",
        "TokenNumber": "H137521",
        "OpenDate": "30/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3612",
        "TokenNumber": "H137523",
        "OpenDate": "30/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "0",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3613",
        "TokenNumber": "H137525",
        "OpenDate": "30/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3614",
        "TokenNumber": "H137529",
        "OpenDate": "30/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3615",
        "TokenNumber": "H137530",
        "OpenDate": "30/03/2020",
        "CloseDate": "30/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3616",
        "TokenNumber": "H137531",
        "OpenDate": "30/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3619",
        "TokenNumber": "H137537",
        "OpenDate": "30/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3620",
        "TokenNumber": "H137540",
        "OpenDate": "30/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3621",
        "TokenNumber": "H137541",
        "OpenDate": "30/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3622",
        "TokenNumber": "H137543",
        "OpenDate": "30/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3624",
        "TokenNumber": "H137559",
        "OpenDate": "30/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3625",
        "TokenNumber": "H137562",
        "OpenDate": "30/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3626",
        "TokenNumber": "H137563",
        "OpenDate": "30/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3628",
        "TokenNumber": "H137566",
        "OpenDate": "30/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3629",
        "TokenNumber": "H137567",
        "OpenDate": "30/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3630",
        "TokenNumber": "H137573",
        "OpenDate": "30/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3631",
        "TokenNumber": "H137577",
        "OpenDate": "30/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3632",
        "TokenNumber": "H137580",
        "OpenDate": "30/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3633",
        "TokenNumber": "H137588",
        "OpenDate": "30/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3634",
        "TokenNumber": "H137589",
        "OpenDate": "30/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3635",
        "TokenNumber": "H137593",
        "OpenDate": "31/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3636",
        "TokenNumber": "H137594",
        "OpenDate": "31/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3637",
        "TokenNumber": "H137598",
        "OpenDate": "31/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3638",
        "TokenNumber": "H137599",
        "OpenDate": "31/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3639",
        "TokenNumber": "H137603",
        "OpenDate": "31/03/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "10",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3642",
        "TokenNumber": "H137607",
        "OpenDate": "31/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3643",
        "TokenNumber": "H137609",
        "OpenDate": "31/03/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3645",
        "TokenNumber": "H137614",
        "OpenDate": "31/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3646",
        "TokenNumber": "H137615",
        "OpenDate": "31/03/2020",
        "CloseDate": "31/03/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3647",
        "TokenNumber": "H137619",
        "OpenDate": "31/03/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3648",
        "TokenNumber": "H137621",
        "OpenDate": "31/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3649",
        "TokenNumber": "H137623",
        "OpenDate": "31/03/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "27",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3650",
        "TokenNumber": "H137626",
        "OpenDate": "31/03/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3651",
        "TokenNumber": "H137629",
        "OpenDate": "31/03/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3653",
        "TokenNumber": "H137636",
        "OpenDate": "31/03/2020",
        "CloseDate": "01/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3655",
        "TokenNumber": "H137638",
        "OpenDate": "31/03/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3657",
        "TokenNumber": "H137643",
        "OpenDate": "01/04/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3658",
        "TokenNumber": "H137644",
        "OpenDate": "01/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3659",
        "TokenNumber": "H137648",
        "OpenDate": "01/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3661",
        "TokenNumber": "H137650",
        "OpenDate": "01/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "8",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3662",
        "TokenNumber": "H137652",
        "OpenDate": "01/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3663",
        "TokenNumber": "H137655",
        "OpenDate": "01/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3665",
        "TokenNumber": "H137660",
        "OpenDate": "01/04/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3667",
        "TokenNumber": "H137671",
        "OpenDate": "01/04/2020",
        "CloseDate": "02/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3668",
        "TokenNumber": "H137672",
        "OpenDate": "01/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3669",
        "TokenNumber": "H137674",
        "OpenDate": "01/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3670",
        "TokenNumber": "H137680",
        "OpenDate": "01/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3672",
        "TokenNumber": "H137683",
        "OpenDate": "01/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3673",
        "TokenNumber": "H137687",
        "OpenDate": "01/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3674",
        "TokenNumber": "H137688",
        "OpenDate": "01/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3675",
        "TokenNumber": "H137691",
        "OpenDate": "01/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3676",
        "TokenNumber": "H137694",
        "OpenDate": "01/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3677",
        "TokenNumber": "H137695",
        "OpenDate": "01/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3678",
        "TokenNumber": "H137699",
        "OpenDate": "02/04/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3681",
        "TokenNumber": "H137705",
        "OpenDate": "02/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3683",
        "TokenNumber": "H137709",
        "OpenDate": "02/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3684",
        "TokenNumber": "H137712",
        "OpenDate": "02/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3685",
        "TokenNumber": "H137715",
        "OpenDate": "02/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "25",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3686",
        "TokenNumber": "H137717",
        "OpenDate": "02/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3687",
        "TokenNumber": "H137719",
        "OpenDate": "02/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "11",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3688",
        "TokenNumber": "H137722",
        "OpenDate": "02/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3693",
        "TokenNumber": "H137730",
        "OpenDate": "02/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3694",
        "TokenNumber": "H137731",
        "OpenDate": "02/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3695",
        "TokenNumber": "H137733",
        "OpenDate": "02/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3696",
        "TokenNumber": "H137734",
        "OpenDate": "02/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3697",
        "TokenNumber": "H137737",
        "OpenDate": "02/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "24",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3698",
        "TokenNumber": "H137738",
        "OpenDate": "02/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3700",
        "TokenNumber": "H137744",
        "OpenDate": "02/04/2020",
        "CloseDate": "05/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3701",
        "TokenNumber": "H137749",
        "OpenDate": "02/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3702",
        "TokenNumber": "H137750",
        "OpenDate": "02/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3704",
        "TokenNumber": "H137753",
        "OpenDate": "03/04/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3705",
        "TokenNumber": "H137754",
        "OpenDate": "03/04/2020",
        "CloseDate": "03/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3706",
        "TokenNumber": "H137755",
        "OpenDate": "03/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3708",
        "TokenNumber": "H137762",
        "OpenDate": "03/04/2020",
        "CloseDate": "04/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3709",
        "TokenNumber": "H137764",
        "OpenDate": "03/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3710",
        "TokenNumber": "H137766",
        "OpenDate": "03/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3712",
        "TokenNumber": "H137768",
        "OpenDate": "03/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3713",
        "TokenNumber": "H137770",
        "OpenDate": "03/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3715",
        "TokenNumber": "H137774",
        "OpenDate": "03/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3716",
        "TokenNumber": "H137775",
        "OpenDate": "03/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3721",
        "TokenNumber": "H137786",
        "OpenDate": "03/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "24",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3722",
        "TokenNumber": "H137789",
        "OpenDate": "03/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3723",
        "TokenNumber": "H137792",
        "OpenDate": "03/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3724",
        "TokenNumber": "H137794",
        "OpenDate": "03/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3725",
        "TokenNumber": "H137796",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3726",
        "TokenNumber": "H137799",
        "OpenDate": "04/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "31",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3727",
        "TokenNumber": "H137800",
        "OpenDate": "04/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "19",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3728",
        "TokenNumber": "H137801",
        "OpenDate": "04/04/2020",
        "CloseDate": "05/04/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3729",
        "TokenNumber": "H137804",
        "OpenDate": "04/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3730",
        "TokenNumber": "H137805",
        "OpenDate": "04/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "25",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3731",
        "TokenNumber": "H137812",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3732",
        "TokenNumber": "H137814",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3733",
        "TokenNumber": "H137813",
        "OpenDate": "04/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3734",
        "TokenNumber": "H137815",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3735",
        "TokenNumber": "H137816",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3737",
        "TokenNumber": "H137819",
        "OpenDate": "04/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3738",
        "TokenNumber": "H137820",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3739",
        "TokenNumber": "H137822",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3740",
        "TokenNumber": "H137823",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3741",
        "TokenNumber": "H137824",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3742",
        "TokenNumber": "H137825",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3743",
        "TokenNumber": "H137826",
        "OpenDate": "04/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3744",
        "TokenNumber": "H137827",
        "OpenDate": "04/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3745",
        "TokenNumber": "H137828",
        "OpenDate": "04/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3746",
        "TokenNumber": "H137830",
        "OpenDate": "05/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3747",
        "TokenNumber": "H137832",
        "OpenDate": "05/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "30",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3748",
        "TokenNumber": "H137833",
        "OpenDate": "05/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "8",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3749",
        "TokenNumber": "H137834",
        "OpenDate": "05/04/2020",
        "CloseDate": "05/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3751",
        "TokenNumber": "H137839",
        "OpenDate": "05/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3752",
        "TokenNumber": "H137843",
        "OpenDate": "05/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3753",
        "TokenNumber": "H137847",
        "OpenDate": "05/04/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3754",
        "TokenNumber": "H137849",
        "OpenDate": "05/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3755",
        "TokenNumber": "H137850",
        "OpenDate": "05/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "22",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3757",
        "TokenNumber": "H137858",
        "OpenDate": "05/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3758",
        "TokenNumber": "H137860",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3760",
        "TokenNumber": "H137862",
        "OpenDate": "06/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3761",
        "TokenNumber": "H137865",
        "OpenDate": "06/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3762",
        "TokenNumber": "H137867",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3763",
        "TokenNumber": "H137870",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3764",
        "TokenNumber": "H137871",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3765",
        "TokenNumber": "H137872",
        "OpenDate": "06/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3766",
        "TokenNumber": "H137873",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3767",
        "TokenNumber": "H137875",
        "OpenDate": "06/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3768",
        "TokenNumber": "H137881",
        "OpenDate": "06/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "18",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3770",
        "TokenNumber": "H137883",
        "OpenDate": "06/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3772",
        "TokenNumber": "H137887",
        "OpenDate": "06/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3773",
        "TokenNumber": "H137889",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3774",
        "TokenNumber": "H137891",
        "OpenDate": "06/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3775",
        "TokenNumber": "H137892",
        "OpenDate": "06/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3776",
        "TokenNumber": "H137895",
        "OpenDate": "06/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "17",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3777",
        "TokenNumber": "H137897",
        "OpenDate": "06/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3778",
        "TokenNumber": "H137898",
        "OpenDate": "07/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3780",
        "TokenNumber": "H137901",
        "OpenDate": "07/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3781",
        "TokenNumber": "H137903",
        "OpenDate": "07/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3782",
        "TokenNumber": "H137904",
        "OpenDate": "07/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3783",
        "TokenNumber": "H137905",
        "OpenDate": "07/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3784",
        "TokenNumber": "H137906",
        "OpenDate": "07/04/2020",
        "CloseDate": "07/04/2020",
        "CompletionTime": "0",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3785",
        "TokenNumber": "H137908",
        "OpenDate": "07/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3786",
        "TokenNumber": "H137909",
        "OpenDate": "07/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3787",
        "TokenNumber": "H137912",
        "OpenDate": "07/04/2020",
        "CloseDate": "10/04/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3788",
        "TokenNumber": "H137914",
        "OpenDate": "07/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3789",
        "TokenNumber": "H137916",
        "OpenDate": "07/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3790",
        "TokenNumber": "H137917",
        "OpenDate": "07/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3791",
        "TokenNumber": "H137918",
        "OpenDate": "07/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "4",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3792",
        "TokenNumber": "H137919",
        "OpenDate": "07/04/2020",
        "CloseDate": "08/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3795",
        "TokenNumber": "H137924",
        "OpenDate": "07/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3797",
        "TokenNumber": "H137931",
        "OpenDate": "07/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3798",
        "TokenNumber": "H137932",
        "OpenDate": "07/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "28",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3799",
        "TokenNumber": "H137934",
        "OpenDate": "07/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3800",
        "TokenNumber": "H137935",
        "OpenDate": "08/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3801",
        "TokenNumber": "H137936",
        "OpenDate": "08/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "3",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3802",
        "TokenNumber": "H137938",
        "OpenDate": "08/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3803",
        "TokenNumber": "H137939",
        "OpenDate": "08/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3804",
        "TokenNumber": "H137941",
        "OpenDate": "08/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3805",
        "TokenNumber": "H137944",
        "OpenDate": "08/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3806",
        "TokenNumber": "H137948",
        "OpenDate": "08/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "3807",
        "TokenNumber": "H137950",
        "OpenDate": "08/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3809",
        "TokenNumber": "H137956",
        "OpenDate": "08/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3810",
        "TokenNumber": "H137959",
        "OpenDate": "08/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3811",
        "TokenNumber": "H137960",
        "OpenDate": "08/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "26",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3812",
        "TokenNumber": "H137964",
        "OpenDate": "08/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3814",
        "TokenNumber": "H137971",
        "OpenDate": "08/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3816",
        "TokenNumber": "H137974",
        "OpenDate": "09/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3817",
        "TokenNumber": "H137976",
        "OpenDate": "09/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3818",
        "TokenNumber": "H137978",
        "OpenDate": "09/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "18",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3819",
        "TokenNumber": "H137982",
        "OpenDate": "09/04/2020",
        "CloseDate": "17/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3820",
        "TokenNumber": "H137987",
        "OpenDate": "09/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "18",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3822",
        "TokenNumber": "H137993",
        "OpenDate": "09/04/2020",
        "CloseDate": "09/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3823",
        "TokenNumber": "H137999",
        "OpenDate": "09/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3824",
        "TokenNumber": "H138002",
        "OpenDate": "09/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3825",
        "TokenNumber": "H138006",
        "OpenDate": "10/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3826",
        "TokenNumber": "H138008",
        "OpenDate": "10/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3827",
        "TokenNumber": "H138009",
        "OpenDate": "10/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3828",
        "TokenNumber": "H138011",
        "OpenDate": "10/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3829",
        "TokenNumber": "H138013",
        "OpenDate": "10/04/2020",
        "CloseDate": "19/04/2020",
        "CompletionTime": "9",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3830",
        "TokenNumber": "H138015",
        "OpenDate": "10/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3831",
        "TokenNumber": "H138016",
        "OpenDate": "10/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3832",
        "TokenNumber": "H138019",
        "OpenDate": "10/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3833",
        "TokenNumber": "H138023",
        "OpenDate": "10/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "5",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3834",
        "TokenNumber": "H138029",
        "OpenDate": "10/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3835",
        "TokenNumber": "H138030",
        "OpenDate": "10/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3836",
        "TokenNumber": "H138031",
        "OpenDate": "10/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "2",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3837",
        "TokenNumber": "H138035",
        "OpenDate": "10/04/2020",
        "CloseDate": "11/04/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3838",
        "TokenNumber": "H138036",
        "OpenDate": "10/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3839",
        "TokenNumber": "H138038",
        "OpenDate": "10/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "3",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3840",
        "TokenNumber": "H138039",
        "OpenDate": "10/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3841",
        "TokenNumber": "H138042",
        "OpenDate": "10/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "6",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3842",
        "TokenNumber": "H138045",
        "OpenDate": "10/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "23",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3843",
        "TokenNumber": "H138047",
        "OpenDate": "11/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "24",
        "Subject": "Street lights",
        "Stage": "REOPEN"
    },
    {
        "SrNo.": "3844",
        "TokenNumber": "H138048",
        "OpenDate": "11/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3845",
        "TokenNumber": "H138050",
        "OpenDate": "11/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3846",
        "TokenNumber": "H138051",
        "OpenDate": "11/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "23",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3847",
        "TokenNumber": "H138052",
        "OpenDate": "11/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "11",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3848",
        "TokenNumber": "H138053",
        "OpenDate": "11/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "2",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3849",
        "TokenNumber": "H138054",
        "OpenDate": "11/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3850",
        "TokenNumber": "H138056",
        "OpenDate": "11/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "22",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3851",
        "TokenNumber": "H138057",
        "OpenDate": "11/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3852",
        "TokenNumber": "H138058",
        "OpenDate": "11/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3853",
        "TokenNumber": "H138059",
        "OpenDate": "11/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "1",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3855",
        "TokenNumber": "H138068",
        "OpenDate": "11/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3856",
        "TokenNumber": "H138069",
        "OpenDate": "11/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3857",
        "TokenNumber": "H138071",
        "OpenDate": "11/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "12",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3858",
        "TokenNumber": "H138075",
        "OpenDate": "11/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3859",
        "TokenNumber": "H138079",
        "OpenDate": "11/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3860",
        "TokenNumber": "H138080",
        "OpenDate": "11/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3861",
        "TokenNumber": "H138082",
        "OpenDate": "11/04/2020",
        "CloseDate": "12/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3863",
        "TokenNumber": "H138085",
        "OpenDate": "11/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3864",
        "TokenNumber": "H138086",
        "OpenDate": "11/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3865",
        "TokenNumber": "H138088",
        "OpenDate": "11/04/2020",
        "CloseDate": "14/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3866",
        "TokenNumber": "H138090",
        "OpenDate": "11/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3867",
        "TokenNumber": "H138091",
        "OpenDate": "11/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "4",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3868",
        "TokenNumber": "H138093",
        "OpenDate": "12/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3869",
        "TokenNumber": "H138094",
        "OpenDate": "12/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3871",
        "TokenNumber": "H138095",
        "OpenDate": "12/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3872",
        "TokenNumber": "H138096",
        "OpenDate": "12/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3873",
        "TokenNumber": "H138097",
        "OpenDate": "12/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3874",
        "TokenNumber": "H138099",
        "OpenDate": "12/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3875",
        "TokenNumber": "H138100",
        "OpenDate": "12/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3876",
        "TokenNumber": "H138104",
        "OpenDate": "12/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3877",
        "TokenNumber": "H138105",
        "OpenDate": "12/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "17",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3878",
        "TokenNumber": "H138106",
        "OpenDate": "12/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3879",
        "TokenNumber": "H138108",
        "OpenDate": "12/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3880",
        "TokenNumber": "H138111",
        "OpenDate": "12/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3881",
        "TokenNumber": "H138116",
        "OpenDate": "12/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "15",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3882",
        "TokenNumber": "H138117",
        "OpenDate": "12/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "1",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3883",
        "TokenNumber": "H138118",
        "OpenDate": "12/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3884",
        "TokenNumber": "H138119",
        "OpenDate": "12/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3885",
        "TokenNumber": "H138121",
        "OpenDate": "12/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3886",
        "TokenNumber": "H138122",
        "OpenDate": "12/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "8",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3887",
        "TokenNumber": "H138123",
        "OpenDate": "12/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3888",
        "TokenNumber": "H138124",
        "OpenDate": "12/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "12",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3889",
        "TokenNumber": "H138126",
        "OpenDate": "13/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3890",
        "TokenNumber": "H138127",
        "OpenDate": "13/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "2",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3891",
        "TokenNumber": "H138131",
        "OpenDate": "13/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "21",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3892",
        "TokenNumber": "H138134",
        "OpenDate": "13/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "14",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3894",
        "TokenNumber": "H138138",
        "OpenDate": "13/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "21",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3895",
        "TokenNumber": "H138140",
        "OpenDate": "13/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3896",
        "TokenNumber": "H138139",
        "OpenDate": "13/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "2",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3898",
        "TokenNumber": "H138144",
        "OpenDate": "13/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3899",
        "TokenNumber": "H138146",
        "OpenDate": "13/04/2020",
        "CloseDate": "13/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3900",
        "TokenNumber": "H138147",
        "OpenDate": "13/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3901",
        "TokenNumber": "H138148",
        "OpenDate": "13/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3902",
        "TokenNumber": "H138149",
        "OpenDate": "13/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "21",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3903",
        "TokenNumber": "H138150",
        "OpenDate": "13/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3904",
        "TokenNumber": "H138151",
        "OpenDate": "13/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "21",
        "Subject": "Pot Holes",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3905",
        "TokenNumber": "H138152",
        "OpenDate": "13/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "21",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3907",
        "TokenNumber": "H138157",
        "OpenDate": "13/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "14",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3908",
        "TokenNumber": "H138159",
        "OpenDate": "13/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3909",
        "TokenNumber": "H138160",
        "OpenDate": "13/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3911",
        "TokenNumber": "H138162",
        "OpenDate": "13/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "10",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3913",
        "TokenNumber": "H138164",
        "OpenDate": "13/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3915",
        "TokenNumber": "H138169",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3916",
        "TokenNumber": "H138172",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3917",
        "TokenNumber": "H138173",
        "OpenDate": "14/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3918",
        "TokenNumber": "H138175",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3919",
        "TokenNumber": "H138176",
        "OpenDate": "14/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "13",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3920",
        "TokenNumber": "H138180",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3921",
        "TokenNumber": "H138181",
        "OpenDate": "14/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3922",
        "TokenNumber": "H138185",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3923",
        "TokenNumber": "H138186",
        "OpenDate": "14/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3924",
        "TokenNumber": "H138187",
        "OpenDate": "14/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "13",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3925",
        "TokenNumber": "H138188",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3926",
        "TokenNumber": "H138189",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3927",
        "TokenNumber": "H138190",
        "OpenDate": "14/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "15",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3928",
        "TokenNumber": "H138191",
        "OpenDate": "14/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "4",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3929",
        "TokenNumber": "H138193",
        "OpenDate": "14/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3930",
        "TokenNumber": "H138197",
        "OpenDate": "14/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "19",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3931",
        "TokenNumber": "H138198",
        "OpenDate": "14/04/2020",
        "CloseDate": "19/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3933",
        "TokenNumber": "H138202",
        "OpenDate": "15/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "15",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3934",
        "TokenNumber": "H138203",
        "OpenDate": "15/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3936",
        "TokenNumber": "H138206",
        "OpenDate": "15/04/2020",
        "CloseDate": "15/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3937",
        "TokenNumber": "H138210",
        "OpenDate": "15/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3938",
        "TokenNumber": "H138211",
        "OpenDate": "15/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3939",
        "TokenNumber": "H138195",
        "OpenDate": "15/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3941",
        "TokenNumber": "H138215",
        "OpenDate": "15/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3942",
        "TokenNumber": "H138216",
        "OpenDate": "15/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "20",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3943",
        "TokenNumber": "H138217",
        "OpenDate": "15/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "19",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3945",
        "TokenNumber": "H138224",
        "OpenDate": "15/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "1",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3946",
        "TokenNumber": "H138223",
        "OpenDate": "15/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3947",
        "TokenNumber": "H138227",
        "OpenDate": "15/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3948",
        "TokenNumber": "H138228",
        "OpenDate": "15/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "9",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3950",
        "TokenNumber": "H138231",
        "OpenDate": "15/04/2020",
        "CloseDate": "17/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3951",
        "TokenNumber": "H138233",
        "OpenDate": "15/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3952",
        "TokenNumber": "H138234",
        "OpenDate": "15/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "12",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3953",
        "TokenNumber": "H138235",
        "OpenDate": "15/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3954",
        "TokenNumber": "H138241",
        "OpenDate": "15/04/2020",
        "CloseDate": "16/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3957",
        "TokenNumber": "H138246",
        "OpenDate": "15/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3959",
        "TokenNumber": "H138252",
        "OpenDate": "15/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3960",
        "TokenNumber": "H138253",
        "OpenDate": "16/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "18",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3961",
        "TokenNumber": "H138254",
        "OpenDate": "16/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3962",
        "TokenNumber": "H138256",
        "OpenDate": "16/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3963",
        "TokenNumber": "H138258",
        "OpenDate": "16/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "11",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3964",
        "TokenNumber": "H138259",
        "OpenDate": "16/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3965",
        "TokenNumber": "H138260",
        "OpenDate": "16/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "4",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3967",
        "TokenNumber": "H138270",
        "OpenDate": "16/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3968",
        "TokenNumber": "H138275",
        "OpenDate": "16/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "18",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3969",
        "TokenNumber": "H138276",
        "OpenDate": "16/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3970",
        "TokenNumber": "H138284",
        "OpenDate": "16/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3971",
        "TokenNumber": "H138286",
        "OpenDate": "17/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3972",
        "TokenNumber": "H138287",
        "OpenDate": "17/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3974",
        "TokenNumber": "H138289",
        "OpenDate": "17/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "10",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3975",
        "TokenNumber": "H138290",
        "OpenDate": "17/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3976",
        "TokenNumber": "H138291",
        "OpenDate": "17/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3980",
        "TokenNumber": "H138300",
        "OpenDate": "17/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3981",
        "TokenNumber": "H138302",
        "OpenDate": "17/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3982",
        "TokenNumber": "H138304",
        "OpenDate": "17/04/2020",
        "CloseDate": "18/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3985",
        "TokenNumber": "H138312",
        "OpenDate": "17/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3987",
        "TokenNumber": "H138314",
        "OpenDate": "17/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3988",
        "TokenNumber": "H138315",
        "OpenDate": "17/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3989",
        "TokenNumber": "H138316",
        "OpenDate": "17/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "12",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3993",
        "TokenNumber": "H138325",
        "OpenDate": "17/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3995",
        "TokenNumber": "H138327",
        "OpenDate": "17/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3996",
        "TokenNumber": "H138331",
        "OpenDate": "18/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "12",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3997",
        "TokenNumber": "H138332",
        "OpenDate": "18/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "16",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3998",
        "TokenNumber": "H138333",
        "OpenDate": "18/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "3999",
        "TokenNumber": "H138335",
        "OpenDate": "18/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "3",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4000",
        "TokenNumber": "H138336",
        "OpenDate": "18/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "9",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4001",
        "TokenNumber": "H138338",
        "OpenDate": "18/04/2020",
        "CloseDate": "19/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4003",
        "TokenNumber": "H138346",
        "OpenDate": "18/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "17",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4004",
        "TokenNumber": "H138350",
        "OpenDate": "18/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4005",
        "TokenNumber": "H138347",
        "OpenDate": "18/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4006",
        "TokenNumber": "H138348",
        "OpenDate": "18/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4007",
        "TokenNumber": "H138352",
        "OpenDate": "18/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "9",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4008",
        "TokenNumber": "H138353",
        "OpenDate": "18/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4009",
        "TokenNumber": "H138354",
        "OpenDate": "18/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "8",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4010",
        "TokenNumber": "H138355",
        "OpenDate": "18/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4011",
        "TokenNumber": "H138356",
        "OpenDate": "18/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4012",
        "TokenNumber": "H138357",
        "OpenDate": "18/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "16",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4014",
        "TokenNumber": "H138359",
        "OpenDate": "18/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "8",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4015",
        "TokenNumber": "H138363",
        "OpenDate": "18/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4016",
        "TokenNumber": "H138364",
        "OpenDate": "18/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4017",
        "TokenNumber": "H138365",
        "OpenDate": "18/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4018",
        "TokenNumber": "H138366",
        "OpenDate": "18/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "9",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4020",
        "TokenNumber": "H138371",
        "OpenDate": "19/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "3",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4022",
        "TokenNumber": "H138375",
        "OpenDate": "19/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4023",
        "TokenNumber": "H138376",
        "OpenDate": "19/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4024",
        "TokenNumber": "H138377",
        "OpenDate": "19/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4025",
        "TokenNumber": "H138379",
        "OpenDate": "19/04/2020",
        "CloseDate": "20/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4026",
        "TokenNumber": "H138384",
        "OpenDate": "19/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4027",
        "TokenNumber": "H138385",
        "OpenDate": "19/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4028",
        "TokenNumber": "H138389",
        "OpenDate": "19/04/2020",
        "CloseDate": "28/04/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4029",
        "TokenNumber": "H138390",
        "OpenDate": "19/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "10",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4030",
        "TokenNumber": "H138391",
        "OpenDate": "19/04/2020",
        "CloseDate": "21/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4037",
        "TokenNumber": "H138403",
        "OpenDate": "20/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "14",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4038",
        "TokenNumber": "H138404",
        "OpenDate": "20/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4039",
        "TokenNumber": "H138405",
        "OpenDate": "20/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4040",
        "TokenNumber": "H138406",
        "OpenDate": "20/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4041",
        "TokenNumber": "H138408",
        "OpenDate": "20/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "10",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4042",
        "TokenNumber": "H138413",
        "OpenDate": "20/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4044",
        "TokenNumber": "H138416",
        "OpenDate": "20/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "14",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4045",
        "TokenNumber": "H138420",
        "OpenDate": "20/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4046",
        "TokenNumber": "H138419",
        "OpenDate": "20/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4047",
        "TokenNumber": "H138421",
        "OpenDate": "20/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4048",
        "TokenNumber": "H138422",
        "OpenDate": "20/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "7",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4049",
        "TokenNumber": "H138423",
        "OpenDate": "20/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4050",
        "TokenNumber": "H138425",
        "OpenDate": "20/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4051",
        "TokenNumber": "H138426",
        "OpenDate": "20/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "7",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4053",
        "TokenNumber": "H138428",
        "OpenDate": "20/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "6",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4054",
        "TokenNumber": "H138429",
        "OpenDate": "20/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "4",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4055",
        "TokenNumber": "H138430",
        "OpenDate": "20/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4056",
        "TokenNumber": "H138434",
        "OpenDate": "20/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4058",
        "TokenNumber": "H138438",
        "OpenDate": "20/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4059",
        "TokenNumber": "H138439",
        "OpenDate": "21/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "12",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4061",
        "TokenNumber": "H138448",
        "OpenDate": "21/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4062",
        "TokenNumber": "H138451",
        "OpenDate": "21/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4063",
        "TokenNumber": "H138452",
        "OpenDate": "21/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4065",
        "TokenNumber": "H138454",
        "OpenDate": "21/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "13",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4066",
        "TokenNumber": "H138457",
        "OpenDate": "21/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "4067",
        "TokenNumber": "H138458",
        "OpenDate": "21/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4071",
        "TokenNumber": "H138466",
        "OpenDate": "21/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4072",
        "TokenNumber": "H138468",
        "OpenDate": "21/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4073",
        "TokenNumber": "H138469",
        "OpenDate": "21/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4075",
        "TokenNumber": "H138473",
        "OpenDate": "22/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4076",
        "TokenNumber": "H138474",
        "OpenDate": "22/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4077",
        "TokenNumber": "H138476",
        "OpenDate": "22/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4078",
        "TokenNumber": "H138477",
        "OpenDate": "22/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4079",
        "TokenNumber": "H138478",
        "OpenDate": "22/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4081",
        "TokenNumber": "H138482",
        "OpenDate": "22/04/2020",
        "CloseDate": "22/04/2020",
        "CompletionTime": "0",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4082",
        "TokenNumber": "H138485",
        "OpenDate": "22/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4083",
        "TokenNumber": "H138487",
        "OpenDate": "22/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "7",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4086",
        "TokenNumber": "H138491",
        "OpenDate": "22/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "11",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4088",
        "TokenNumber": "H138496",
        "OpenDate": "22/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4091",
        "TokenNumber": "H138500",
        "OpenDate": "22/04/2020",
        "CloseDate": "25/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4095",
        "TokenNumber": "H138506",
        "OpenDate": "22/04/2020",
        "CloseDate": "23/04/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4096",
        "TokenNumber": "H138507",
        "OpenDate": "23/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4097",
        "TokenNumber": "H138509",
        "OpenDate": "23/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4098",
        "TokenNumber": "H138514",
        "OpenDate": "23/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4099",
        "TokenNumber": "H138520",
        "OpenDate": "23/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "4",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4103",
        "TokenNumber": "H138527",
        "OpenDate": "23/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "REOPEN"
    },
    {
        "SrNo.": "4104",
        "TokenNumber": "H138528",
        "OpenDate": "23/04/2020",
        "CloseDate": "28/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4105",
        "TokenNumber": "H138529",
        "OpenDate": "23/04/2020",
        "CloseDate": "24/04/2020",
        "CompletionTime": "1",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4109",
        "TokenNumber": "H138544",
        "OpenDate": "24/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4110",
        "TokenNumber": "H138545",
        "OpenDate": "24/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4114",
        "TokenNumber": "H138554",
        "OpenDate": "24/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "5",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4115",
        "TokenNumber": "H138555",
        "OpenDate": "24/04/2020",
        "CloseDate": "28/04/2020",
        "CompletionTime": "4",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4116",
        "TokenNumber": "H138559",
        "OpenDate": "24/04/2020",
        "CloseDate": "28/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4117",
        "TokenNumber": "H138561",
        "OpenDate": "24/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "3",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4118",
        "TokenNumber": "H138563",
        "OpenDate": "24/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4119",
        "TokenNumber": "H138565",
        "OpenDate": "24/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "5",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4120",
        "TokenNumber": "H138566",
        "OpenDate": "24/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "10",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4122",
        "TokenNumber": "H138568",
        "OpenDate": "24/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "3",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4124",
        "TokenNumber": "H138571",
        "OpenDate": "24/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "6",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4125",
        "TokenNumber": "H138576",
        "OpenDate": "25/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4126",
        "TokenNumber": "H138575",
        "OpenDate": "25/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "9",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4127",
        "TokenNumber": "H138580",
        "OpenDate": "25/04/2020",
        "CloseDate": "25/04/2020",
        "CompletionTime": "0",
        "Subject": "Contaminated Water Supply",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4129",
        "TokenNumber": "H138584",
        "OpenDate": "25/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4131",
        "TokenNumber": "H138586",
        "OpenDate": "25/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4132",
        "TokenNumber": "H138588",
        "OpenDate": "25/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4134",
        "TokenNumber": "H138590",
        "OpenDate": "25/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4135",
        "TokenNumber": "H138593",
        "OpenDate": "25/04/2020",
        "CloseDate": "26/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4136",
        "TokenNumber": "H138594",
        "OpenDate": "25/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "4",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4138",
        "TokenNumber": "H138597",
        "OpenDate": "25/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "9",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4140",
        "TokenNumber": "H138601",
        "OpenDate": "26/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "4142",
        "TokenNumber": "H138603",
        "OpenDate": "26/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4143",
        "TokenNumber": "H138607",
        "OpenDate": "26/04/2020",
        "CloseDate": "27/04/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4144",
        "TokenNumber": "H138609",
        "OpenDate": "27/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "2",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4147",
        "TokenNumber": "H138614",
        "OpenDate": "27/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "7",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4148",
        "TokenNumber": "H138617",
        "OpenDate": "27/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "2",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4149",
        "TokenNumber": "H138618",
        "OpenDate": "27/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "4151",
        "TokenNumber": "H138620",
        "OpenDate": "27/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "2",
        "Subject": "Peving Block",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4153",
        "TokenNumber": "H138622",
        "OpenDate": "27/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "8",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4154",
        "TokenNumber": "H138624",
        "OpenDate": "27/04/2020",
        "CloseDate": "03/05/2020",
        "CompletionTime": "6",
        "Subject": "Pipeline Leakage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4155",
        "TokenNumber": "H138625",
        "OpenDate": "27/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "7",
        "Subject": "Water problem",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4156",
        "TokenNumber": "H138629",
        "OpenDate": "28/04/2020",
        "CloseDate": "28/04/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4158",
        "TokenNumber": "H138633",
        "OpenDate": "28/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4162",
        "TokenNumber": "H138639",
        "OpenDate": "28/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "7",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4163",
        "TokenNumber": "H138640",
        "OpenDate": "28/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "ASSIGNED"
    },
    {
        "SrNo.": "4169",
        "TokenNumber": "H138647",
        "OpenDate": "28/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4173",
        "TokenNumber": "H138654",
        "OpenDate": "28/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4179",
        "TokenNumber": "H138662",
        "OpenDate": "28/04/2020",
        "CloseDate": "02/05/2020",
        "CompletionTime": "4",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4181",
        "TokenNumber": "H138664",
        "OpenDate": "29/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4183",
        "TokenNumber": "H138670",
        "OpenDate": "29/04/2020",
        "CloseDate": "29/04/2020",
        "CompletionTime": "0",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4185",
        "TokenNumber": "H138678",
        "OpenDate": "29/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4186",
        "TokenNumber": "H138679",
        "OpenDate": "29/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "6",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4187",
        "TokenNumber": "H138682",
        "OpenDate": "29/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "6",
        "Subject": "Road repairing",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4189",
        "TokenNumber": "H138685",
        "OpenDate": "29/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4191",
        "TokenNumber": "H138686",
        "OpenDate": "29/04/2020",
        "CloseDate": "30/04/2020",
        "CompletionTime": "1",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4192",
        "TokenNumber": "H138687",
        "OpenDate": "29/04/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "5",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4204",
        "TokenNumber": "H138711",
        "OpenDate": "30/04/2020",
        "CloseDate": "02/05/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4205",
        "TokenNumber": "H138712",
        "OpenDate": "30/04/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "5",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4208",
        "TokenNumber": "H138714",
        "OpenDate": "01/05/2020",
        "CloseDate": "01/05/2020",
        "CompletionTime": "0",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4209",
        "TokenNumber": "H138718",
        "OpenDate": "01/05/2020",
        "CloseDate": "02/05/2020",
        "CompletionTime": "1",
        "Subject": "Unauthorised Construction",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4211",
        "TokenNumber": "H138720",
        "OpenDate": "01/05/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "3",
        "Subject": "Street lights",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4224",
        "TokenNumber": "H138747",
        "OpenDate": "02/05/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4225",
        "TokenNumber": "H138749",
        "OpenDate": "02/05/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4227",
        "TokenNumber": "H138752",
        "OpenDate": "02/05/2020",
        "CloseDate": "04/05/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4229",
        "TokenNumber": "H138757",
        "OpenDate": "02/05/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "3",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4243",
        "TokenNumber": "H138776",
        "OpenDate": "03/05/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "2",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    {
        "SrNo.": "4250",
        "TokenNumber": "H138786",
        "OpenDate": "04/05/2020",
        "CloseDate": "05/05/2020",
        "CompletionTime": "1",
        "Subject": "Drainage blockage",
        "Stage": "CLOSED"
    },
    // {
    //     "SrNo.": "",
    //     "TokenNumber": "",
    //     "OpenDate": "",
    //     "CloseDate": "",
    //     "CompletionTime": "50218",
    //     "Subject": "",
    //     "Stage": ""
    // }
]