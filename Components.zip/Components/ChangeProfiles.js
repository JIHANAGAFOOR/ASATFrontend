import React, { Component } from "react";
import i18next from "i18next";

export class ChangeProfiles extends Component {
  change(option) {
    option.preventDefault();
    localStorage.setItem("profile", option.target.value);
    window.location.reload();
  }

  render() {
    const profile = localStorage.getItem("profile") || "pcmc";
    return (
      <>
        <select
          className="custom-select pull-right mr-3"
          onChange={this.change}
          value={profile}
          style={{color:'#111112'}}
        >
          <option selected={profile === "pcmc" ? "selected" : ""} value="pcmc">
            PCMC
          </option>
          <option
            selected={profile === "pcscl" ? "selected" : ""}
            value="pcscl"
          >
            PCSCL
          </option>
        </select>
      </>
    );
  }
}

export default ChangeProfiles;
