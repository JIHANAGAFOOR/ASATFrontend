import React, { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import Typography from "@material-ui/core/Typography";
import ZoomOutMapIcon from "@material-ui/icons/ZoomOutMap";
import Button from "@material-ui/core/Button";
import InstaCommentsModal from "./InstaCommentsModal";
import { Paper } from "@material-ui/core";
const InstaReport = ({ data }) => {
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [comment, setComment] = useState("Nodata");
  function handleBarClick(data) {
    // Extract necessary information from the clicked bar data
    const { message, created_time, positive, negative, neutral, comments } =
      data;
    console.log(comments);
    setModalMessage(message);
    setShowModal(true);
    setComment(comments);
  }

  const newObj = [];
  const instaObj = [];
  data.forEach((obj1) => {
    // console.log(obj1["comments"].neutral_description.length);
    let post = {
      created_time: new Date(obj1["time"]).toLocaleString(),
      Positive_Comment: obj1["comments"].positive_description.length,
      Negative_Comment: obj1["comments"].negative_description.length,
      Neutral_Comment: obj1["comments"].neutral_description.length,
      message: obj1["post"],
      comments: obj1["comments"],
    };
    instaObj.push(post);
  });
  return (
    <div>
           <Paper elevation={3}>
            <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight">
              <div class="mr-auto p-2 bd-highlight">Instagram Sentimental Analysis</div>
              <div class="bd-highlight">
              </div>
            </div>
          </Typography>
      <ResponsiveContainer height={400} width="100%" >
        <BarChart
          data={instaObj} >
          <XAxis dataKey="created_time" />
          <YAxis />
          <Tooltip />
          <Legend
          formatter={(value, entry, index) => (
            <span style={{ color: entry.color }}>
              {value.replace(/_/g, ' ')}
            </span>
          )}
          />
          <Bar
            dataKey="Positive_Comment"
            stackId="a"
            fill="#8884d8"
            onClick={(data) => handleBarClick(data)}
          />
          <Bar
            dataKey="Negative_Comment"
            stackId="a"
            fill="#82ca9d"
            onClick={(data) => handleBarClick(data)}
          />
          <Bar
            dataKey="Neutral_Comment"
            stackId="a"
            fill="#efca9d"
            onClick={(data) => handleBarClick(data)}
          />
        </BarChart>
      </ResponsiveContainer>
      {showModal && (
      <InstaCommentsModal
          title={modalMessage}
          open={showModal}
          handleCloseModal={() => setShowModal(false)}
          comments={comment}
          fileName={"senti"}
        />
      )}
 </Paper>
    </div>
  );
};

export default InstaReport;

