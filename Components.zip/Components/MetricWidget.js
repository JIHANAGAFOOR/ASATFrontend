import React from "react";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";
import Grid from "@material-ui/core/Grid";
import FacebookIcon from "@material-ui/icons/Facebook";
import TwitterIcon from "@material-ui/icons/Twitter";
import InstagramIcon from "@material-ui/icons/Instagram";
import PeopleAltIcon from '@material-ui/icons/PeopleAlt';
import InboxIcon from '@material-ui/icons/Inbox';
import Link from "@material-ui/core/Link";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";
import { useMediaQuery } from "@material-ui/core";
import { createStyles, withStyles } from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  containerStyle:{
    textAlign: "center",
    height: "5vw",
    textAlignVertical: "center",
    width: "auto",
  },
  iconSize: {
    fontSize: 60, 
    color: "white"
  },
  countSize:{
    color: "white", 
    fontSize: "32px"
  },
  textSize:{
    fontSize:'16px'
  },
  "@media (max-width: 660px)": {
    iconSize: {
      fontSize: 30, 
    },
    countSize:{
      fontSize: "12px"
    },
    containerStyle:{
      height: "65px",
    },
    textSize:{
      fontSize:'12px'
    },
  },
  "@media (min-width: 660px)": {
    iconSize: {
      fontSize: 30, 
    },
    countSize:{
      fontSize: "16px"
    },
    containerStyle:{
      height: "65px",
    },
    textSize:{
      fontSize:'12px'
    },
  },
  "@media (min-width: 768px)": {
    iconSize: {
      fontSize: 36, 
    },
    countSize:{
      fontSize: "20px"
    },
    containerStyle:{
      height: "75px",
    }
  },

  "@media (min-width: 992px)": {
    iconSize: {
      fontSize: 50, 
    },
    countSize:{
      fontSize: "32px"
    },
    containerStyle:{
      height: "80px",
    }
  },

});

export default function MetricWidget({iconType, backgroundColor, parentUrl, name, count, size=4}) {

  const classes = useStyles();

  let socialIcon;
  if(iconType === 'facebook')
    socialIcon = <FacebookIcon className={classes.iconSize} />;
  else if(iconType === 'twitter')
    socialIcon = <TwitterIcon className={classes.iconSize} />;
  else if(iconType === 'instagram')
    socialIcon = <InstagramIcon className={classes.iconSize} />;
  else if(iconType === 'friends')
    socialIcon = <PeopleAltIcon className={classes.iconSize} />;
  else if(iconType === 'posts')
    socialIcon = <InboxIcon className={classes.iconSize} />;

  return <Grid item xs={12} sm={12} lg={size} xl={size} md={12}>
    <Paper
      elevation={3}
      style={{ background: backgroundColor}}
      className={classes.containerStyle}
    >
      <Grid container spacing={3}>
        <Grid
          item
          xs={4}
          style={{ paddingTop: "2px", paddingLeft: "15px" }}
        >
          <IconButton
            rel="preload"
            as="script"
            component={Link}
            to={parentUrl}
          >
            {socialIcon}
          </IconButton>
        </Grid>
        <Grid
          item
          xs={4}
          style={{ paddingLeft: "20px", paddingTop: "0px" }}
        >
          <br />
          <Typography className={classes.textSize} style={{ color: "white", paddingLeft: "20px" }}>
            {i18next.t("Total")}
            <br />
            {i18next.t(name)}{" "}
          </Typography>
        </Grid>
        <Grid
          item
          xs={4}
          style={{ paddingTop: "1px", paddingLeft: "5px" }}
        >
          <br />
          <Typography
            variant="h2"
            className={classes.countSize}
          >
            {count || <p style={{fontSize:'12px'}}>No Data Found</p>}{" "}
          </Typography>
        </Grid>
      </Grid>
    </Paper>
  </Grid>;
  };
