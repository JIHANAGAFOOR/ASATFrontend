import React from "react";
import { Modal, Button, Dropdown, DropdownButton } from "react-bootstrap";
import { withRouter } from "react-router-dom";
import "../CSS/DynModal.css";

const DynModal = function (props) {
  function WorkOrders(elementName) {
    props.history.push("/DasboardHome/SiapWorkorders");
  }
  return (
    <div>
      <Modal
        className="my-modal"
        size="lg"
        show={props.show}
        onHide={props.handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>{props.modalTitle}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{props.modalBody}</Modal.Body>
        {props.modalFooter && (
          <Modal.Footer>
            <Button onClick={props.handleClose} variant="secondary">
              Purge
            </Button>
            <DropdownButton id="dropdown-basic-button" title="Act">
              <div className="MyDropDownMenu">
                <Dropdown.Item onClick={() => WorkOrders()}>
                  Device/Equipment control policy
                </Dropdown.Item>
                <Dropdown.Item href="#/action-2">
                  Create a WorkFlow
                </Dropdown.Item>
                <Dropdown.Item href="#/action-3">
                  Asset Mnagement Workorder
                </Dropdown.Item>
              </div>
            </DropdownButton>
          </Modal.Footer>
        )}
      </Modal>
    </div>
  );
};
export default withRouter(DynModal);
