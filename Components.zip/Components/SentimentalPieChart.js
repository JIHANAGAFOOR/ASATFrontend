import React from "react";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";
import { DropdownButton, Dropdown } from "react-bootstrap";
import CircularProgress from "@material-ui/core/CircularProgress";
import { MenuItem, FormControl, Select, ButtonBase } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import ZoomOutMapIcon from "@material-ui/icons/ZoomOutMap";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${payload[0].name} : ${payload[0].value} % `}</p>
      </div>
    );
  }
  return null;
};

export default function SentimentalPieChart({
  dataArray,
  title,
  handleOpenPositive,
  handleOpenNegative,
  handleOpenNeutral,
  handleChangeWord,
  language,
  words,
  handleZoomout,
}) {
  if (dataArray.length > 0) {
    return (
      <div
        style={{
          // minWidth: "385px",
          // minHeight: "400px",
        }}
      >
        <Paper elevation={3}>
          <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight">
              <div class="mr-auto p-2 bd-highlight">{i18next.t(title)}</div>
              <div class="bd-highlight">
                {handleZoomout && (
                  <div align="right">
                    <Button onClick={handleZoomout}>
                      <ZoomOutMapIcon />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </Typography>

          <div className="d-flex align-items-center justify-content-between">
            <div align="left">
              <DropdownButton
                id="dropdown-basic-button"
                drop="right"
                variant="none"
              >
                <Dropdown.Item onClick={handleOpenPositive}>
                  {" "}
                  {i18next.t("Positive Comments")} {" "}
                </Dropdown.Item>
                <Dropdown.Item onClick={handleOpenNegative}>
                  {" "}
                  {i18next.t("Negative Comments")} {" "}
                </Dropdown.Item>
                <Dropdown.Item onClick={handleOpenNeutral}>
                  {" "}
                  {i18next.t("Neutral Comments")} {" "}
                </Dropdown.Item>
              </DropdownButton>
            </div>
            <FormControl className="app_header m-2">
	    {/* <Select
                variant="outlined"
                onChange={handleChangeWord}
                value={language}
              >
                <MenuItem value="default">default</MenuItem>
                {words.map((val) => (
                  <MenuItem value={val.word}>{val.word}</MenuItem>
                ))}
              </Select>*/}
            </FormControl>
          </div>
          <div className="d-flex justify-content-cneter">
            <ResponsiveContainer height={360} width="100%">
              <PieChart
                width={500}
                height={200}
                // verticalAlign="center"
                // margin={{ top: 0, left: 0, right: 0, bottom: 0 }}
              >
                <Legend
                  layout="vertical"
                  verticalAlign="top"
                  align="right"
                />
                <Tooltip content={<CustomTooltip />} />
                <Pie
                  data={
                    dataArray.length > 0 ? (
                      dataArray
                    ) : (
                      <p>
                        <CircularProgress />
                      </p>
                    )
                  }
                  // cx={100}
                  // cy={100}
                  innerRadius={45}
                  outerRadius={100}
                  fill="#8884d8"
                  // paddingAngle={5}
                  dataKey="value"
                  
                >
                  {dataArray.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                  label
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Paper>
      </div>
    );
  } else
    return (
      <div style={{ alignItems: "center", margin: "auto" }}>
        <CircularProgress />
      </div>
    );
}

