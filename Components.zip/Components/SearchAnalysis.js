import React, {useState} from "react";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";
import { DropdownButton, Dropdown } from "react-bootstrap";
import CircularProgress from "@material-ui/core/CircularProgress";
import { MenuItem, FormControl, Select, ButtonBasie, Input, InputLabel } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import ZoomOutMapIcon from "@material-ui/icons/ZoomOutMap";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import SearchModal from './SearchModal'
const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${payload[0].name} : ${payload[0].value} % `}</p>
      </div>
    );
  }
  return null;
};

export default function SentimentalPieChart({
  dataArray,
  title,
  handleOpenPositive,
  handleOpenNegative,
  handleOpenNeutral,
   searchValue,
	setSearchValue,
	handleSubmit,
  handleZoomout,
	searchArray,
	commentsArray

}) {
 const [showModal, setShowModal] = useState(false);
	const handleBarClick=()=>{
	setShowModal(true)}
    return (
      <div
        style={{
          // minWidth: "385px",
          // minHeight: "400px",
        }}
      >
        <Paper elevation={3}>
          <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight">
              <div class="mr-auto p-2 bd-highlight">{i18next.t(title)}</div>
              <div class="bd-highlight">
                {handleZoomout && (
                  <div align="right">
                    <Button onClick={handleZoomout}>
                      <ZoomOutMapIcon />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </Typography>

	    {/*<div className="d-flex align-items-center justify-content-between">
            <div align="left">
              <DropdownButton
                id="dropdown-basic-button"
                drop="right"
                variant="none"
              >
                <Dropdown.Item onClick={handleOpenPositive}>
                  {" "}
                  {i18next.t("Positive Comments")} {" "}
                </Dropdown.Item>
                <Dropdown.Item onClick={handleOpenNegative}>
                  {" "}
                  {i18next.t("Negative Comments")} {" "}
                </Dropdown.Item>
                <Dropdown.Item onClick={handleOpenNeutral}>
                  {" "}
                  {i18next.t("Neutral Comments")} {" "}
                </Dropdown.Item>
              </DropdownButton>
            </div>
	    jjj
          </div>*/}
	    <div style={{marginLeft:"16px"}}>
	    <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center'}} >
      <FormControl style={{ marginRight: '10px' }}>
        <InputLabel htmlFor="search-input">Search</InputLabel>
        <Input id="search-input" type="text"  value={searchValue} onChange={setSearchValue} />
      </FormControl>
	    <Button type="submit" variant="contained" color="primary">
        Search
      </Button>
    </form></div>
	    {/*{searchValue!=="" ?
          <div className="d-flex justify-content-cneter">
		   
		    {searchArray.no_of_posts!==0?<div style={{height:"360px" , width:"100%"}}>
			    {searchArray.no_of_posts?<p style={{ marginLeft: '10px' }}>Number of matching word : {searchArray.no_of_posts}</p> :""}
			    <ResponsiveContainer height={360} width="100%">
			   
			    {dataArray.length>0? <PieChart
                width={500}
                height={200}
                // verticalAlign="center"
                // margin={{ top: 0, left: 0, right: 0, bottom: 0 }}
              >
                <Legend
                  layout="vertical"
                  verticalAlign="top"
                  align="right"
                />
                <Tooltip content={<CustomTooltip />} />
                <Pie
				    onClick={handleBarClick}
                  data={
                    dataArray
                  }
                  // cx={100}
                  // cy={100}
                  innerRadius={45}
                  outerRadius={100}
                  fill="#8884d8"
                  // paddingAngle={5}
                  dataKey="value"
                  
                >
                  {dataArray.length>0&&dataArray.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                  label
                </Pie>
              </PieChart>:<p>ddd</p>}
            </ResponsiveContainer></div>: <div style={{ display:"flex",justifyContent:"center",alignItems: "center", margin: "auto",height:"350px" }}>
        <h5>No matching word found</h5>
      </div>}
          </div>:
		     <div style={{ display:"flex",justifyContent:"center",alignItems: "center", margin: "auto",height:"350px" }}>
        <h5> Give any word to search..</h5>
      </div>
	    }*/}
        </Paper>
	    {showModal && (
        <SearchModal
          title={searchValue}
          open={showModal}
          handleCloseModal={() => setShowModal(false)}
          comments={commentsArray}
          fileName={"senti"}
        />
      )}
      </div>
    );
}
