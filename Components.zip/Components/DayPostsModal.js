import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import Modal from "@material-ui/core/Modal";
import PrintIcon from "@material-ui/icons/Print";
import CloseIcon from "@material-ui/icons/Close";
import PropTypes from "prop-types";
import { Table } from "react-bootstrap";
import { ExportCSV } from "./ExportCSV";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";

export default function DayPostsModal({title, open, handleCloseModal, posts, fileName}) {
    return <Modal
        open={open}
        onClose={handleCloseModal}
        style={{ overflow: "scroll" }}
      >
        <div
          style={{
            // width:1800,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Paper
            elevation={3}
            style={{
              textAlign: "center",
              padding: "10px",
              overflow: "scroll",
            }}
          >
            <div align="right">
              <ExportCSV csvData={posts} fileName={fileName} />
              <IconButton onClick={() => window.print()}>
                <PrintIcon />
              </IconButton>
              <IconButton onClick={handleCloseModal}>
                <CloseIcon />
              </IconButton>
            </div>
  
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>{title}</th>
                </tr>
              </thead>
              <tbody>
                <tr className="d-flex flex-column">
                  {posts ? (
                    posts.map((e) => {
                      return <td style={{ fontSize: "15px" }}>{e.message || e.text}</td>;
                    })
                  ) : (
                    <h1>No data found!!! </h1>
                  )}
                </tr>
              </tbody>
            </Table>
          </Paper>
        </div>
      </Modal>;
  };
