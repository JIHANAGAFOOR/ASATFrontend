import React, { Component } from "react";
import "../CSS/Login.css";

import {
  //  BrowserRouter as Router,
    Redirect } from "react-router-dom";
import Auth from "../AuthRoutes/Auth";
import { NavLink } from "react-router-dom";
import { Form, Button } from "react-bootstrap";
import Logo from "../Images/kissclipart-social-media-clipart-social-media-marketing-instag-b27560fb5e08b588.png";

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      isChecked: false,
      loginStatus: "true",
      emailError: "",
      passwordError: "",
      loginFormError: "",
      role: "",
    };
    this.onChangeValue = this.onChangeValue.bind(this);
    this.onChangeCheckbox = this.onChangeCheckbox.bind(this);
  }

  onChangeValue(event) {
    var nameError = event.target.name.concat("Error");

    this.setState({
      [event.target.name]: event.target.value,
      [nameError]: "",
    });
  }

  onChangeCheckbox(event) {
    this.setState({
      isChecked: event.target.checked,
    });
  }

  validate = () => {
    var currentCharacter = "";
    var numberPresent = false;
    var lowerCasePresent = false;
    var upperCasePresent = false;
    var specialCharacterPresent = false;
    var passwordTemp = this.state.password;
    if (this.state.email !== "") {
      if (!this.state.email.includes("@")) {
        this.setState({
          emailError: "Email should have an @ with domain name.",
        });
        return false;
      }
    } else return false;

    for (var i = 0; i < passwordTemp.length; i++) {
      currentCharacter = passwordTemp.charAt(i);
      if (passwordTemp.charAt(i).match(/[A-Z]/g)) upperCasePresent = true;
      if (passwordTemp.charAt(i).match(/[a-z]/g)) lowerCasePresent = true;
      if (passwordTemp.charAt(i).match(/[0-9]/g)) numberPresent = true;
      if (
        passwordTemp.charAt(i).match(/[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/g)
      )
        specialCharacterPresent = true;
    }
    if (
      i < 8 ||
      upperCasePresent === false ||
      numberPresent === false ||
      lowerCasePresent === false ||
      specialCharacterPresent === false
    ) {
      this.setState({
        passwordError:
          " Password must contain at least one number, one specialCharacter character and one uppercase and lowercase letter, and at least 8 or more characters",
      });
      return false;
    }
    this.setState({ passwordError: "", emailError: "" });
    return true;
  };

  loginSubmit = (event) => {
    if (this.state.email && this.state.password) event.preventDefault();
    const { email, password, isChecked } = this.state;
    if (isChecked && email !== "") {
      localStorage.username = email;
      localStorage.password = password;
      localStorage.checkbox = isChecked;
    }

    const isValid = this.validate();

    if (isValid) {
      const url = "http://103.255.216.239:80/siap/user/login";
      const requestOptions = {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_email: this.state.email,
          password: this.state.password,
        }),
      };

      fetch(url, requestOptions)
        .then(async (response) => {
          const data = await response.json();

          // check for error response
          if (!response.ok) {
            // get error message from body or default to response status
            if (response.status === 301)
              this.setState({ passwordError: data.error.message });

            if (response.status === 404)
              this.setState({ emailError: data.error.message });

            return Promise.reject(data.error.message);
          }
          if (response.ok) {
            Auth.login(() => {
              this.props.history.push("/Login");
            });
            localStorage.emailId = data.data.user.user_email;
            localStorage.role = data.data.user.role;
            localStorage.auth_token = data.data.user.auth_token;
            this.setState({
              loginStatus: true,
              passwordError: "",
              emailError: "",
              loginFormError: "",
              role: data.data.user.role,
            });
          }
        })
        .catch((error) => {
          if (typeof error !== "string")
            this.setState({ loginFormError: error.message, RoleNameError: "" });
          else this.setState({ loginFormError: "" });
        });
    }
  };

  componentDidMount() {
    if (localStorage.checkbox && localStorage.email !== "") {
      this.setState({
        email: localStorage.username,
        password: localStorage.password,
      });
    }
  }
  componentDidMount() {
    if (localStorage.checkbox && localStorage.email !== "") {
      this.setState({
        email: localStorage.username,
        password: localStorage.password,
      });
    }
  }
  render() {
    const { email, password, isChecked } = this.state;
    console.log(`inside Login ${this.props}`);
    if (this.state.loginStatus === true)
      switch (this.state.role) {
        case "dc":
          return <Redirect to={{ pathname: "/dc" }} />;
        case "admin":
          return <Redirect to={{ pathname: "/Admin" }} />;
        case "health":
          return <Redirect to={{ pathname: "/Health" }} />;
      }

    return (
      <div className="screenWrapper">
        <div className="loginContainer">
          <div className="row">
            <div className="col-lg-6 d-none d-lg-block">
              <div className="p-5">
                <div className="text-center">
                  <h1 className="h4 mb-4 text-primary font-weight-bold">
                    Aptive Smart Analytical Tool
                  </h1>
                </div>
                <div className="text-center">
                  <img className="img-profile" width="60%" src={Logo} />
                </div>
                <br />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="p-5">
                <div className="text-center">
                  <h1 className="h4 text-gray-900 mb-4">Welcome Back!</h1>
                </div>
                <Form id="MyForm">
                  {this.state.loginFormError ? (
                    <Form.Text id="myError">
                      {this.state.loginFormError}
                    </Form.Text>
                  ) : null}
                  <Form.Group controlId="formBasicEmail">
                    <Form.Label className="myLabel">Email address</Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={email}
                      placeholder="User Name"
                      required
                      onChange={this.onChangeValue}
                    />
                  </Form.Group>
                  {this.state.emailError ? (
                    <Form.Text id="myError">{this.state.emailError}</Form.Text>
                  ) : null}
                  <Form.Group controlId="formBasicPassword">
                    <Form.Label className="myLabel">Password</Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={password}
                      placeholder="Password"
                      required
                      onChange={this.onChangeValue}
                    />
                  </Form.Group>

                  {this.state.passwordError ? (
                    <Form.Text id="myError">
                      {this.state.passwordError}
                    </Form.Text>
                  ) : null}
                  <Form.Group controlId="formBasicCheckbox">
                    <Form.Check type="checkbox">
                      <Form.Check.Input
                        type="checkbox"
                        name="isChecked"
                        onChange={this.onChangeCheckbox}
                      />
                      <Form.Check.Label className="myLabel">
                        Remember me
                      </Form.Check.Label>
                    </Form.Check>
                  </Form.Group>
                  <Button
                    variant="primary"
                    type="submit"
                    onClick={this.loginSubmit}
                    block
                  >
                    Login
                  </Button>
                </Form>
                <hr className="FooterDevider" />
                <div className="text-center">
                  <p
                    className=""
                    style={{ fontWeight: "normal", fontSize: "medium" }}
                  >
                    <span className="glyphicon glyphicon-question-sign"></span>
                    <NavLink to="/ForgotPassword">Forgot Password ?</NavLink>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Login;
