import React from 'react';
import { BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const reports = [
  { "created_time": "2024-02-27T06:14:30+0000", "positive": "100.00", "negative": 0.00, "neutral": 0.00 },
  { "created_time": "2024-02-27T06:14:30+0000", "positive": 100.00, "negative": 0.00, "neutral": 0.00 },
  { "created_time": "2024-02-27T06:14:30+0000", "positive": 100.00, "negative": 5.00, "neutral": 0.00 },
  { "created_time": "2024-02-27T06:14:30+0000", "positive": "100.00", "negative": 0.00, "neutral": 7.00 }
];

const SentimentalAnalysis = () => {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart
        width={500}
        height={300}
        data={reports}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="created_time" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="positive" stackId="a" fill="#8884d8" />
        <Bar dataKey="negative" stackId="a" fill="#82ca9d" />
        <Bar dataKey="neutral" stackId="a" fill="#efca9d" />
      </BarChart>
    </ResponsiveContainer>
  );
}

export default SentimentalAnalysis;
