import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter, Link } from "react-router-dom";
import i18next from "i18next";
import Grid from "@material-ui/core/Grid";
import "../App.css";
import { scaleOrdinal } from "d3-scale";
import { schemeCategory10 } from "d3-scale-chromatic";
import PropTypes from "prop-types";
import CommentsModal from "./CommentsModal";
import MetricWidget from "./MetricWidget";
import SentimentalPieChart from "./SentimentalPieChart";
import PostCountBarChart from "./PostCountBarChart";
import DayPostsModal from "./DayPostsModal";
import FacebookReport from './FacebookReport'
import InstaReport from './InstaReport'
import {
  fetchmaindashboard,
  fetchthirdpartydashboard,
  fetchfacebooksentimental,
  fetchfacebookPostCount,
  fetchtwitterAnalysis,
  fetchgetword,
  fetchfacebooksearch,
  fetchtwittersearch,
  fetchinstagramsearch,
  fetchinstagramsentimental,
  fetchinstagramPostCount,
  fetchtwitterPostCount,
} from "../Reducers/actions";
import * as URLS from "../Reducers/Constants";
import { Redirect } from "react-router-dom";

const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];
const colors = scaleOrdinal(schemeCategory10).range();

const getPath = (x, y, width, height) => `M${x},${y + height}
          C${x + width / 3},${y + height} ${x + width / 2},${y + height / 3} ${
  x + width / 2
}, ${y}
          C${x + width / 2},${y + height / 3} ${x + (2 * width) / 3},${
  y + height
} ${x + width}, ${y + height}
          Z`;

const TriangleBar = (props) => {
  const { fill, x, y, width, height } = props;

  return <path d={getPath(x, y, width, height)} stroke="none" fill={fill} />;
};

TriangleBar.propTypes = {
  fill: PropTypes.string,
  x: PropTypes.number,
  y: PropTypes.number,
  width: PropTypes.number,
  height: PropTypes.number,
};

class Dashboardtop extends Component {
  componentDidMount() {
    setTimeout(() => {
      this.someFetch();
    }, 1200);
    //  this.someFetch();
  }
  someFetch = () => {
    let { dispatch } = this.props;

    dispatch(fetchmaindashboard());
    dispatch(fetchthirdpartydashboard());
    dispatch(fetchfacebooksentimental());
    dispatch(fetchfacebookPostCount());
    dispatch(fetchinstagramsentimental());
    dispatch(fetchinstagramPostCount());
    dispatch(fetchtwitterAnalysis());
    dispatch(fetchgetword());
    dispatch(fetchtwitterPostCount());
  };

  constructor() {
    super();
    this.state = {
      twitterpos: false,
      twitternegative: false,
      twitterneutral: false,
      facebookpos: false,
      facebookneg: false,
      facebookneu: false,
      facebooksearch: null,
      instagrampos: false,
      instagramneg: false,
      instagramneu: false,
      ch: null,
      twitterch: null,
      showExpire: false,
    };
  }

  handleOpentwitterpos = (e) => {
    e.preventDefault();

    this.setState({ twitterpos: true });
  };

  handleClosetwitterpos = (e) => {
    e.preventDefault();

    this.setState({ twitterpos: false });
  };

  handleOpentwitternegative = (e) => {
    e.preventDefault();

    this.setState({ twitternegative: true });
  };

  handleClosetwitternegative = (e) => {
    e.preventDefault();

    this.setState({ twitternegative: false });
  };

  handleOpentwitterneutral = (e) => {
    e.preventDefault();

    this.setState({ twitterneutral: true });
  };

  handleClosetwitterneutral = (e) => {
    e.preventDefault();

    this.setState({ twitterneutral: false });
  };

  handleOpenfacebookpositive = (e) => {
    e.preventDefault();

    this.setState({ facebookpos: true });
  };

  handleClosefacebookpositive = (e) => {
    e.preventDefault();

    this.setState({ facebookpos: false });
  };

  handleOpenfacebooknegative = (e) => {
    e.preventDefault();

    this.setState({ facebookneg: true });
  };

  handleClosefacebooknegative = (e) => {
    e.preventDefault();

    this.setState({ facebookneg: false });
  };

  handleOpenfacebookneutral = (e) => {
    e.preventDefault();

    this.setState({ facebookneu: true });
  };

  handleClosefacebookneutral = (e) => {
    e.preventDefault();
    this.setState({ facebookneu: false });
  };

  handleOpeninstagrampositive = (e) => {
    e.preventDefault();

    this.setState({ instagrampos: true });
  };

  handleCloseinstagrampositive = (e) => {
    e.preventDefault();

    this.setState({ instagrampos: false });
  };

  handleOpeninstagramnegative = (e) => {
    e.preventDefault();

    this.setState({ instagramneg: true });
  };

  handleCloseinstagramnegative = (e) => {
    e.preventDefault();

    this.setState({ instagramneg: false });
  };

  handleOpeninstagramneutral = (e) => {
    e.preventDefault();

    this.setState({ instagramneu: true });
  };

  handleCloseinstagramneutral = (e) => {
    e.preventDefault();

    this.setState({ instagramneu: false });
  };

  handleOpenDayWisePosts = (e) => {
    e.preventDefault();
    this.setState({ showDayWisePostsModal: true });
  };

  handleCloseDayWisePosts = (e) => {
    e.preventDefault();
    this.setState({ showDayWisePostsModal: false });
  };

  changeWord = async (e) => {
    this.props.dispatch(fetchfacebooksearch(e.target.value));
  };

  twiterchangeWord = async (e) => {
    this.props.dispatch(fetchtwittersearch(e.target.value));
  };

  instaChangeWord = async (e) => {
    this.props.dispatch(fetchinstagramsearch(e.target.value));
  };

  render() {
    // var totalfriends = [];
    var totalFacebookPosts = [];
    var totalretweets = [];
    var totalInstaMedia = "No data found";
    var thirdpartyarr = [];
    var fbarr = [];
    var instaarr = [];
    let twitterarr = [];
    let fbpostvalue = [];
    let fbnegative = [];
    let fbneutral = [];
    let twitterpostvalue = [];
    let twitternegative = [];
    let twitterneutral = [];
    let instapostvalue = [];
    let instanegative = [];
    let instaneutral = [];

    // let instagramtag = [];
    const lang = localStorage.getItem("search") || "default";
    const lang1 = localStorage.getItem("twsearch") || "default";

    //getword
    let words = [];
    if (this.props.getwords) {
      let obj = this.props?.getwords || [];
      words = obj;
    }

    //:x
	  //
    let profilename;
	 // console.log("FACEBOOK DATASS"+JSON.stringify(this.props.facebooksent))
    if (this.props.facebooksent) {
      let objs = this.props.facebooksent?.report || {};
	    console.log(objs)
      // let objs = this.props.facebooksent?.map(x=>x.report) || {}
      fbarr = Object.keys(objs).map((key) => ({
        name: i18next.t(key),
        value: Number(objs[key]),
      }));

      let fbcomments = this.props.facebooksent?.comments || null;
	   // console.log("FACEBOOK   "+JSON.stringify(fbcomments))
      if (fbcomments) {
        fbpostvalue = fbcomments["positive_description"] || [];
        fbnegative = fbcomments["negative_description"] || [];
        fbneutral = fbcomments["neutral_description"] || [];
      }
    }

    //for insta
    
	  var instagramData=this.props.instagramsent
	  //iconsole.log("DATA "+JSON.stringify(instagramData?.["postsWithComments"]))
    if (this.props.instagramsent) {
      let objs = this.props.instagramsent?.report || {};
      instaarr = Object.keys(objs).map((key) => ({
        name: i18next.t(key),
        value: Number(objs[key]),
      }));

      let instacomments = this.props.instagramsent?.comments;
	   // console.log("INSTAAA  "+JSON.stringify(instacomments))
      if (instacomments) {
        instapostvalue = instacomments["positive_description"];
        instanegative = instacomments["negative_description"];
        instaneutral = instacomments["neutral_description"];
      }
    }

    if (this.props.twittersent) {
      let objs = this.props.twittersent?.report || {};
      twitterarr = Object.keys(objs).map((key) => ({
        name: i18next.t(key),
        value: Number(objs[key]),
      }));

      let twittercomments = this.props.twittersent?.comments;
	    //console.log("TWITTERRRRRR : "+JSON.stringify(twittercomments))
      if (twittercomments) {
        twitterpostvalue = twittercomments["positive_comments"];
        twitternegative = twittercomments["negative_comments"];
        twitterneutral = twittercomments["neutral_comments"];
      }
    }

    if (this.props.thirdpartyone) {
      let objs = this.props.thirdpartyone?.stage_wise_data || {};
      var result = Object.keys(objs).map((key) => [key, objs[key]]);

      let temp = [];
      result.map((element, index) => {
        let newtemp = {
          name: i18next.t(element[1].name),
          value: Number(element[1].value),
        };
        temp.push(newtemp);
      });

      thirdpartyarr = temp;
    }
//console.log("MAIN DASHBOARD "+JSON.stringify(this.props))
    if (this.props.maindashboard) {
      let obj = this.props?.maindashboard;
      console.log("DDDDDDDDDDDDd"+JSON.stringify(obj))
      if (obj) {
        totalFacebookPosts = obj.facebook.fb_total_number_of_posts || null;
        	//console.log("POSTSSSSSSSSSSSSS"+totalFacebookPosts)
       	totalretweets =  null;
        totalInstaMedia = obj.instagram.post_count.media_count || null;
        //abcd
      }
    }

    if (this.props.facebookPostCount) {
      let posts = this.props.facebookPostCount["no_of_posts"] || {};
      var dayposts = Object.keys(posts || {}).map((key) => ({
        name: key.slice(0, 10),
        Postscount: posts[key],
      }));
    }

    if (this.props.twitterPostCount) {
      let tweets = this.props.twitterPostCount["no of posts"] || {};
      var dayTweets = tweets
        ? Object.keys(tweets).map((key) => ({
            name: key.slice(0, 10),
            Number_of_Tweets: tweets[key],
          }))
        : [];
    }

    if (this.props.instagramPostCount) {
      let posts = this.props.instagramPostCount["no of posts"] || {};
      var dayInstaPosts = Object.keys(posts || {}).map((key) => ({
        name: key.slice(0, 10),
        Postscount: posts[key],
      }));
    }

    const facebookFileName = "Facebook_Comments";
    const twitterfileName = "Twitter_Comments";
    const instagramFileName = "Instagram_Comments";
//console.log("FB DATA "+JSON.stringify(this.props.facebooksent))
    return (
      <div
        style={{
          paddingTop: "150px",
          paddingLeft: "30px",
          paddingRight: "30px",
        }}
      >
        <CommentsModal
          title="Neutral Comments"
          open={this.state.facebookneu}
          handleCloseModal={this.handleClosefacebookneutral}
          comments={fbneutral}
          fileName={facebookFileName}
        />
        <CommentsModal
          title="Negative Comments"
          open={this.state.facebookneg}
          handleCloseModal={this.handleClosefacebooknegative}
          comments={fbnegative}
          fileName={facebookFileName}
        />
        <CommentsModal
          title="Positive Comments"
          open={this.state.facebookpos}
          handleCloseModal={this.handleClosefacebookpositive}
          comments={fbpostvalue}
          fileName={facebookFileName}
        />
        <CommentsModal
          title="Positive Comments"
          open={this.state.twitterpos}
          handleCloseModal={this.handleClosetwitterpos}
          comments={twitterpostvalue}
          fileName={twitterfileName}
        />
        <CommentsModal
          title="Negative Comments"
          open={this.state.twitternegative}
          handleCloseModal={this.handleClosetwitternegative}
          comments={twitternegative}
          fileName={twitterfileName}
        />
        <CommentsModal
          title="Neutral Comments"
          open={this.state.twitterneutral}
          handleCloseModal={this.handleClosetwitterneutral}
          comments={twitterneutral}
          fileName={twitterfileName}
        />
        <CommentsModal
          title="Positive Comments"
          open={this.state.instagrampos}
          handleCloseModal={this.handleCloseinstagrampositive}
          comments={instapostvalue}
          fileName={instagramFileName}
        />
        <CommentsModal
          title="Negative Comments"
          open={this.state.instagramneg}
          handleCloseModal={this.handleCloseinstagramnegative}
          comments={instanegative}
          fileName={instagramFileName}
        />
        <CommentsModal
          title="Neutral Comments"
          open={this.state.instagramneu}
          handleCloseModal={this.handleCloseinstagramneutral}
          comments={instaneutral}
          fileName={instagramFileName}
        />
        <DayPostsModal
          title="Day wise posts"
          open={this.state.showDayWisePostsModal}
          handleCloseModal={this.handleCloseDayWisePosts}
          comments={[]}
          fileName={twitterfileName}
        />
        <Grid
          container
          spacing={3}
          // container
          // direction="row"
          justify="space-between"
          // textAlignVertical="center"
        >
          <MetricWidget
            iconType="facebook"
	    backgroundColor="#3b5998"
            parentUrl="/parent/fbdb"
            name="Posts"
            count={totalFacebookPosts}
	 
          />

          <MetricWidget
            iconType="twitter"
            backgroundColor="#00aced"
            parentUrl="/parent/dashboard"
            name="Retweets"
            count={totalretweets}
          />

          <MetricWidget
            iconType="instagram"
            // backgroundColor="#3f729b"
            backgroundColor= "radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%)"
            parentUrl="/parent/indb"
            name="Posts"
            count={totalInstaMedia}
          />
        </Grid>
        <br />
        <br />
        <br />
        {/* facebook sentimental graph start */}
        <div class="row mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
          
	    {this.props.facebooksent&&
	   <FacebookReport data={this.props.facebooksent}/>}
          </div>
          <br />
          <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
            <PostCountBarChart
              dataArray={dayposts}
              fetching={this.props.isFacebookPostCountFetching}
              error={
                this.props.facebookPostError ? this.props.facebookPostError : null
              }
              title="Facebook Daily Reach (90 Days)"
              datekey="name"
              countkey="Postscount"
              totalPosts={totalFacebookPosts}
              socialPlatform="facebook"
              labelling="Posts Count"
            />
          </div>
        </div>
	   
        <div class="row mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
            <SentimentalPieChart
              dataArray={twitterarr}
              title="Twitter Sentimental Analysis"
              handleOpenPositive={this.handleOpentwitterpos}
              handleOpenNegative={this.handleOpentwitternegative}
              handleOpenNeutral={this.handleOpentwitterneutral}
              handleChangeWord={this.twiterchangeWord}
              language={lang1}
              words={words}
            />
          </div>
          <br />
	   
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-5">
            <PostCountBarChart
              dataArray={dayTweets}
              fetching={this.props.isTwitterPostCountFetching}
              error={this.props.twitterPostError}
              title="Tweet Growth (per day)"
              datekey="name"
              countkey="Number_of_Tweets"
              totalPosts="----"
              socialPlatform="twitter"
              labelling="Posts Count"
            />
          </div>
        </div>
        {/* third party graph was here */}
        <div class="row mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-6">
            {/* instagram sentimental graph start */}

       {instagramData?.["postsWithComments"]&&
           <InstaReport data={instagramData?.["postsWithComments"]}/>} 
          </div>
          <br />
          <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-6">
            <PostCountBarChart
              dataArray={dayInstaPosts}
              fetching={this.props.isInstagramPostCountFetching}
              error={this.props.instgramPostError}
              title="Instagram Posts (per day)"
              datekey="name"
              countkey="Postscount"
              totalPosts="----"
              socialPlatform="instagram"
              labelling="Posts Count"
            />
          </div>
        </div>
      </div>
    );
  }
}
function mapStateToProps(state) {
  if (
    state?.thirdparty?.data ||
    state?.maindash?.data ||
    state?.facebooksent?.data ||
    state?.twitterAnalysis ||
    state?.twitterPostCount ||
    state?.getword ||
    state?.fbsearch ||
    state?.instagramAnalysis
  ) {
    console.log(state.twitterPostCount);
    return {
      thirdpartyone: state.thirdparty ? state.thirdparty.data : {},
      maindashboard: state.maindash ? state.maindash?.data : {},
      facebooksent: state.facebookAnalysis
        ? state.facebookAnalysis.find(
            (obj) => obj.name === "Sentimental Analysis"
          )
        : {},
      isFacebookPostCountFetching: state.isFacebookPostCountFetching,
      facebookPostCount: state.facebookPostCount ? state.facebookPostCount : [],
      facebookPostError: state.facebookPostError,
      twittersent: state.twitterAnalysis
        ? state.twitterAnalysis.find(
            (obj) => obj.name === "Sentimental analysis"
          )
        : {},
      isTwitterPostCountFetching: state.isTwitterPostCountFetching,
      twitterPostCount: state.twitterPostCount ? state.twitterPostCount : [],
      twitterPostError: state.twitterPostError ? state.twitterPostError : null,
      getwords: state.getword,
      getfbsearch: state.fbsearch,
      instagramsent:
        state.instagramAnalysis &&
        state.instagramAnalysis.find(
          (obj) => obj.name.toLowerCase() === "sentimental analysis"
        ),
      isInstagramPostCountFetching: state.isFacebookPostCountFetching,
      instagramPostCount: state.instagramPostCount
        ? state.instagramPostCount?.data
        : [],
      instagramPostError: state.instagramPostError,
    };
  } else {
    console.log("no data found");
  }
}

export default withRouter(connect(mapStateToProps)(Dashboardtop));

// export default Dashboardtop;
