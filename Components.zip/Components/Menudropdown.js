import React from "react";
// import MenuItem from "@material-ui/core/MenuItem";
// import PermIdentityIcon from "@material-ui/icons/PermIdentity";
// import SettingsIcon from "@material-ui/icons/Settings";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
// import Menu from "@material-ui/core/Menu";
// import AccountCircle from "@material-ui/icons/AccountCircle";
// import IconButton from "@material-ui/core/IconButton";
// import Auth from "../AuthRoutes/Auth";
import Button from "@material-ui/core/Button";
// import ListItem from "@material-ui/core/ListItem";
// import ListItemText from "@material-ui/core/ListItemText";
// import ListItemIcon from "@material-ui/core/ListItemIcon";
import {
  // NavLink,
  Link,
  // Redirect,
  // useHistory,
  // Router as BrowserRouter,
} from "react-router-dom";
// import { withRouter } from "react-router";
// const logout = () => {
//   // localStorage.emailId="";
//   // localStorage.role="";
//   Auth.logout(() => {
//     console.log(props.history);
//     props.history.push("/Login");
//   });

//   // window.location.reload();
// };

const Menudropdown = () => {
  // const [anchorEl, setAnchorEl] = React.useState(null);
  // const open = Boolean(anchorEl);
  // const handleMenu = (event) => {
  //   setAnchorEl(event.currentTarget);
  // };
  // const handleClose = () => {
  //   setAnchorEl(null);
  // };

  return (
    <div>
      {/* <ListItem>
        <ListItemText primary="Profile" />
        <ListItemIcon>
          <IconButton
            // aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleMenu}
            color="inherit"
          >
            <AccountCircle />
          </IconButton>
        </ListItemIcon>
      </ListItem>

      <Menu
        id="menu-appbar"
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        keepMounted
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        open={open}
        onClose={handleClose}
      >
        <MenuItem onClick={handleClose}>
          <PermIdentityIcon />
          Profile
        </MenuItem>
        <MenuItem>
          <SettingsIcon />
          Settings
        </MenuItem>

        <MenuItem>
          <ExitToAppIcon />
          Logout
        </MenuItem>
      </Menu> */}

      <Button
        variant="contained"
        endIcon={<ExitToAppIcon />}
        component={Link}
        to="/Login"
        style={{ background: "white" }}
      >
        {" "}
        Logout
      </Button>
    </div>
  );
};

export default Menudropdown;
