import React, { Component } from "react";
import { fetchtwittercontextualanalysis } from "../Reducers/actions";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

class Twittercontextual extends Component {
  componentWillMount() {
    this.props.dispatch(fetchtwittercontextualanalysis());
  }

  render() {
    return (
      <div>
        abcd
        {/* <div>
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.name}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.source}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Positive
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.positive}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Weekly_positive
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.weekly_positive}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Strongly_positive
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.strongly_positive}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Negative
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.negtive}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Weekly Negative
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.weekly_negative}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Strongly Negative
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.strongly_negetive}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div>
        <div>
          Neutral
          {this.props.twitter ? (
            this.props.twitter.map((a) => <h1>{a.report.neutral}</h1>)
          ) : (
            <p>wait ...</p>
          )}
        </div> */}
      </div>
    );
  }
}
function mapStateToProps(state) {
  return { twitter: state };
}

export default withRouter(connect(mapStateToProps)(Twittercontextual));
