import React, { Component } from "react";
import Button from "@material-ui/core/Button";
import Modal from "@material-ui/core/Modal";
import PrintIcon from "@material-ui/icons/Print";
import CloseIcon from "@material-ui/icons/Close";
import PropTypes from "prop-types";
import { Table } from "react-bootstrap";
import { ExportCSV } from "./ExportCSV";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";

export default function CommentsModal({title, open, handleCloseModal, comments, fileName}) {
  const formatDateTime=(datentime)=>{
    let dateTime=new Date(datentime);
    let formattedTime=dateTime.toLocaleTimeString();
    let formattedDate=dateTime.toLocaleDateString();
 return formattedDate+" "+formattedTime
  }
    return <Modal
        open={open}
        onClose={handleCloseModal}
        style={{ overflow: "scroll" }}
      >
        <div
          style={{
            // width:1800,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Paper
            elevation={3}
            style={{
              textAlign: "left",
              padding: "10px",
              overflow: "scroll",
              width: "900px",
              maxHeight: "900px",
              // height: "900px",
              marginTop: "40px"
            }}
          >
            <div align="right">
              <ExportCSV csvData={comments} fileName={fileName} />
              <IconButton onClick={() => window.print()}>
                <PrintIcon />
              </IconButton>
              <IconButton onClick={handleCloseModal}>
                <CloseIcon />
              </IconButton>
            </div>
  
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>{title}</th>
                </tr>
              </thead>
              <tbody>
                <tr className="d-flex flex-column">
                  {comments ? (
                    comments.map((e) => {
                      return <td style={{ fontSize: "15px" }}><span>{e.message || e.text} </span> <span class="secname">{formatDateTime(e.time || e.date_time)}</span> </td>;
                    })
                  ) : (
                    <h1>No data found!!! </h1>
                  )}
                </tr>
              </tbody>
            </Table>
          </Paper>
        </div>
      </Modal>;
  };
