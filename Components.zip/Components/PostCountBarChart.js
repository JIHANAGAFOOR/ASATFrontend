import React, { useEffect, useState } from "react";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";
import Grid from "@material-ui/core/Grid";
import Link from "@material-ui/core/Link";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";
import CircularProgress from "@material-ui/core/CircularProgress";
import BasicDateRangePicker from "./DatePicker";
import DatePickers from "./DatePicker";
import Button from "@material-ui/core/Button";
import ZoomOutMapIcon from "@material-ui/icons/ZoomOutMap";
import DayPostsModal from "./DayPostsModal";
import {
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Label,
  ResponsiveContainer,
  BarChart,
  Bar,
  Brush,
  ReferenceLine,
} from "recharts";
import { filter } from "@amcharts/amcharts4/.internal/core/utils/Iterator";
import * as URLS from "../Reducers/Constants";
import axios from "axios";
import { Alert } from "react-bootstrap";

const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

Date.prototype.addDays = function (days) {
  var date = new Date(this.valueOf());
  date.setDate(date.getDate() + days);
  return date;
};

Date.prototype.subDays = function (days) {
  var date = new Date(this.valueOf());
  date.setDate(date.getDate() - days);
  return date;
};

const formatDate = function (date) {
  let ye = new Intl.DateTimeFormat("en", { year: "numeric" }).format(date);
  let mo = new Intl.DateTimeFormat("en", { month: "2-digit" }).format(date);
  let da = new Intl.DateTimeFormat("en", { day: "2-digit" }).format(date);
  return `${ye}-${mo}-${da}`;
};

function getDates(startDate, stopDate) {
  var dateArray = new Array();
  var currentDate = startDate;
  while (currentDate <= stopDate) {
    dateArray.push(formatDate(currentDate));
    currentDate = currentDate.addDays(1);
  }
  return dateArray;
}

export default function PostCountBarChart({
  dataArray,
  title,
  datekey,
  countkey,
  totalPosts,
  handleZoomout,
  socialPlatform = "facebook",
  fetching,
  error,
  labelling,
}) {
  const [fromDate, setFromDate] = useState(new Date().subDays(59));
  const [toDate, setTodate] = useState(new Date());
  const [dateRange, setDateRange] = useState(getDates(fromDate, toDate));
  const [graphData, setGraphData] = useState([]);
  const [totalPostsCount, setTotalPostsCount] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [dayWisePosts, setDayWisePosts] = useState([]);

  const showDayWisePostsModal = async (bar) => {
    const accountName = localStorage.getItem("profile") || "pcmc";

    let url;
    if (socialPlatform === "facebook") url = URLS.FACEBOOK_POSTCOUNT;
    else if (socialPlatform === "twitter") url = URLS.INSTAGRAM_POSTCOUNT;
    else url = URLS.TWITTER_POSTCOUNT;

    url = url + `?account_name=${accountName}&on-click=${bar.name}`;

    const headers = {
      "Content-Type": "application/json",
    };

    await axios.get(url, { headers }).then((res) => {
      setDayWisePosts(res.data.onclick_posts_data);
      setShowModal(true);
    });
  };

  const getFromDate = function (date) {
    setFromDate(date);
  };
  const getToDate = function (date) {
    setTodate(date);
  };

  const setDefaultDates = function () {
    const endDate = new Date();
    const startDate = endDate.subDays(59);
    setFromDate(startDate);
    setTodate(endDate);
  };

  const setNewGraphData = function () {
    let dr = dateRange;
    let filterData = [];
    let totalPCount = 0;
    dr.map((ele) => {
      let x = {};
      dataArray.map((graphEle) => {
        if (ele === graphEle.name) {
          totalPCount += Object.values(graphEle)[1];
          const date = graphEle.name.split("-");
          x = {
            ...graphEle,
            name: `${date[2]}-${date[1]}-${date[0]}`,
          };
        }
      });
      filterData = x ? [...filterData, x] : [...filterData, { [`${ele}`]: 0 }];
    });
    setTotalPostsCount(totalPCount);
    setGraphData(filterData);
  };

  if (graphData.length === 0) {
    if (dataArray && dataArray.length > 0) {
      setNewGraphData();
    }
  }

  useEffect(() => {
    if (fromDate && toDate) setDateRange(getDates(fromDate, toDate));
  }, [fromDate, toDate]);

 // console.log("fetching, error, graphData", fetching, error, graphData);

  if (fetching) {
    return (
      <div
        style={{
          alignItems: "center",
          margin: "auto",
          minWidth: "300px",
          minHeight: "400px",
        }}
      >
        <CircularProgress />
      </div>
    );
  } else if (error) {
    return (
      <div>
        <DayPostsModal
          title="Day wise posts"
          open={showModal}
          handleCloseModal={() => setShowModal(false)}
          posts={dayWisePosts}
          fileName="daily_posts"
        />
        <Paper elevation={3}>
          <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
              marginBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight ">
              <div class="mr-auto pt-2 bd-highlight"> {i18next.t(title)}</div>
            </div>
          </Typography>
          <ResponsiveContainer height={300} width="100%">
            <Alert variant="danger">Error occurred While Loading</Alert>;
          </ResponsiveContainer>
        </Paper>
      </div>
    );
  } else if (graphData?.length < 1) {
    return (
      <div>
        <DayPostsModal
          title="Day wise posts"
          open={showModal}
          handleCloseModal={() => setShowModal(false)}
          posts={dayWisePosts}
          fileName="daily_posts"
        />
        <Paper elevation={3}>
          <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
              marginBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight ">
              <div class="mr-auto pt-2 bd-highlight"> {i18next.t(title)}</div>
            </div>
          </Typography>
          <ResponsiveContainer height={300} width="100%">
            <Alert variant="warning">{i18next.t("No Data Found")}</Alert>
          </ResponsiveContainer>
        </Paper>
      </div>
    );
  } else if (graphData && graphData.length > 0) {
    return (
      <div>
        <DayPostsModal
          title="Day wise posts"
          open={showModal}
          handleCloseModal={() => setShowModal(false)}
          posts={dayWisePosts}
          fileName="daily_posts"
        />
        <Paper elevation={3}>
          <Typography
            style={{
              paddingLeft: "20px",
              paddingTop: "10px",
              background: "#b0bec5",
              paddingBottom: "10px",
              marginBottom: "10px",
            }}
          >
            <div class="d-flex bd-highlight ">
              <div class="mr-auto pt-2 bd-highlight"> {i18next.t(title)}</div>
              <div class=" bd-highlight">
                {handleZoomout && (
                  <Button onClick={handleZoomout}>
                    <ZoomOutMapIcon />
                  </Button>
                )}
              </div>
            </div>
          </Typography>

          <div class="d-inline mt-2 p-2 bg-primary text-white">
            {i18next.t("Total Post")} {"-"} {totalPostsCount}{" "}
          </div>
          <div className="d-flex pl-3 pr-3">
            <DatePickers
              label="From"
              getDate={getFromDate}
              defaultDate={fromDate}
            />
            <DatePickers label="To" getDate={getToDate} defaultDate={toDate} />
            <Button
              variant="contained"
              component={Link}
              style={{ background: "white" }}
              onClick={setNewGraphData}
              className={"h-50 mt-3 text-decoration-none"}
            >
              {i18next.t("SUBMIT")}
            </Button>
          </div>
          <ResponsiveContainer height={300} width="100%">
            <BarChart
              width={500}
              height={300}
              data={
                graphData && graphData.length > 0 ? (
                  graphData
                ) : (
                  <div
                    style={{
                      alignItems: "center",
                      margin: "auto",
                      minWidth: "300px",
                      minHeight: "400px",
                    }}
                  >
                    <CircularProgress />
                  </div>
                )
              }
              margin={{
                top: 5,
                right: 10,
                left: -10,
                bottom: 5,
              }}
            >
              {/* <CartesianGrid strokeDasharray="3 3" /> */}
              <XAxis dataKey={datekey} interval={"preserveEnd"}>
                <Label
                  value={"Date --->"}
                  offset={-2}
                  position="insideBottom"
                />
              </XAxis>
              <YAxis />
              <Tooltip contentStyle={{ color: "#143491" }} />
              <Legend
                verticalAlign="top"
                wrapperStyle={{ lineHeight: "40px" }}
              />
              <ReferenceLine y={0} stroke="#000" />
              {/* <Brush dataKey="name" height={30} stroke="#90caf9" /> */}
              {/* <Bar dataKey="Postscount" fill="#8884d8" /> */}
              <Bar
                dataKey={countkey}
                fill="#90caf9"
                onClick={showDayWisePostsModal}
                name={labelling}
              />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </div>
    );
  } else {
    return null;
  }
}
