// import i18next from "i18next";
// import HttpBackend from "i18next-http-backend";
import LanguageDetector from "i18next-browser-languagedetector";
import { initReactI18next } from "react-i18next";
import  i18n  from "i18next";
import translationEN from './locales/en/translationEN.json'
import translationHI from './locales/hi/translationHI.json'
import translationMR from './locales/mr/translationMR.json'


// const apiKey = "seRrad2aizPwnaxismkFBg";
// const loadPath = `https://api.i18nexus.com/project_resources/translations/{{lng}}/{{ns}}.json?api_key=${apiKey}`;


const resources = {
  en: {
    translation : translationEN
  },

  hi: {
    translation : translationHI
  },

  mr : {
    translation : translationMR
  }
}

i18n
.use (initReactI18next)
.init({
  resources,
  lang : 'en',
  keySeparator : false , 
  interpolation: {
    escapeValue: false
  }
})

export default i18n
// i18next
//   .use(HttpBackend)
//   .use(LanguageDetector)
//   .use(initReactI18next)
//   .init({
//     fallbackLng: "en",

//     ns: ["default"],
//     defaultNS: "default",

//     supportedLngs: ["en","hi","mr"],
    
//     backend: {
//       loadPath: loadPath
//     }
//   })