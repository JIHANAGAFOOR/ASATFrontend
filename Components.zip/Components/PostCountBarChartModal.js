import React from "react";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import i18next from "i18next";
import CircularProgress from "@material-ui/core/CircularProgress";
import Modal from "@material-ui/core/Modal";
import CloseIcon from "@material-ui/icons/Close";
import PrintIcon from "@material-ui/icons/Print";
import {
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  Brush,
  ReferenceLine,
  CartesianGrid,
} from "recharts";

const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

export default function PostCountBarChartModal({dataArray, open, title, datekey, labellingModal,

	countkey,
	handleClose}) {  
  return <Modal open={open} onClose={handleClose}>
    <div
      style={{
        // width:1800,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Paper
        elevation={3}
        style={{
          textAlign: "center",
          textAlignVertical: "center",
          padding: "10px",
        }}
      >
        <Typography>{i18next.t(title)}</Typography>
        <div align="right">
          <IconButton onClick={() => window.print()}>
            <PrintIcon />
          </IconButton>
          <IconButton onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </div>

        <ResponsiveContainer height={800} width={1800}>
          <BarChart
            width={1000}
            height={300}
            data={
              dataArray && dataArray.length > 0 ? (
                dataArray
              ) : (
                <p>
                  <CircularProgress />
                </p>
              )
            }
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            {/* <CartesianGrid strokeDasharray="3 3" /> */}
            <XAxis dataKey={datekey} />
            <YAxis />
            <Tooltip contentStyle={{ color: '#143491' }} />
            <Legend
              verticalAlign="top"
              wrapperStyle={{ lineHeight: "40px" }}
            />
            <ReferenceLine y={0} stroke="#000" />
            <Bar dataKey={countkey} fill="#8884d8" name={labellingModal} /> 
          </BarChart>
        </ResponsiveContainer>
      </Paper>
    </div>
  </Modal>;

};
