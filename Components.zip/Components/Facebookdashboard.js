import React, { Component } from "react";
import Grid from "@material-ui/core/Grid";
import "../App.css";
import {
  fetchmaindashboard,
  fetchfacebooksentimental,
  fetchfacebookPostCount,
  fetchfacebooksearch,
} from "../Reducers/actions";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import * as URLS from "../Reducers/Constants";
import axios from "axios";
import i18next from "i18next";
import Typography from "@material-ui/core/Typography";
import Toolbar from "@material-ui/core/Toolbar";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";
import PostCountBarChart from "./PostCountBarChart";
import PostCountBarChartModal from "./PostCountBarChartModal";
import CommentsModal from "./CommentsModal";
import MetricWidget from "./MetricWidget";
import SentimentalPieChart from "./SentimentalPieChart";
import SearchAnalysis from './SearchAnalysis'
import SentimentalPieChartModal from "./SentimentalPieChartModal";
import FacebookReport from './FacebookReport'

const COLORS = [
  "#18ffff",
  "#9fe39d",
  "#f56767",
  "#850604",
  "#ffe0b2",
  "#ffcc80",
  "#ffb74d",
  "#ffa726",
  "#ff9800",
  "#fb8c00",
  "#f57c00",
  "#ef6c00",
  "#e65100",
];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${payload[0].name} : ${payload[0].value} % `}</p>
      </div>
    );
  }
  return null;
};

class Dashboard extends Component {
  componentDidMount() {
    let { dispatch } = this.props;
    // dispatch(fetchfacebookprofile());
    dispatch(fetchmaindashboard());
    dispatch(fetchfacebooksentimental());
    dispatch(fetchfacebookPostCount());
  }
  constructor() {
    super();
    this.state = {
      fbsenti: false,
      posts: false,
      facebookpos: false,
      facebookneg: false,
      facebookneu: false,
      ch: null,
	    searchValue: '',
	    click:false,
    };
  }

  // static jsfiddleUrl = "https://jsfiddle.net/alidingling/3Leoa7f4/";
  handleMouseEnter = (o) => {
    const { dataKey } = o;
    const { opacity } = this.state;

    this.setState({
      opacity: { ...opacity, [dataKey]: 0.5 },
    });
  };

  handleMouseLeave = (o) => {
    const { dataKey } = o;
    const { opacity } = this.state;

    this.setState({
      opacity: { ...opacity, [dataKey]: 1 },
    });
  };

  handleOpenfbsenti = (e) => {
    e.preventDefault();
    this.setState({ fbsenti: true });
  };

  handleClosefbsenti = (e) => {
    e.preventDefault();
    this.setState({ fbsenti: false });
  };

  handleOpenfbposts = (e) => {
    e.preventDefault();
    this.setState({ posts: true });
  };

  handleClosefbposts = (e) => {
    e.preventDefault();
    this.setState({ posts: false });
  };

  handleOpenfacebookpositive = (e) => {
    e.preventDefault();
    this.setState({ facebookpos: true });
  };

  handleClosefacebookpositive = (e) => {
    e.preventDefault();
    this.setState({ facebookpos: false });
  };

  handleOpenfacebooknegative = (e) => {
    e.preventDefault();
    this.setState({ facebookneg: true });
  };

  handleClosefacebooknegative = (e) => {
    e.preventDefault();
    this.setState({ facebookneg: false });
  };

  handleOpenfacebookneutral = (e) => {
    e.preventDefault();
    this.setState({ facebookneu: true });
  };

  handleClosefacebookneutral = (e) => {
    e.preventDefault();
    this.setState({ facebookneu: false });
  };

  changeWord = async (e) => {
    this.props.dispatch(fetchfacebooksearch(e.target.value));
  };
handleSubmit= async (e)=>{
	 e.preventDefault();

console.log("SERACH ", this.state.searchValue)
	this.props.dispatch(fetchfacebooksearch(this.state.searchValue));
}
 handleInputChange = (e) => {
	 console.log("nn ",e.target.value)
    this.setState({ searchValue: e.target.value });
	
  };

  render() {
    let arr = [];
    let fbpostvalue = [];
    let fbnegative = [];
    let fbneutral = [];
	  let fbarr=[]
let searchArray={}
	  let commentsArray={}
    const lang = localStorage.getItem("search") || "default";
	  //console.log("LANG ",lang)
	  //console.log("WORDS ",JSON.stringify(this.props))

    //getword
    let words = this.props.getwords || [];
let search=this.props.facebooksearch
	  
    if (this.props.facebooksent) {
	    commentsArray=this.props.facebooksent.comments;
	    console.log("DATAZZ  "+JSON.stringify(this.props.facebooksent.comments))
	   let dataSearch=this.props.facebooksent.data || {}
	    
	    searchArray=dataSearch
      let objs = this.props.facebooksent.report || {};
      arr = Object.keys(objs).map((key) => ({
        name: i18next.t(key),
        value: Number(objs[key]),
      }));
    }
//console.log("DATAZZ  "+JSON.stringify(arr))
    // for fb
   // if (this.props.facebooktwo) {
     // let obj = this.props.facebooktwo || {};
      //let objs = obj.report || {};
      //var result = Object.keys(objs).map((key) => [key, objs[key]]);
      //fbpostvalue = result[5][1];
      //fbnegative = result[6][1];
      //fbneutral = result[7][1];
   // }
	  //
	  //
	 // if (this.props.facebooksent !== undefined) {
     // let objs = this.props.facebooksent.report;
    //  fbarr = Object.keys(objs).map((key) => ({
    //    name: i18next.t(key),
      //  value: Number(objs[key]),
    //  }));

      //let fbcomments = this.props.facebooksent.comments;
     // fbpostvalue = fbcomments["positive_description"];
     // fbnegative = fbcomments["negative_description"];
     // fbneutral = fbcomments["neutral_description"];
    //}

    
    if (this.props.facebookPostCount) {
      let posts = this.props.facebookPostCount["no_of_posts"];
      var dayposts = Object.keys(posts || {}).map((key) => ({
        name: i18next.t(key.slice(0, 10)),
        Postscount: posts[key],
      }));
    }

   // const facebookFileName = "comments";
   // const fneutral = [fbneutral];
   // const fpositive = [fbpostvalue];
   // const fnegative = [fbnegative];

    return (
      <div
        style={{
          paddingLeft: "20px",
          paddingRight: "20px",
          paddingTop: "100px",
        }}
      >
	    {/* <CommentsModal
          title="Neutral Comments"
          open={this.state.facebookneu}
          handleCloseModal={this.handleClosefacebookneutral}
          comments={fbneutral}
          fileName={facebookFileName}
        />

        <CommentsModal
          title="Negative Comments"
          open={this.state.facebookneg}
          handleCloseModal={this.handleClosefacebooknegative}
          comments={fbnegative}
          fileName={facebookFileName}
        />

        <CommentsModal
          title="Positive Comments"
          open={this.state.facebookpos}
          handleCloseModal={this.handleClosefacebookpositive}
          comments={fbpostvalue}
          fileName={facebookFileName}
        />

        <SentimentalPieChartModal
          dataArray={arr}
          open={this.state.fbsenti}
          title="Sentimental Analysis"
          handleClose={this.handleClosefbsenti}
        />
*/}
        <PostCountBarChartModal
          dataArray={dayposts}
          open={this.state.posts}
          title="Posts per day"
          datekey="name"
          countkey="Postscount"
	    labellingModal="Posts Count"
          handleClose={this.handleClosefbposts}
        />

        <Toolbar variant="dense" style={{ paddingBottom: "20px" }}>
          <Typography variant="h5" style={{ flexGrow: "1" }}>
            {i18next.t("Facebook Analysis")}
          </Typography>
          <Breadcrumbs aria-label="breadcrumb" textalign="right">
            <Link color="inherit">{i18next.t("Dashboard")}</Link>

            <Typography color="textPrimary">
              {i18next.t("Facebook Analysis")}
            </Typography>
          </Breadcrumbs>
        </Toolbar>
        <br />

        {/* </AppBar> */}

        {/* <h1 align="center"> Facebook Analysis</h1> */}
        <Grid container spacing={3} justify="space-between">
          <MetricWidget
            iconType="friends"
            backgroundColor="#3b5998"
            name="Friends"
            count={this.props.maindashboard?.facebook.friends.followers_count}
            size={6}
          />

          <MetricWidget
            iconType="posts"
            // backgroundColor="#ffc107"
            backgroundColor="#3b5998"

            name="Posts"
            count={this.props.maindashboard?.facebook.fb_total_number_of_posts}
            size={6}
          />
        </Grid>
        <div class="row mt-4 mb-4">
          <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-6">
	      
	     
	     <SearchAnalysis 
	    searchArray={searchArray}
              dataArray={arr}
	    
              title="Search Analysis"
              handleOpenPositive={this.handleOpenfacebookpositive}
              handleOpenNegative={this.handleOpenfacebooknegative}
              handleOpenNeutral={this.handleOpenfacebookneutral}
	      handleSubmit={this.handleSubmit}
	      searchValue={this.state.searchValue}
          setSearchValue={this.handleInputChange}
              handleZoomout={this.handleOpenfbsenti}
	    commentsArray={commentsArray}
            />
	   
          </div>
		 <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-6">
            <PostCountBarChart
              dataArray={dayposts}
              title="Posts per day"
              datekey="name"
              countkey="Postscount"
              totalPosts="----"
              handleZoomout={this.handleOpenfbposts}
              labelling="Post Count"
            />
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  if (state.facebookAnalysis && state.getword && state.maindash) {
    return {
      maindashboard: state.maindash ? state.maindash?.data : [],
      facebooksent: state.facebookAnalysis
        ? state.facebookAnalysis.find(
            (obj) => obj.name === "Sentimental Analysis"
          )
        : {},
      facebookPostCount: state.facebookPostCount ? state.facebookPostCount : [],
      getwords: state.getword ? state.getword : [],
	    facebooksearch:state.facebookAnalysis?state.facebookAnalysis:[]
    };
  } else {
    console.log("No data found");
  }
}

export default withRouter(connect(mapStateToProps)(Dashboard));
