import React, { Component } from "react";
import Typography from "@material-ui/core/Typography";
import Toolbar from "@material-ui/core/Toolbar";
import Breadcrumbs from "@material-ui/core/Breadcrumbs";
import Link from "@material-ui/core/Link";
import { scaleOrdinal } from "d3-scale";
import { schemeCategory10 } from "d3-scale-chromatic";
import PropTypes from "prop-types";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import { fetchthirdpartydashboard } from "../Reducers/actions";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Modal from "@material-ui/core/Modal";
import CloseIcon from "@material-ui/icons/Close";
import PrintIcon from "@material-ui/icons/Print";
import IconButton from "@material-ui/core/IconButton";
import ZoomOutMapIcon from "@material-ui/icons/ZoomOutMap";
import Button from "@material-ui/core/Button";
import GravenceExcel from "./GraveinceExcel";
import GravienceStage from "./GravienceStage";
import GrevChartPie from './GrevChartPie';
import GrievanceForcast from  './GrievanceForcast'
import {
  Cell,
  Legend,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Brush,
  ReferenceLine,
  Label,
} from "recharts";
import i18next from "i18next";

const colors = scaleOrdinal(schemeCategory10).range();

const getPath = (x, y, width, height) => `M${x},${y + height}
          C${x + width / 3},${y + height} ${x + width / 2},${y + height / 3} ${
  x + width / 2
}, ${y}
          C${x + width / 2},${y + height / 3} ${x + (2 * width) / 3},${
  y + height
} ${x + width}, ${y + height}
          Z`;

const TriangleBar = (props) => {
  const { fill, x, y, width, height } = props;

  return <path d={getPath(x, y, width, height)} stroke="none" fill={fill} />;
};

TriangleBar.propTypes = {
  fill: PropTypes.string,
  x: PropTypes.number,
  y: PropTypes.number,
  width: PropTypes.number,
  height: PropTypes.number,
};

class Gravience extends Component {
  componentDidMount() {
    let { dispatch } = this.props;

    dispatch(fetchthirdpartydashboard());
  }
  constructor() {
    super();
    this.state = {
      stagewisezoom: false,
      prabhagzoom: false,
      dynmodel: false,
      modeldata: [],
      modelnames: "",
    };
  }

  handleOpenstagewisezoom = (e) => {
    e.preventDefault();

    this.setState({ stagewisezoom: true });
  };
  handleClosestagewisezoom = (e) => {
    e.preventDefault();

    this.setState({ stagewisezoom: false });
  };
  handleOpenprabhagzoom = (e) => {
    e.preventDefault();

    this.setState({ prabhagzoom: true });
  };
  handleCloseprabhagzoom = (e) => {
    e.preventDefault();

    this.setState({ prabhagzoom: false });
  };
  handleclosedynamic = () => {
    this.setState({
      dynmodel: !this.state.dynmodel,
      modeldata: [],
      modelnames: "",
    });
  };
  render() {
    var arr = [];
    let arr2 = [];
    let arr3 = [];

    if (this.props.thirdpartyone) {
      let objs = this.props?.thirdpartyone.stage_wise_data || {};
      var result = Object.keys(objs).map((key) => [key, objs[key]]);

      let temp = [];
      result.map((element, index) => {
        let newtemp = {
          name: i18next.t(element[1].name),
          value: Number(element[1].value),
        };
        temp.push(newtemp);
      });
      arr3 = temp;
    }

    if (this.props.thirdpartyone) {
      arr = this.props?.thirdpartyone.stage_wise_data || [];
      arr2 = this.props?.thirdpartyone.prabhag_wise_data || [];

      var namesarray = [];
      for (let i = 0; i < arr.length; i++) {
        var names = arr[i].name;
        namesarray.push(names);
      }

      //for wardwise
      var wardno = arr2.map((a) => a.prabhags_no);
      var reports = arr2.map((b) => b.report) || [];
      var status = reports.map((c) => c.status) || [];
      
      var prabhagas = [];
      for (let i = 0; i < status.length; i++) {
        let objpra = {
          // const date = game.created_time.split("T")[0];

          prabhags_no: i,
          assigned: status[i],
          attended: status[i],
          inprocess: status[i],
          refused: status[i],
          closed: status[i],
          reopened: status[i],
        };
        prabhagas.push(objpra);
      }
      //for dynamic
      var arrnames = arr.map((c) => c.name) || [];
      var dyn = arr.map((a) => a.report) || [];

      let valuedynamic;
      let datesdynamic;

      var temp = [];
      dyn.map((element) => {
        valuedynamic = Object.values(element);
        datesdynamic = Object.keys(element);
        let tempone = [];
        for (let i = 0; i < valuedynamic.length; i++) {
          let Obj = {
            name: datesdynamic[i].split("-").slice(0, 2).join("-"),
            count: valuedynamic[i],
          };
          tempone.push(Obj);
        }
        temp.push(tempone);
      });
    }

    return (
      <div
        style={{
          paddingTop: "100px",
          paddingLeft: "30px",
          paddingRight: "30px",
        }}
      >
        {this.state.dynmodel ? (
          <div>
            <Modal open={this.state.dynmodel} onClose={this.handleclosedynamic}>
              <div
                style={{
                  // width:1800,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Paper
                  elevation={3}
                  style={{
                    textAlign: "center",
                    textAlignVertical: "center",
                    padding: "10px",
                  }}
                >
                  <Typography>{this.state.modelnames}</Typography>
                  <div align="right">
                    <IconButton onClick={() => window.print()}>
                      <PrintIcon />
                    </IconButton>
                    <IconButton onClick={this.handleclosedynamic}>
                      <CloseIcon />
                    </IconButton>
                  </div>
                  <ResponsiveContainer height={800} width={1800}>
                    <BarChart
                      width={500}
                      height={300}
                      data={this.state.modeldata}
                      layout="vertical"
                      margin={{
                        top: 0,
                        right: 10,
                        left: 0,
                        bottom: 0,
                      }}
                      barSize={10}
                    >
                      <XAxis
                        type="number"
                        // hide
                        dataKey="count..."
                      />
                      <YAxis
                        type="category"
                        // hide
                        dataKey="name"
                      />
                      <Tooltip contentStyle={{ color: "#143491" }} />
                      <Legend
                        layout="vertical"
                        verticalAlign="top"
                        align="right"
                      />

                      <Bar
                        dataKey="count"
                        fill="#8884d8"
                        background={{ fill: "#eee" }}
                      >
                        {this.state.modeldata.map((entry, index) => (
                          <Cell
                            fill={
                              entry.count <= 25
                                ? "#089c19" // green
                                : entry.count <= 50
                                ? "#d4bb02" //yellow
                                : entry.count <= 75
                                ? "#d48402" //orange
                                : "#d41002"
                            }
                          /> //red
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Paper>
              </div>
            </Modal>
          </div>
        ) : null}

        <Modal
          open={this.state.stagewisezoom}
          onClose={this.handleClosestagewisezoom}
        >
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                textAlignVertical: "center",
                padding: "10px",
              }}
            >
              <Typography>{i18next.t("Stage Wise Data")}</Typography>
              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleClosestagewisezoom}>
                  <CloseIcon />
                </IconButton>
              </div>
              <ResponsiveContainer height={800} width={1800}>
                <BarChart
                  width={1000}
                  height={200}
                  data={
                    this.props.thirdpartyone !== undefined ? (
                      arr3
                    ) : (
                      <p>Waiting..</p>
                    )
                  }
                  margin={{
                    top: 15,
                    right: 10,
                    left: 0,
                    bottom: 5,
                  }}
                >
                  {/* <CartesianGrid strokeDasharray="3 3" /> */}
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  <Legend layout="vertical" verticalAlign="top" align="right" />

                  <Bar
                    dataKey="value"
                    fill="#8884d8"
                    shape={<TriangleBar />}
                    label={{ position: "top" }}
                  >
                    {arr.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={colors[index % 20]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </div>
        </Modal>
        <Modal
          open={this.state.prabhagzoom}
          onClose={this.handleCloseprabhagzoom}
        >
          <div
            style={{
              // width:1800,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Paper
              elevation={3}
              style={{
                textAlign: "center",
                textAlignVertical: "center",
                padding: "10px",
              }}
            >
              <Typography>{i18next.t("Prabhag Wise Data")}</Typography>
              <div align="right">
                <IconButton onClick={() => window.print()}>
                  <PrintIcon />
                </IconButton>
                <IconButton onClick={this.handleCloseprabhagzoom}>
                  <CloseIcon />
                </IconButton>
              </div>
              <ResponsiveContainer height={800} width={1800}>
                <BarChart
                  width={500}
                  height={300}
                  data={
                    this.props.thirdpartyone !== undefined ? (
                      arr2
                    ) : (
                      <p>Waiting..</p>
                    )
                  }
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <XAxis dataKey="prabhags_no" />
                  <YAxis />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  <Legend
                    verticalAlign="top"
                    wrapperStyle={{ lineHeight: "40px" }}
                  />
                  <ReferenceLine y={0} stroke="#000" />
                  <Brush dataKey="prabhags_no" height={30} stroke="#8884d8" />
                  <Bar dataKey="count" fill="#8884d8" />
                  {/* <Bar dataKey="uv" fill="#82ca9d" /> */}
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </div>
        </Modal>

        <Toolbar variant="dense">
          <Typography variant="h5" style={{ flexGrow: "1" }}>
            {i18next.t("Grievance Data Analysis")}
          </Typography>
          <Breadcrumbs aria-label="breadcrumb" textalign="right">
            <Link color="inherit">{i18next.t("Dashboard")}</Link>
            <Typography color="textPrimary">
              {i18next.t("Grievance Data Analysis")}
            </Typography>
          </Breadcrumbs>
        </Toolbar>
        <br />

        <Grid container spacing={3} justify="space-between">
          <Grid item xs={12} sm={12} md={12} lg={6} xl={6}>
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                }}
              >
                {i18next.t("STAGE WISE DATA")}
              </Typography>
              <div align="right">
                <Button onClick={this.handleOpenstagewisezoom}>
                  <ZoomOutMapIcon />
                </Button>
              </div>
              <ResponsiveContainer height={200} width="100%">
                <BarChart
                  width={1000}
                  height={200}
                  data={
                    this.props.thirdpartyone !== undefined ? (
                      arr3
                    ) : (
                      <p>Waiting..</p>
                    )
                  }
                  margin={{
                    top: 15,
                    right: 10,
                    left: 0,
                    bottom: 5,
                  }}
                >
                  <XAxis dataKey="name">
                    <Label
                      value={"Name--->"}
                      offset={0}
                      position="insideBottom"
                    />
                  </XAxis>
                  <YAxis />
                  <Legend layout="vertical" verticalAlign="top" align="right" />
                  <Tooltip
                    //  cursor={{ fill: "black" }}
                    contentStyle={{ color: "#143491" }}
                  />
                  <Bar
                    dataKey="value"
                    fill="#8884d8"
                    shape={<TriangleBar />}
                    label={{ position: "top" }}
                  >
                    {arr.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={colors[index % 20]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>
          <Grid justify="center" item xs={12} sm={12} md={12} lg={6} xl={6}>
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                }}
              >
                {i18next.t("PRABHAG WISE DATA")}
              </Typography>
              <div align="right">
                <Button onClick={this.handleOpenprabhagzoom}>
                  <ZoomOutMapIcon />
                </Button>
              </div>
              <ResponsiveContainer height={200} width="100%">
                <BarChart
                  width={500}
                  height={300}
                  data={
                    this.props.thirdpartyone !== undefined ? (
                      arr2
                    ) : (
                      <p>Waiting..</p>
                    )
                  }
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <XAxis dataKey="prabhags_no" />
                  <YAxis />
                  <Tooltip contentStyle={{ color: "#143491" }} />
                  <Legend
                    verticalAlign="top"
                    wrapperStyle={{ lineHeight: "40px" }}
                  />
                  <ReferenceLine y={0} stroke="#000" />
                  <Brush dataKey="prabhags_no" height={20} stroke="#8884d8" />
                  <Bar dataKey="count" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </Paper>
          </Grid>

          <Grid item xs={12}>
            {temp && (
              <div>
                <Grid container justify="flex-start" spacing={3}>
                  {temp.map((singlechart, i) => (
                    <Grid item xs={4}>
                      <Paper elevation={3}>
                        <Typography
                          style={{
                            paddingLeft: "20px",
                            paddingTop: "10px",
                            background: "#b0bec5",
                          }}
                        >
                          {i18next.t(arrnames[i])}
                        </Typography>
                        <div align="right">
                          <Button
                            onClick={() => {
                              this.setState({
                                dynmodel: !this.state.dynmodel,
                                modeldata: singlechart,
                                modelnames: arrnames[i],
                              });
                            }}
                          >
                            <ZoomOutMapIcon />
                          </Button>
                        </div>
                        <ResponsiveContainer height={300} width="100%">
                          <BarChart
                            width={500}
                            height={300}
                            data={singlechart}
                            layout="vertical"
                            margin={{
                              top: 0,
                              right: 20,
                              left: 30,
                              bottom: 0,
                            }}
                            barSize={10}
                          >
                            <XAxis
                              type="number"
                              dataKey="count"
                              interval={"preserveStartEnd"}
                            />
                            <YAxis
                              type="category"
                              dataKey="name"
                              label={{
                                value: "Month/Year--->",
                                angle: -90,
                                position: "insideLeft",
                                textAnchor: "middle",
                                offset: -10,
                              }}
                            />
                            <Tooltip contentStyle={{ color: "#143491" }} />
                            <Legend
                              layout="vertical"
                              verticalAlign="top"
                              align="right"
                            />

                            <Bar
                              dataKey="count"
                              fill="#52ccc6"
                              background={{ fill: "#eee" }}
                            >
                              {singlechart.map((entry, index) => (
                                <Cell /> //red
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </Paper>
                    </Grid>
                  ))}
                </Grid>
              </div>
            )}
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={6} xl={6}>
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                }}
              >
                {i18next.t("CUMULATIVE STAGE WISE MEAN COMPLETION TIME")}
              </Typography>
              <div align="right">
                {/* <Button onClick={this.handleOpenstagewisemeanzoom}> */}
	    {/* <ZoomOutMapIcon />*/}
                {/* </Button> */}
              </div>
              <ResponsiveContainer height={470} width="100%">
              <GravenceExcel />
                
              </ResponsiveContainer>
            </Paper>
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={6} xl={6}>
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                }}
              >
                {i18next.t("COMPLETION TIME FOR EACH STAGE ")}
              </Typography>
              <div align="right">
                {/* <Button onClick={this.handleOpenstagewisemeanzoom}> */}
	    {/*<ZoomOutMapIcon />*/}
                {/* </Button> */}
              </div>
              <ResponsiveContainer height={470} width="100%">
              <GravienceStage />
                
              </ResponsiveContainer>
            </Paper>
          </Grid>
          <Grid item xs={12} sm={12} md={12} lg={6} xl={6}>
            <Paper elevation={3}>
              <Typography
                style={{
                  paddingLeft: "20px",
                  paddingTop: "10px",
                  background: "#b0bec5",
                }}
              >
                {i18next.t("COMPLETION TIME FOR EACH STAGE (Percentage)")}
              </Typography>
              <div align="right">
                {/* <Button onClick={this.handleOpenstagewisemeanzoom}> */}
	    {/* <ZoomOutMapIcon />*/}
                {/* </Button> */}
              </div>
              <ResponsiveContainer height={450} width="100%">
              <GrevChartPie />
                
              </ResponsiveContainer>
            </Paper>
          </Grid>
	     <GrievanceForcast />
        </Grid>
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    thirdpartyone: state.thirdparty.data,
  };
}

export default withRouter(connect(mapStateToProps)(Gravience));
