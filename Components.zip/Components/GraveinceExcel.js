import React, { useState} from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { GrevienceData } from './GravienceData';

const GravenceExcel = () => {
  const [data, setData] = useState(GrevienceData);
  
  
  const prepareDataForChart = () => {
    const meanCompletionTimes = calculateMeanCompletionTime();
    const chartData = [];

    Object.keys(meanCompletionTimes).forEach(subject => {
        const subjectData = { subject };

        Object.keys(meanCompletionTimes[subject]).forEach(stage => {
            subjectData[stage] = meanCompletionTimes[subject][stage];
        });

        chartData.push(subjectData);
    });

    return chartData;
};

const calculateMeanCompletionTime = () => {
    const meanCompletionTimes = {};

    data.forEach(item => {
        const { Subject, Stage, CompletionTime } = item;

        if (!meanCompletionTimes[Subject]) {
            meanCompletionTimes[Subject] = {};
        }

        if (!meanCompletionTimes[Subject][Stage]) {
            meanCompletionTimes[Subject][Stage] = {
                total: 0,
                count: 0
            };
        }

        meanCompletionTimes[Subject][Stage].total += parseInt(CompletionTime); // Parse CompletionTime as an integer
        meanCompletionTimes[Subject][Stage].count++;
    });

    Object.keys(meanCompletionTimes).forEach(subject => {
        Object.keys(meanCompletionTimes[subject]).forEach(stage => {
            const { total, count } = meanCompletionTimes[subject][stage];
            if (count !== 0) {
                meanCompletionTimes[subject][stage] = Math.round(total / count);
            } else {
                meanCompletionTimes[subject][stage] = 0; // or any other appropriate value
            }
        });
    });

    return meanCompletionTimes;
};
  const chartData = prepareDataForChart();

console.log("chartData",chartData)
  return (
    <div>
      {/* <h2>Mean Completion Time for Different Stages by Subject</h2> */}
      <BarChart
        width={400}
        height={430}
        data={chartData}
        layout="vertical"
        margin={{ top: 16, left: 16, bottom: 0 }}
      >
        
        <XAxis type="number" />
        <YAxis dataKey="subject" type="category" width={100}  textAnchor="end" />
        <Tooltip />
        <Legend />
        <Bar dataKey="ASSIGNED" stackId="a" fill="#C222B6" barSize={10} />
        <Bar dataKey="CLOSED" stackId="a" fill="#8884d8" />
        <Bar dataKey="REOPEN" stackId="a" fill="#FFA500" />
      </BarChart>
    </div>
  );
};

export default GravenceExcel;
