import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import TimelineIcon from "@material-ui/icons/Timeline";
import { Route, Link, Switch, Redirect } from "react-router-dom";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Drawer from "@material-ui/core/Drawer";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ChangeLanguage from "./ChangeLanguage";
import ChangeProfiles from "./ChangeProfiles";
import Dashboard from "./Dashboard";
import Cms from "./Cms";
import Webcrawler from "./Webcrawling";
import Aboutus from "./Aboutus";
import Footer from "../Footer";
import Signin from "./Signin";
import Dashboardtop from "./Dashboardtop";
import { createMuiTheme, ThemeProvider } from "@material-ui/core/styles";
import Switchtheme from "@material-ui/core/Switch";
import DashboardIcon from "@material-ui/icons/Dashboard";
import InfoIcon from "@material-ui/icons/Info";
import Facebookdashboard from "./Facebookdashboard";
import LanguageIcon from "@material-ui/icons/Language";
import Brightness4Icon from "@material-ui/icons/Brightness4";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import Collapse from "@material-ui/core/Collapse";
import TwitterIcon from "@material-ui/icons/Twitter";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import FacebookIcon from "@material-ui/icons/Facebook";
import Logowhite from "../Images/logo.jpg";

// import Logowhite from "../Images/200x70-ASAT-White.png";
import Instagramdashboard from "../Components/Instagramdashboard";
import InstagramIcon from "@material-ui/icons/Instagram";
import { deepOrange, orange } from "@material-ui/core/colors";
import Menudropdown from "./Menudropdown";
import Logo from "../Images/logo.jpg";
import Gravience from "./Gravience";
import AssessmentIcon from "@material-ui/icons/Assessment";
import i18next from "i18next";

import Modal from "@material-ui/core/Modal";
import CloseIcon from "@material-ui/icons/Close";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";
import { Button } from "react-bootstrap";
// import "../CSS/Charts.css";
const drawerWidth = 250;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexGrow: 1,
  },
  appBar: {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: drawerWidth,
    height: "3.5vw",
  },

  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
    height: "48vw",
  },
  // necessary for content to be below app bar
  // toolbar: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    // backgroundColor: theme.palette.background.default,
    padding: theme.spacing(1),
  },
}));
//logo change
// const logos = { Logo, Logowhite };

const Parent = React.memo(function PermanentDrawerLeft() {
  const classes = useStyles();
  const [darkState, setDarkState] = useState(false);
  const palletType = darkState ? "dark" : "light";
  const mainPrimaryColor = darkState ? "#424242" : "#424242";
  const mainSecondaryColor = darkState ? deepOrange[900] : deepOrange[900];
  const headercolor = darkState
    ? "linear-gradient(to right bottom, #ED1C24, #FDB815)"
    : "linear-gradient(to right bottom, #1B1B1E, #424240)";
  const logos = { Logo, Logowhite };
  const [isToggled, setToggled] = useState(logos.Logo);
  // const toggleTrueFalse = (e) => {
  //   e.preventDefault();
  //   setToggled(!isToggled);
  // };
  // const [selected, setselected] = useState(logos.Logo);
// const Image = isToggled ? logos.Logo : logos.Logowhite;
  const Image =  logos.Logo;
  const darkTheme = createMuiTheme({
    palette: {
      type: palletType,
      primary: {
        main: mainPrimaryColor,
        backgroundone: headercolor,
      },
      secondary: {
        main: mainSecondaryColor,
      },
    },
  });
  const handleThemeChange = (e) => {
    e.preventDefault();
    setDarkState(!darkState);
    setToggled(!isToggled);

    // setselected(!selected);
  };
  const [open, setOpen] = React.useState(true);
  const [openthirdparty, setOpenthirdparty] = React.useState(true);
  const [showExpire, setShowExpire] = React.useState(false)

  const handleClick = () => {
    setOpen(!open);
  };
  const handleclickthirdparty = () => {
    setOpenthirdparty(!openthirdparty);
  };

  const handleCloseshowExpire = () => {
    setShowExpire(false)
  };

  const handleOpenshowExpire = () => {
    setShowExpire(true)
  };

  const renewLicense = () => {
    window.open("https://rzp.io/i/kBJ57Wmo0");
  };

  // var today = new Date().toISOString().substr(0, 10);
  // var pending = new Date(localStorage.expiration_date).toISOString().substr(0, 10);
  // var expire = new Date(localStorage.expire).toISOString().substr(0, 10);
  // console.log("today,pending", today, pending);

  // let timeref;
  // if (today === pending) {
  //   timeref = setInterval(handleOpenshowExpire, 80000);
  // }

  return (
    <div className={classes.root}>
      <ThemeProvider theme={darkTheme}>
        {/* <Router history={history}> */}
        <CssBaseline />
        <AppBar
          position="fixed"
          className={classes.appBar}
          style={{
            height: "85px",
            background: "linear-gradient(to right bottom, #ED1C24, #FDB815)",
            // fontFamily:"roboto thin"
          }}
        >
          <Toolbar>
            <Typography class="head1"
              // variant="h4"
              // style={{
              //   paddingTop: "50px",
              //   // paddingRight: "30px",
              //   paddingBottom: "50px",
              //   // paddingLeft: " 80px",
              //   color: "white",
              //   // fontFamily:"Open Sans",
              //   letterSpacing: "4px",
              //   fontWeight: "300",
              // }}
            >
              {i18next.t("SMART ANALYTICAL TOOL")}
            </Typography>

            <hr />
            <Toolbar style={{ align: "right" }}>
              <ChangeLanguage />
              <ChangeProfiles />
              <Brightness4Icon />
              <div align="right">
                <Switchtheme
                  checked={darkState}
                  onChange={handleThemeChange}
                  // onClick={toggleTrueFalse}
                />
              </div>
              <div align="right">
                <Menudropdown />
              </div>
            </Toolbar>
          </Toolbar>
        </AppBar>

        <Drawer
          className={classes.drawer}
          variant="permanent"
          classes={{
            paper: classes.drawerPaper,
          }}
          anchor="left"
        >
          <div
            style={{
              paddingTop: "15px",
              paddingRight: "5px",
              paddingBottom: "3px",
              paddingLeft: "30px",
            }}
          >
            <img src={Image} alt="Logo" height="120px" width="150px" />
          </div>
          <div
          // className={classes.toolbar}
          />

          <Modal open={showExpire} onClose={handleCloseshowExpire}>
            <div
              style={{
                // width:1800,
                marginTop: "25%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Paper
                elevation={3}
                style={{
                  textAlign: "center",
                  padding: "10px",
                }}
              >
                <div align="right">
                  <IconButton onClick={handleCloseshowExpire}>
                    <CloseIcon />
                  </IconButton>
                </div>
                <div>
                  <p style={{ fontSize: "18px", padding: "5px" }}>
                    Your license is going to expired
                  </p>{" "}
                  <Button
                    variant="warning"
                    onClick={renewLicense}
                    align="right"
                  >
                    Renew License
                  </Button>{" "}
                </div>
              </Paper>
            </div>
          </Modal>

          <List style={{ paddingLeft: "15px" }}>
            <ListItem
              button
              component={Link}
              to="/parent/homedash"
              onClick={handleClick}
              style={{ paddingTop: "20px", paddingBottom: "20px" }}
            >
              <ListItemIcon
                style={{ paddingleft: "10px", marginRight: "-15px" }}
              >
                <DashboardIcon />
              </ListItemIcon>
              <ListItemText primary={i18next.t("Home")} />
              {open ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={open} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItem
                  button
                  className={classes.nested}
                  component={Link}
                  to="/parent/dashboard"
                  style={{ paddingTop: "20px", paddingBottom: "20px" }}
                >
                  <ListItemIcon
                    style={{ paddingleft: "10px", marginRight: "-15px" }}
                  >
                    <TwitterIcon />
                  </ListItemIcon>
                  <ListItemText primary={i18next.t("Twitter Dashboard")} />
                </ListItem>
                <ListItem
                  button
                  className={classes.nested}
                  component={Link}
                  to="/parent/fbdb"
                  style={{ paddingTop: "20px", paddingBottom: "20px" }}
                >
                  <ListItemIcon
                    style={{ paddingleft: "10px", marginRight: "-15px" }}
                  >
                    <FacebookIcon />
                  </ListItemIcon>
                  <ListItemText primary={i18next.t("FB Dashboard")} />
                </ListItem>
                <ListItem
                  button
                  className={classes.nested}
                  component={Link}
                  to="/parent/indb"
                  style={{ paddingTop: "20px", paddingBottom: "20px" }}
                >
                  <ListItemIcon
                    style={{ paddingleft: "10px", marginRight: "-15px" }}
                  >
                    <InstagramIcon />
                  </ListItemIcon>
                  <ListItemText primary={i18next.t("Instagram Dashboard")} />
                </ListItem>
              </List>
            </Collapse>
            <ListItem
              button
              // component={Link}
              // to="/parent/homedash"
              onClick={handleclickthirdparty}
              // selected={true}
              // disabled={false}
              style={{ paddingTop: "20px", paddingBottom: "20px" }}
            >
              <ListItemIcon
                style={{ paddingleft: "10px", marginRight: "-15px" }}
              >
                <AssessmentIcon />
              </ListItemIcon>
              <ListItemText primary={i18next.t("Third Party Analysis")} />
              {openthirdparty ? <ExpandLess /> : <ExpandMore />}
            </ListItem>
            <Collapse in={openthirdparty} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItem
                  button
                  component={Link}
                  to="/parent/grievance"
                  style={{ paddingTop: "20px", paddingBottom: "20px" }}
                >
                  <ListItemIcon
                    style={{ paddingleft: "10px", marginRight: "-15px" }}
                  >
                    <TimelineIcon />
                  </ListItemIcon>
                  <ListItemText primary={i18next.t("Grievance Data")} />
                </ListItem>
              </List>
            </Collapse>
            <ListItem
              button
              component={Link}
              to="/parent/webcrawler"
              style={{ paddingTop: "20px", paddingBottom: "20px" }}
            >
              <ListItemIcon
                style={{ paddingleft: "10px", marginRight: "-15px" }}
              >
                <LanguageIcon />
              </ListItemIcon>
              <ListItemText primary={i18next.t("Web Crawler")} />
            </ListItem>
            <ListItem
              button
              component={Link}
              to="/parent/aboutus"
              style={{ paddingTop: "20px", paddingBottom: "20px" }}
            >
              <ListItemIcon
                style={{ paddingleft: "10px", marginRight: "-15px" }}
              >
                <InfoIcon />
              </ListItemIcon>
              <ListItemText primary={i18next.t("About SAT")} />
            </ListItem>
          </List>
        </Drawer>
        {/* <Dashboardtop/> */}
        <main className={classes.content}>
          <div className={classes.toolbar} />
          <Switch>
            <Route exact path="/parent">
              <Redirect from="/parent" to="/parent/homedash" />
            </Route>
            <Route
              exact
              path="/parent/homedash"
              component={Dashboardtop}
            ></Route>
            <Route exact path="/parent/dashboard" component={Dashboard}></Route>
            <Route exact path="/parent/cms" component={Cms}></Route>
            <Route
              exact
              path="/parent/webcrawler"
              component={Webcrawler}
            ></Route>
            <Route exact path="/parent/aboutus" component={Aboutus}></Route>
            <Route exact path="/parent/signin" component={Signin}></Route>
            <Route exact path="/parent/grievance" component={Gravience}></Route>

            <Route
              exact
              path="/parent/fbdb"
              component={Facebookdashboard}
            ></Route>
            <Route
              exact
              path="/parent/indb"
              component={Instagramdashboard}
            ></Route>
          </Switch>
          <Footer />
        </main>
        {/* </Router> */}
      </ThemeProvider>
    </div>
  );
});
export default Parent;
