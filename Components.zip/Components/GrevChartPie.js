// import React, { useState, useMemo } from "react";
// import { PieChart, Pie, Tooltip, Legend, Cell } from "recharts";
// import { GrevienceData } from "./GravienceData";
// const CustomTooltip = ({ active, payload, label }) => {
//   if (active && payload && payload.length) {
//     return (
//       <div className="custom-tooltip">
//         <p className="label">{`${payload[0].name} : ${payload[0].value} % `}</p>
//       </div>
//     );
//   }
//   return null;
// };

// const GrevChartPie = () => {
//   const [data, setData] = useState(GrevienceData);

//   // Function to calculate total completion time for each stage
//   const calculateTotalCompletionTimeByStage = () => {
//     const StageData = {};
//     const StageCount = {};
//     const avgCompletionTime = {};
//     data.map((item) => {
//       const { Stage, CompletionTime } = item;
//       if (!StageData[Stage]) {
//         StageData[Stage] = 0;
//         StageCount[Stage] = 0;
//       }
//       StageData[Stage] = StageData[Stage] + parseInt(CompletionTime);
//       StageCount[Stage] = StageCount[Stage] + 1;
//     });
//     console.log("StageData", StageData);
//     Object.keys(StageData).map((ele) => {
//       avgCompletionTime[ele] = StageData[ele] / StageCount[ele];
//     });

//     let Total = 0;
//     Object.values(avgCompletionTime).map((item) => (Total = item + Total));

//     Object.keys(avgCompletionTime).map((elem) => {
//       avgCompletionTime[elem] = (avgCompletionTime[elem] / Total) * 100;
//     });
//     return avgCompletionTime;
//   };

//   // Prepare data for pie chart
//   const prepareDataForPieChart = () => {
//     const stageCompletionTimes = calculateTotalCompletionTimeByStage();
//     return Object.keys(stageCompletionTimes).map((stage) => ({
//       name: stage,
//       value: parseFloat(stageCompletionTimes[stage].toFixed(2)), // Calculate percentage
//     }));
//   };

//   const COLORS = ["#0088FE", "#FFBB28", "#FF8042", "#AF19FF"]; // Add more colors if needed

//   return (
//     <div>
//       {/* <h2>Stage-wise Completion Time Percentage</h2> */}
//       <PieChart width={400} height={400}>
//         <Pie
//           data={prepareDataForPieChart()}
//           cx="70%"
//           cy="50%"
//           labelLine={true}
//           label={({ name, value }) => `${name} ${(value * 100).toFixed(2)}%`}
//           outerRadius={120}
//           innerRadius={100}
//           fill="#8884d8"
//           dataKey="value"
//         >
//           <Legend layout="vertical" verticalAlign="top" align="right" />
//           {prepareDataForPieChart().map((entry, index) => (
//             <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//           ))}
//         </Pie>
//         <Tooltip content={<CustomTooltip />} />
//       </PieChart>
//     </div>
//   );
// };

// export default GrevChartPie;
import React, { useState } from "react";
import { PieChart, Pie, Tooltip, Legend, Cell } from "recharts";
import { GrevienceData } from "./GravienceData";

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <p className="label">{`${payload[0].name} : ${payload[0].value} % `}</p>
      </div>
    );
  }
  return null;
};

const GrevChartPie = () => {
  const [data, setData] = useState(GrevienceData);

  // Function to calculate total completion time for each stage
  const calculateTotalCompletionTimeByStage = () => {
    const StageData = {};
    const StageCount = {};
    const avgCompletionTime = {};
    data.forEach((item) => {
      const { Stage, CompletionTime } = item;
      if (!StageData[Stage]) {
        StageData[Stage] = 0;
        StageCount[Stage] = 0;
      }
      StageData[Stage] += parseInt(CompletionTime);
      StageCount[Stage]++;
    });

    Object.keys(StageData).forEach((ele) => {
      avgCompletionTime[ele] = StageData[ele] / StageCount[ele];
    });

    let Total = 0;
    Object.values(avgCompletionTime).forEach((item) => (Total += item));

    Object.keys(avgCompletionTime).forEach((elem) => {
      avgCompletionTime[elem] = (avgCompletionTime[elem] / Total) * 100;
    });

    return avgCompletionTime;
  };

  // Prepare data for pie chart
  const prepareDataForPieChart = () => {
    const stageCompletionTimes = calculateTotalCompletionTimeByStage();
    return Object.keys(stageCompletionTimes).map((stage) => ({
      name: stage,
      value: parseFloat(stageCompletionTimes[stage].toFixed(2)), // Calculate percentage
    }));
  };

  const COLORS = ["#0088FE", "#FFBB28", "#FF8042", "#AF19FF"]; // Add more colors if needed

  return (
    <div>
      <PieChart width={600} height={400}>
        <Pie
          data={prepareDataForPieChart()}
          cx="50%"
          cy="50%"
          labelLine={true}
          label={({ name, value }) => `${name} ${(value).toFixed(2)}%`}
          outerRadius={120}
          innerRadius={90}
          fill="#8884d8"
          dataKey="value"
        >
          {prepareDataForPieChart().map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
        <Legend />
      </PieChart>
    </div>
  );
};

export default GrevChartPie;
