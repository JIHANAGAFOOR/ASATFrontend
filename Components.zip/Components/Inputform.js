import React, { Component } from "react";
import { Formik } from "formik";
import SignIn from "./Signin";
import * as Yup from "yup";
class Inputform extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  validationSchema = Yup.object({
    email: Yup.string("Enter your email")
      .email("Enter a valid email")
      .required("Email is required"),

    password: Yup.string("")
      .min(8, "Password must contain at least 8 characters")
      .required("Enter your password"),
  });
  render() {
    const values = { name: "", email: "", confirmPassword: "", password: "" };
    return (
      <div>
        <Formik
          render={(props) => <SignIn {...props} />}
          initialValues={values}
          validationSchema={this.validationSchema}
        />
      </div>
    );
  }
}

export default Inputform;


