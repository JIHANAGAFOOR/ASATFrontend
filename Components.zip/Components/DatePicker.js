import "date-fns";
import React from "react";
import Grid from "@material-ui/core/Grid";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";

export default function DatePickers({ label, getDate, defaultDate }) {
  // The first commit of Material-UI
  const [selectedDate, setSelectedDate] = React.useState(defaultDate);
  const handleDateChange = (date) => {
    setSelectedDate(date);
    getDate(date);
  };

  return (
    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <Grid container justifyContent="space-around">
        <KeyboardDatePicker
          margin="normal"
          id="date-picker-dialog"
          label={label}
          format="dd/MM/yyyy"
          value={selectedDate}
          onChange={handleDateChange}
          KeyboardButtonProps={{
            "aria-label": "change date",
          }}
          minDate="11.05.2021"
          maxDate={new Date()}
        />
      </Grid>
    </MuiPickersUtilsProvider>
  );
}
