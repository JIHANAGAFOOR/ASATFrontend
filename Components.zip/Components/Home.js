import React, { Component } from "react";
import { Switch, Route } from "react-router-dom";
import Parent from "./Parent";

class Home extends Component {
  render() {
    return (
      <div>
        <Parent />
        {/* <Switch>
          <Route exact path="/dashboardtop" component={Dashboardtop}></Route>
          <Route exact path="/dashboard" component={Dashboard}></Route>
              <Route exact path="/survey" component={Survey}></Route>
              <Route exact path="/cms" component={Cms}></Route>
              <Route exact path="/webcrawler" component={Webcrawler}></Route>
              <Route exact path="/aboutus" component={Aboutus}></Route>
              <Route exact path="/signup" component={Signup}></Route>
              <Route exact path="/signin" component={Signin}></Route>
              <Route
                exact
                path="/twitterAnalysis"
                component={Twittersentimental}
              ></Route>

              <Route
                exact
                path="/twittertrend"
                component={Twittertrend}
              ></Route>

              <Route
                exact
                path="/hashtagtwitter"
                component={Hashtagtwitter}
              ></Route>
              <Route
                exact
                path="/topicmodellingtwitter"
                component={Twittertopicmodelling}
              ></Route>

              <Route
                exact
                path="/twittersocialnetwork"
                component={Twittersocialnetworkanalysis}
              ></Route>
              
              <Route exact path="/dashboardtop" component={Dashboardtop}></Route>
              <Route exact path="/fbdb" component={Facebookdashboard}></Route>
        </Switch> */}
      </div>
    );
  }
}

export default Home;
