import React, { Component } from 'react';

class Nodata extends Component {
    render() {
        return (
            <div>
                <h1>No Data Found</h1>
            </div>
        );
    }
}

export default Nodata;